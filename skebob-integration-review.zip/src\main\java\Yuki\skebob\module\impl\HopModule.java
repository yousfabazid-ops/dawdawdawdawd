package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import net.minecraft.client.MinecraftClient;

public class HopModule extends Module {

    private final BooleanSetting onlyWhileMoving = (BooleanSetting) this.addSetting(
        new BooleanSetting(
            "Only While Moving",
            "Automatically jump only while moving",
            true
        )
    );

    public HopModule() {
        super(
            "Hop",
            "Automatically jumps when on the ground",
            Category.MISC
        );
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null) {
            return;
        }

        if (!mc.player.isOnGround()) {
            return;
        }

        if (onlyWhileMoving.get()) {
            if (mc.player.forwardSpeed == 0.0F &&
                mc.player.sidewaysSpeed == 0.0F) {
                return;
            }
        }

        mc.player.jump();
    }
}