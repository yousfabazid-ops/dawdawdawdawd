package Yuki.skebob.module.impl;

import Yuki.skebob.mixin.AbstractContainerScreenAccessor;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.util.InventoryHelper;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.Items;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class HoverTotemModule extends Module {
   public final SliderSetting tickDelay = (SliderSetting)this.addSetting(new SliderSetting("Tick Delay", "", (double)0.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final BooleanSetting hotbarTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Hotbar Totem", "", true));
   public final SliderSetting hotbarSlot = (SliderSetting)this.addSetting(new SliderSetting("Hotbar Slot", "", (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   public final BooleanSetting autoSwitchToTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Auto Switch To Totem", "", false));
   private int tickCounter;

   public HoverTotemModule() {
      super("Hover Totem", "Equip totem when hovering over one in inventory", Category.COMBAT);
   }

   protected void onEnable() {
      this.tickCounter = 0;
   }

   protected void onDisable() {
      this.tickCounter = 0;
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null) {
         if ((Boolean)this.autoSwitchToTotem.get() && (Boolean)this.hotbarTotem.get()) {
            int slot = this.hotbarSlot.getInt() - 1;
            if (client.player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
               InventoryHelper.swap(slot);
            }
         }

         Screen var3 = client.currentScreen;
         if (var3 instanceof HandledScreen) {
            HandledScreen<?> handledScreen = (HandledScreen)var3;
            ++this.tickCounter;
            if (this.tickCounter >= this.tickDelay.getInt()) {
               this.tickCounter = 0;
               Slot focusedSlot = this.getFocusedSlot(handledScreen);
               if (focusedSlot != null && focusedSlot.hasStack() && focusedSlot.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                  int slotId = focusedSlot.id;
                  client.interactionManager.clickSlot(handledScreen.getScreenHandler().syncId, slotId, 0, SlotActionType.PICKUP, client.player);
                  client.interactionManager.clickSlot(handledScreen.getScreenHandler().syncId, 45, 0, SlotActionType.PICKUP, client.player);
                  client.interactionManager.clickSlot(handledScreen.getScreenHandler().syncId, slotId, 0, SlotActionType.PICKUP, client.player);
               }
            }
         }
      }

   }

   private Slot getFocusedSlot(HandledScreen<?> screen) {
      return ((AbstractContainerScreenAccessor)screen).getHoveredSlot();
   }
}
