package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.impl.FakeStatsModule;
import net.minecraft.text.Text;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.StringVisitable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public class GuiSidebarMixin {
   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$beginSidebar(DrawContext guiGraphics, ScoreboardObjective objective, CallbackInfo ci) {
      FakeStatsModule fs = fakeStats();
      if (fs != null) {
         fs.beginSidebar();
      }

   }

   @Redirect(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/font/TextRenderer;getWidth(Lnet/minecraft/text/StringVisitable;)I",
   ordinal = 1
)
   )
   private int SkebobClient$lineWidth(TextRenderer font, StringVisitable text) {
      FakeStatsModule fs = fakeStats();
      if (fs != null && text instanceof Text component) {
         try {
            return font.getWidth(fs.rewriteForWidth(component));
         } catch (Exception var6) {
         }
      }

      return font.getWidth(text);
   }

   @ModifyArg(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)V",
   ordinal = 1
),
      index = 1
   )
   private Text SkebobClient$lineText(Text text) {
      FakeStatsModule fs = fakeStats();
      if (fs != null) {
         try {
            return fs.rewriteForDraw(text);
         } catch (Exception var4) {
         }
      }

      return text;
   }

   private static FakeStatsModule fakeStats() {
      ModuleManager m = SkebobClient.modules();
      return m != null && m.fakeStats != null && m.fakeStats.isEnabled() ? m.fakeStats : null;
   }
}
