package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.impl.SkinChangerModule;
import Yuki.skebob.render.custommodel.CustomPlayerModelState;
import Yuki.skebob.render.custommodel.CustomPlayerModels;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererSkinChangerMixin {
    @Inject(
        method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
        at = @At("TAIL")
    )
    private void skebob$updateCustomModelState(PlayerLikeEntity entity, PlayerEntityRenderState state,
                                               float tickProgress, CallbackInfo ci) {
        CustomPlayerModelState customState = (CustomPlayerModelState) state;
        ModuleManager manager = SkebobClient.modules();
        SkinChangerModule module = manager == null ? null : manager.skinChanger;
        if (module != null && module.isEnabled() && module.shouldApply(entity.getUuid())) {
            customState.skebob$setCustomModel(module.model.get());
        } else {
            customState.skebob$setCustomModel("");
        }
    }

    @Inject(
        method = "getTexture(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;",
        at = @At("RETURN"),
        cancellable = true
    )
    private void skebob$customModelTexture(PlayerEntityRenderState state,
                                           CallbackInfoReturnable<Identifier> cir) {
        CustomPlayerModelState customState = (CustomPlayerModelState) state;
        if (customState.skebob$hasCustomModel()) {
            cir.setReturnValue(CustomPlayerModels.texture(customState.skebob$getCustomModel()));
        }
    }
}
