package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.TridentItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.concurrent.ThreadLocalRandom;

public class TriggerbotModule extends Module {

   public final BooleanSetting players = (BooleanSetting) this.addSetting(
      new BooleanSetting("Players", "Target players", true)
   );

   public final BooleanSetting passive = (BooleanSetting) this.addSetting(
      new BooleanSetting("Passive", "Target passive mobs", false)
   );

   public final BooleanSetting hostile = (BooleanSetting) this.addSetting(
      new BooleanSetting("Hostile", "Target hostile mobs", true)
   );

   public final BooleanSetting neutral = (BooleanSetting) this.addSetting(
      new BooleanSetting("Neutral", "Target neutral/angerable mobs", false)
   );

   public final BooleanSetting invisible = (BooleanSetting) this.addSetting(
      new BooleanSetting("Invisible", "Target invisible entities", false)
   );

   public final BooleanSetting bots = (BooleanSetting) this.addSetting(
      new BooleanSetting("Bots", "Also attack bots (players without tab list entry)", false)
   );

   public final SliderSetting delayMs = (SliderSetting) this.addSetting(
      new SliderSetting(
         "Delay",
         "Delay between attacks in milliseconds",
         90.0,
         30.0,
         500.0,
         5.0,
         "ms"
      )
   );

   public final BooleanSetting randomizeDelay = (BooleanSetting) this.addSetting(
      new BooleanSetting("Randomize Delay", "Randomizes the delay slightly", true)
   );

   public final BooleanSetting requireWeapon = (BooleanSetting) this.addSetting(
      new BooleanSetting("Require Weapon", "Only attack when holding a sword, axe or trident", false)
   );

   private long lastAttackTime = 0L;
   private double currentDelay = 90.0;

   public TriggerbotModule() {
      super(
         "TriggerBot",
         "Automatically attacks entities when looking at them",
         Category.COMBAT
      );
   }

   @Override
   protected void onEnable() {
      this.lastAttackTime = 0L;
      this.currentDelay = this.delayMs.get();
   }

   @Override
   protected void onDisable() {
      this.lastAttackTime = 0L;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
      if (mc.currentScreen != null) return;

      // Require weapon check
      if (this.requireWeapon.get() && !this.isHoldingWeapon(mc)) return;

      // Delay check
      long now = System.currentTimeMillis();
      if (now - this.lastAttackTime < this.currentDelay) return;

      // Must be looking at an entity
      if (!(mc.crosshairTarget instanceof EntityHitResult hit) || hit.getType() != HitResult.Type.ENTITY) {
         return;
      }

      Entity target = hit.getEntity();
      if (!this.isValidTarget(mc, target)) return;

      // Attack
      mc.interactionManager.attackEntity(mc.player, target);
      mc.player.swingHand(Hand.MAIN_HAND);

      this.lastAttackTime = now;
      this.currentDelay = this.getNextDelay();
   }

   private double getNextDelay() {
      double base = this.delayMs.get();
      if (!this.randomizeDelay.get()) {
         return base;
      }
      double variance = base * 0.25;
      return base + ThreadLocalRandom.current().nextDouble(-variance, variance);
   }

   private boolean isValidTarget(MinecraftClient mc, Entity entity) {
      if (!(entity instanceof LivingEntity living)) return false;
      if (entity == mc.player) return false;
      if (!entity.isAlive() || living.getHealth() <= 0.0F) return false;
      if (!this.invisible.get() && entity.isInvisible()) return false;

      if (living instanceof PlayerEntity player) {
         if (!this.players.get()) return false;
         // Bot check: if bots setting is false, skip players that are not in the tab list
         if (!this.bots.get() && this.isBot(mc, player)) return false;
         return true;
      }

      if (living instanceof HostileEntity || living instanceof Monster) {
         return this.hostile.get();
      }

      if (this.isAngerable(living)) {
         return this.neutral.get();
      }

      if (living instanceof PassiveEntity) {
         return this.passive.get();
      }

      return false;
   }

   private boolean isBot(MinecraftClient mc, PlayerEntity player) {
      if (mc.getNetworkHandler() == null) return false;
      PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
      return entry == null;
   }

   private boolean isAngerable(LivingEntity entity) {
      for (Class<?> clazz = entity.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
         for (Class<?> iface : clazz.getInterfaces()) {
            if ("Angerable".equals(iface.getSimpleName())) {
               return true;
            }
         }
      }
      return false;
   }

   private boolean isHoldingWeapon(MinecraftClient mc) {
      ItemStack stack = mc.player.getMainHandStack();
      if (stack == null || stack.isEmpty()) return false;
      return stack.isIn(ItemTags.SWORDS)
         || stack.getItem() instanceof AxeItem
         || stack.getItem() instanceof TridentItem;
   }
}