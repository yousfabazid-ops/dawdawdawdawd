package Yuki.skebob.module.impl;

import Yuki.skebob.mixin.MinecraftAccessor;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.ModeSetting;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.client.MinecraftClient;

public class FastUseModule extends Module {
   public final ModeSetting items = (ModeSetting)this.addSetting(new ModeSetting("Items", "What to speed up", "All", new String[]{"All", "Pearls", "XP Bottles"}));

   public FastUseModule() {
      super("FastUse", "Removes item use cooldowns", Category.MISC);
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && this.appliesTo(mc)) {
         ((MinecraftAccessor)mc).SkebobClient$setRightClickDelay(0);
      }

   }

   private boolean appliesTo(MinecraftClient mc) {
      if (this.items.is("All")) {
         return true;
      } else {
         Item target = this.items.is("Pearls") ? Items.ENDER_PEARL : Items.EXPERIENCE_BOTTLE;
         return mc.player.getMainHandStack().isOf(target) || mc.player.getOffHandStack().isOf(target);
      }
   }
}
