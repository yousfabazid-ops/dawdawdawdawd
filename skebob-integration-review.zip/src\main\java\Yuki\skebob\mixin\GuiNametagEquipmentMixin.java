package Yuki.skebob.mixin;

import Yuki.skebob.render.WorldNametagRenderer;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public class GuiNametagEquipmentMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("TAIL")}
   )
   private void SkebobClient$nametagEquipment(DrawContext guiGraphics, RenderTickCounter deltaTracker, CallbackInfo ci) {
      WorldNametagRenderer.renderEquipment(guiGraphics);
   }
}
