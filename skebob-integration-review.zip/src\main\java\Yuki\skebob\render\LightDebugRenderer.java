package Yuki.skebob.render;

import Yuki.skebob.module.impl.LightDebugModule;
import Yuki.skebob.util.Colors;
import java.util.List;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;

public final class LightDebugRenderer {
   private static final int MAX_CELLS = 50000;

   private LightDebugRenderer() {
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d camera, LightDebugModule module) {
      int rendered = 0;
      boolean stop = false;

      for(List<LightDebugModule.Cell> cells : module.cells().values()) {
         for(LightDebugModule.Cell cell : cells) {
            float brightness = (float)(cell.light() - 1) / 14.0F;
            int shade = Math.round(Math.clamp(brightness, 0.0F, 1.0F) * 255.0F);
            int color = Colors.withAlpha(shade << 16 | shade << 8 | shade, 110);
            double x = (double)cell.pos().getX();
            double y = (double)cell.pos().getY();
            double z = (double)cell.pos().getZ();
            EspBoxRenderer.fill(bufferSource, poseStack, camera, x, y, z, x + (double)1.0F, y + (double)1.0F, z + (double)1.0F, color);
            ++rendered;
            if (rendered >= 50000) {
               stop = true;
               break;
            }
         }

         if (stop) {
            break;
         }
      }

      EspBoxRenderer.flush(bufferSource);
   }
}
