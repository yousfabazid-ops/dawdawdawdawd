package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.ModeSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

/** Client-side Minecraft skin changer. Custom PNG skins are discovered on startup. */
public final class SkinChangerModule extends Module {
    public final ModeSetting model;
    public final ModeSetting applyTo;

    public SkinChangerModule() {
        super("Skin Changer", "Applies 2D Minecraft skin textures to the player model", Category.MISC);
        String[] skins = discoverSkinOptions();
        this.model = addSetting(new ModeSetting(
            "Skin", "Choose a Minecraft skin PNG", "CJ", skins));
        this.applyTo = addSetting(new ModeSetting(
            "Apply To", "Choose which rendered players use the skin", "Self", "Self", "Others", "Everyone"));
    }

    private static String[] discoverSkinOptions() {
        Map<String, String> options = new LinkedHashMap<>();
        options.put("cj", "CJ");
        options.put("tung_tung", "Tung Tung");
        options.put("sweetie_fox", "Sweetie Fox");
        options.put("sweetie_fox_2d", "Sweetie Fox 2D");
        options.put("sweetie_fox_v2", "Sweetie Fox V2");

        Path folder = FabricLoader.getInstance().getConfigDir().resolve("skebob").resolve("skins");
        try {
            Files.createDirectories(folder);
            try (Stream<Path> files = Files.list(folder)) {
                files.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted()
                    .forEach(path -> {
                        String filename = path.getFileName().toString();
                        String base = filename.substring(0, filename.length() - 4);
                        String key = normalizeKey(base);
                        if (!key.isEmpty()) options.putIfAbsent(key, displayName(base));
                    });
            }
        } catch (IOException exception) {
            System.err.println("[Skebob] Could not scan custom skin folder: " + exception.getMessage());
        }
        return options.values().toArray(String[]::new);
    }

    private static String normalizeKey(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).trim().replaceAll("[\\s-]+", "_")
            .replaceAll("[^a-z0-9_]", "").replaceAll("_+", "_");
    }

    private static String displayName(String value) {
        String cleaned = value.replace('_', ' ').replace('-', ' ').trim();
        StringBuilder result = new StringBuilder();
        for (String part : cleaned.split("\\s+")) {
            if (part.isEmpty()) continue;
            if (result.length() > 0) result.append(' ');
            if (part.equalsIgnoreCase("cj")) result.append("CJ");
            else result.append(part.substring(0, 1).toUpperCase(Locale.ROOT))
                .append(part.substring(1).toLowerCase(Locale.ROOT));
        }
        return result.length() == 0 ? value : result.toString();
    }

    public boolean shouldApply(UUID uuid) {
        if (uuid == null) return false;
        MinecraftClient client = MinecraftClient.getInstance();
        UUID self = client.player == null ? null : client.player.getUuid();
        if (applyTo.is("Everyone")) return true;
        if (applyTo.is("Self")) return self != null && self.equals(uuid);
        return self == null || !self.equals(uuid);
    }
}