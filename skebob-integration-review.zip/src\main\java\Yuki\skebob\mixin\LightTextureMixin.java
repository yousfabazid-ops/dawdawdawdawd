package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Slice;

@Mixin({LightmapTextureManager.class})
public class LightTextureMixin {
   @ModifyExpressionValue(
      method = {"update"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"
)},
      slice = {@Slice(
   from = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/GameOptions;getGamma()Lnet/minecraft/client/option/SimpleOption;"
)
)}
   )
   private Object SkebobClient$fullbrightGamma(Object original) {
      ModuleManager modules = SkebobClient.modules();
      return modules != null && modules.fullbright != null && modules.fullbright.isEnabled() ? (double)modules.fullbright.gamma.getFloat() : original;
   }
}
