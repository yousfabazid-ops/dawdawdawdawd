package Yuki.skebob.mixin;

import Yuki.skebob.render.custommodel.CustomPlayerModelState;
import Yuki.skebob.render.custommodel.CustomPlayerModels;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.state.CameraRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererCustomModelMixin {
    @Shadow protected EntityModel<?> model;
    @Unique private EntityModel<?> skebob$originalModel;

    @Inject(
        method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
        at = @At("HEAD")
    )
    private void skebob$swapCustomModel(LivingEntityRenderState state, MatrixStack matrices,
                                        OrderedRenderCommandQueue queue, CameraRenderState cameraState,
                                        CallbackInfo ci) {
        // Recover the original model after any prior exceptional render exit.
        if (this.skebob$originalModel != null) {
            this.model = this.skebob$originalModel;
            this.skebob$originalModel = null;
        }
        if (!(state instanceof CustomPlayerModelState customState)
                || !customState.skebob$hasCustomModel()
                || !(this.model instanceof PlayerEntityModel)) {
            return;
        }
        this.skebob$originalModel = this.model;
        this.model = CustomPlayerModels.getModel(customState.skebob$getCustomModel());
    }

    @Inject(
        method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
        at = @At("RETURN")
    )
    private void skebob$restoreModel(LivingEntityRenderState state, MatrixStack matrices,
                                     OrderedRenderCommandQueue queue, CameraRenderState cameraState,
                                     CallbackInfo ci) {
        if (this.skebob$originalModel != null) {
            this.model = this.skebob$originalModel;
            this.skebob$originalModel = null;
        }
    }
}
