package Yuki.skebob.module.impl;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.staff.StaffDetector;
import Yuki.skebob.staff.StaffEntry;
import Yuki.skebob.staff.StaffTracker;
import java.util.List;
import java.util.Set;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public class StaffListModule extends Module {
   public final BooleanSetting showOnHud = (BooleanSetting)this.addSetting(new BooleanSetting("Show on HUD", "Display the fixed StaffList panel", true));
   public final StaffTracker tracker = new StaffTracker(this);

   public StaffListModule() {
      super("StaffList", "Lists online staff using the normal preset", Category.MISC);
   }

   protected void onEnable() {
      this.tracker.reset();
   }

   protected void onDisable() {
      this.tracker.clear();
   }

   public void onTick() {
      this.tracker.tick();
   }

   public List<StaffEntry> staff() {
      return this.tracker.current();
   }

   public boolean isHudVisible() {
      return this.isEnabled() && (Boolean)this.showOnHud.get();
   }

   public StaffDetector.DetectConfig detectConfig() {
      return new StaffDetector.DetectConfig("Marker + Rank", Set.of(), StaffDetector.DEFAULT_RANK_KEYWORDS, "â˜…â˜†âœ¦âœ§âœªâœ©âœ«âœ¬âœ­âœ®âœ¯â­âœ°â‚âšâœ´âœµâœ¶âœ·âœ¸âœ¹âŸ", true, true);
   }

   public boolean showRank() {
      return true;
   }

   public boolean showPing() {
      return false;
   }

   public int maxRows() {
      return 6;
   }

   public void onStaffAppear(StaffEntry entry) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null) {
         String rank = entry.rankLabel().isEmpty() ? "Staff" : entry.rankLabel();
         String tail = entry.vanished() ? " (vanished)" : "";
         if (SkebobClient.notifications() != null) {
            SkebobClient.notifications().pushInfo(rank + " " + entry.name() + " online" + tail);
         }

         client.getSoundManager().play(PositionedSoundInstance.master((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.comp_349(), 1.5F, 0.6F));
      }

   }
}
