package Yuki.skebob.render.custommodel;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Skebob skin models: normal skins plus two flat, double-sided photo models. */
public final class CustomPlayerModels {
    private static PlayerEntityModel vanillaPlayerModel;
    private static PlayerEntityModel sweetieFox2DModel;
    private static PlayerEntityModel sweetieFoxV2Model;

    private static final Map<String, Identifier> LOADED_SKINS = new HashMap<>();
    private static final Map<String, Identifier> FAILED_SKINS = new HashMap<>();

    private CustomPlayerModels() { }

    public static PlayerEntityModel getModel(String name) {
        String key = normalizeKey(name);

        if (key.equals("sweetie_fox_2d")) {
            if (sweetieFox2DModel == null) {
                sweetieFox2DModel = createSweetieFox2D();
            }
            return sweetieFox2DModel;
        }

        if (key.equals("sweetie_fox_v2")) {
            if (sweetieFoxV2Model == null) {
                sweetieFoxV2Model = createSweetieFoxV2();
            }
            return sweetieFoxV2Model;
        }

        if (vanillaPlayerModel == null) {
            ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.0F), false);
            vanillaPlayerModel = new PlayerEntityModel(
                TexturedModelData.of(data, 64, 64).createModel(), false
            );
        }

        return vanillaPlayerModel;
    }

    public static Identifier texture(String name) {
        String key = normalizeKey(name);

        if (key.equals("sweetie_fox_2d")) {
            return Identifier.of("skebob", "textures/models/sweetie_fox_2d.png");
        }

        if (key.equals("sweetie_fox_v2")) {
            return Identifier.of("skebob", "textures/models/sweetie_fox_v2_atlas.png");
        }

        if (key.isEmpty()) key = "cj";

        Path customFile = FabricLoader.getInstance().getConfigDir()
            .resolve("skebob").resolve("skins").resolve(key + ".png");

        if (Files.isRegularFile(customFile)) {
            Identifier loaded = loadExternalSkin(key, customFile);
            if (loaded != null) return loaded;
        }

        String builtIn = key.equals("tung_tung") ? "tung_tung"
            : (key.equals("sweetie_fox") ? "sweetie_fox" : "cj");

        return Identifier.of("skebob", "textures/models/" + builtIn + ".png");
    }

    /*
     * Full player-height photo plane:
     * width = 8 model units, height = 32 model units.
     * Bottom edge: originY + (88 * 0.25) = 24.
     */
    private static PlayerEntityModel createSweetieFox2D() {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.0F), false);
        ModelPartData rootData = data.getRoot();

        rootData.addChild("skebob_sweetie_fox_sprite",
            ModelPartBuilder.create().uv(0, 0)
                .cuboid(-32.0F, -40.0F, -0.5F, 64.0F, 128.0F, 1.0F),
            ModelTransform.origin(0.0F, 2.0F, 0.0F));

        ModelPart bakedRoot = TexturedModelData.of(data, 256, 160).createModel();
        ModelPart sprite = bakedRoot.getChild("skebob_sweetie_fox_sprite");

        sprite.xScale = 0.125F;
        sprite.yScale = 0.25F;
        sprite.zScale = 0.001F;
        sprite.setDefaultTransform(sprite.getTransform());

        return new FlatPhotoPlayerModel(bakedRoot, sprite);
    }

    private static PlayerEntityModel createSweetieFoxV2() {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.0F), false);
        ModelPartData rootData = data.getRoot();

        rootData.addChild("skebob_sweetie_fox_v2_sprite",
            ModelPartBuilder.create().uv(0, 0)
                .cuboid(-32.0F, -40.0F, -0.5F, 64.0F, 128.0F, 1.0F),
            ModelTransform.origin(0.0F, 2.0F, 0.0F));

        ModelPart bakedRoot = TexturedModelData.of(data, 256, 160).createModel();
        ModelPart sprite = bakedRoot.getChild("skebob_sweetie_fox_v2_sprite");

        sprite.xScale = 0.125F;
        sprite.yScale = 0.25F;
        sprite.zScale = 0.001F;
        sprite.setDefaultTransform(sprite.getTransform());

        return new FlatPhotoPlayerModel(bakedRoot, sprite);
    }

    private static Identifier loadExternalSkin(String key, Path file) {
        Identifier cached = LOADED_SKINS.get(key);
        if (cached != null) return cached;
        if (FAILED_SKINS.containsKey(key)) return null;

        try (InputStream input = Files.newInputStream(file)) {
            NativeImage image = NativeImage.read(input);

            if (image.getWidth() != 64 || image.getHeight() != 64) {
                image.close();
                System.err.println("[Skebob] Skin '" + file.getFileName()
                    + "' must be a 64x64 PNG. Using a built-in skin instead.");
                FAILED_SKINS.put(key, Identifier.of("skebob", "textures/models/cj.png"));
                return null;
            }

            Identifier id = Identifier.of("skebob", "dynamic_skins/" + key);
            NativeImageBackedTexture texture = new NativeImageBackedTexture(
                () -> "Skebob skin " + key, image
            );

            MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
            LOADED_SKINS.put(key, id);
            return id;
        } catch (IOException | RuntimeException exception) {
            System.err.println("[Skebob] Could not load skin '" + file.getFileName()
                + "': " + exception.getMessage());
            FAILED_SKINS.put(key, Identifier.of("skebob", "textures/models/cj.png"));
            return null;
        }
    }

    private static String normalizeKey(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).trim()
            .replaceAll("[\\s-]+", "_")
            .replaceAll("[^a-z0-9_]", "")
            .replaceAll("_+", "_");
    }

    /** A flat photo model: normal player parts are hidden while the sprite remains visible. */
    private static final class FlatPhotoPlayerModel extends PlayerEntityModel {
        private final ModelPart sprite;

        private FlatPhotoPlayerModel(ModelPart root, ModelPart sprite) {
            super(root, false);
            this.sprite = sprite;
            hideBodyParts();
        }

        @Override
        public void setAngles(PlayerEntityRenderState state) {
            super.setAngles(state);
            hideBodyParts();
        }

        @Override
        public void setVisible(boolean visible) {
            super.setVisible(visible);
            hideBodyParts();
        }

        private void hideBodyParts() {
            this.head.visible = false;
            this.hat.visible = false;
            this.body.visible = false;
            this.jacket.visible = false;
            this.leftArm.visible = false;
            this.rightArm.visible = false;
            this.leftLeg.visible = false;
            this.rightLeg.visible = false;
            this.leftSleeve.visible = false;
            this.rightSleeve.visible = false;
            this.leftPants.visible = false;
            this.rightPants.visible = false;
            // Reapply scale after model updates.
            this.sprite.xScale = 0.125F;
            this.sprite.yScale = 0.25F;
            this.sprite.zScale = 0.001F;
            this.sprite.visible = true;
        }
    }
}
