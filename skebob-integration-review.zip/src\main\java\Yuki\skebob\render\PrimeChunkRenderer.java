package Yuki.skebob.render;

import Yuki.skebob.module.impl.PrimeChunkFinderModule;
import Yuki.skebob.util.Colors;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;

public final class PrimeChunkRenderer {
   private static final double FIXED_CHUNK_Y = (double)64.0F;
   private static final int REPEATER_FILL = Colors.argb(60, 50, 205, 50);
   private static final int REPEATER_OUTLINE = Colors.argb(180, 50, 205, 50);
   private static final int NORMAL_FILL = Colors.argb(120, 50, 205, 50);
   private static final int NORMAL_OUTLINE = Colors.argb(255, 50, 205, 50);
   private static final double SIZE = (double)52.0F;

   private PrimeChunkRenderer() {
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d camera, PrimeChunkFinderModule module) {
      for(ChunkPos pos : module.markedChunks.keySet()) {
         double cx = (double)pos.x * (double)16.0F + (double)8.0F;
         double cz = (double)pos.z * (double)16.0F + (double)8.0F;
         double x0 = cx - (double)26.0F;
         double z0 = cz - (double)26.0F;
         double x1 = cx + (double)26.0F;
         double z1 = cz + (double)26.0F;
         String type = (String)module.markedChunks.get(pos);
         if ("repeater".equals(type)) {
            drawQuad(bufferSource, poseStack, camera, x0, z0, x1, z1, (double)64.0F, REPEATER_FILL, REPEATER_OUTLINE);
         } else {
            drawQuad(bufferSource, poseStack, camera, x0, z0, x1, z1, (double)64.0F, NORMAL_FILL, NORMAL_OUTLINE);
         }
      }

      FlatOverlay.flush(bufferSource);
   }

   private static void drawQuad(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d camera, double x0, double z0, double x1, double z1, double y, int fillColor, int outlineColor) {
      FlatOverlay.fillQuad(bufferSource, poseStack, camera, x0, z0, x1, z1, y, fillColor);
      FlatOverlay.edge(bufferSource, poseStack, camera, x0, z0, x1, z0, y, outlineColor, 2.0F);
      FlatOverlay.edge(bufferSource, poseStack, camera, x1, z0, x1, z1, y, outlineColor, 2.0F);
      FlatOverlay.edge(bufferSource, poseStack, camera, x1, z1, x0, z1, y, outlineColor, 2.0F);
      FlatOverlay.edge(bufferSource, poseStack, camera, x0, z1, x0, z0, y, outlineColor, 2.0F);
   }
}
