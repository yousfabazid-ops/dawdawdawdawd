package Yuki.skebob.mixin;

import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Input.class})
public interface ClientInputAccessor {
   @Accessor("playerInput")
   void SkebobClient$setKeyPresses(PlayerInput var1);

   @Accessor("movementVector")
   void SkebobClient$setMoveVector(Vec2f var1);
}
