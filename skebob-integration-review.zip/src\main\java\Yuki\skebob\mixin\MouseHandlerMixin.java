package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.hud.HudDragController;
import Yuki.skebob.util.CpsTracker;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseHandlerMixin {
   @Inject(
      method = {"onMouseButton(JLnet/minecraft/client/input/MouseInput;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void SkebobClient$onButton(long window, MouseInput buttonInfo, int action, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (window == minecraft.getWindow().getHandle()) {
         if (action == 1 && minecraft.currentScreen == null) {
            CpsTracker.onClick(buttonInfo.button());
         }

         if (minecraft.currentScreen instanceof ChatScreen && buttonInfo.button() == 0 && SkebobClient.hud() != null) {
            if (action == 1) {
               if (HudDragController.tryStartDrag(SkebobClient.hud())) {
                  ci.cancel();
               }
            } else if (action == 0 && HudDragController.isDragging()) {
               HudDragController.stopDrag();
               SkebobClient.config().save();
               ci.cancel();
            }
         }
      }

   }

   @Inject(
      method = {"onMouseScroll(JDD)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void SkebobClient$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (window == minecraft.getWindow().getHandle()) {
         if (minecraft.currentScreen == null && SkebobClient.modules() != null && SkebobClient.modules().freecam != null && SkebobClient.modules().freecam.isActive()) {
            SkebobClient.modules().freecam.adjustSpeed(yOffset);
            ci.cancel();
         } else if (minecraft.currentScreen instanceof ChatScreen && SkebobClient.hud() != null && HudDragController.tryResize(SkebobClient.hud(), yOffset)) {
            ci.cancel();
         }

      }
   }
}
