package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.render.StorageEspRenderer;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.IconListSetting;
import Yuki.skebob.settings.SliderSetting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.block.ChestBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;

public class StorageEspModule extends Module {
   public final SliderSetting range = (SliderSetting)this.addSetting(new SliderSetting("Range", "Max distance a container is highlighted", (double)128.0F, (double)16.0F, (double)256.0F, (double)8.0F));
   public final SliderSetting highlightAlpha = (SliderSetting)this.addSetting(new SliderSetting("Highlight Alpha", "Box opacity (0-255)", (double)200.0F, (double)0.0F, (double)255.0F, (double)1.0F));
   public final BooleanSetting tracers = (BooleanSetting)this.addSetting(new BooleanSetting("Tracers", "Draw lines from the crosshair to each container", false));
   public final IconListSetting containers = (IconListSetting)this.addSetting(new IconListSetting("Containers", "Which container types to highlight"));
   private final Set<BlockPos> interactedBlocks = new HashSet();

   public StorageEspModule() {
      super("StorageESP", "Highlights chests, barrels, shulkers", Category.RENDER);

      for(StorageType type : StorageEspModule.StorageType.values()) {
         this.containers.add(type.key, type.label, type.icon, type.defaultEnabled, type.defaultColor);
      }

   }

   public boolean isTypeEnabled(StorageType type) {
      return this.containers.isEnabled(type.key);
   }

   public int colorFor(StorageType type) {
      return this.containers.color(type.key);
   }

   public boolean isInteracted(int x, int y, int z) {
      return this.isInteracted(new BlockPos(x, y, z));
   }

   public boolean isInteracted(BlockPos pos) {
      return !this.interactedBlocks.isEmpty() && this.interactedBlocks.contains(pos);
   }

   public void trackInteraction(BlockPos pos) {
      if (pos != null) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world != null) {
            this.interactedBlocks.add(pos.toImmutable());
            BlockEntity be = mc.world.getBlockEntity(pos);
            if (be instanceof ChestBlockEntity) {
               BlockState state = mc.world.getBlockState(pos);
               if (state.getBlock() instanceof ChestBlock) {
                  ChestType ct = (ChestType)state.get(ChestBlock.CHEST_TYPE);
                  if (ct != ChestType.SINGLE) {
                     Direction facing = (Direction)state.get(ChestBlock.FACING);
                     BlockPos other = pos.offset(ct == ChestType.LEFT ? facing.rotateYClockwise() : facing.rotateYCounterclockwise());
                     this.interactedBlocks.add(other);
                  }
               }
            }
         }
      }

   }

   protected void onEnable() {
      this.interactedBlocks.clear();
      StorageEspRenderer.resetScan();
   }

   public void onTick() {
      StorageEspRenderer.scan(this);
   }

   protected void onDisable() {
      StorageEspRenderer.resetScan();
   }

   public static enum StorageType {
      CHEST("chest", "Chest", Items.CHEST, -22016, true),
      TRAPPED("trapped", "Trapped Chest", Items.TRAPPED_CHEST, -65536, true),
      ENDER("ender", "Ender Chest", Items.ENDER_CHEST, -8912641, true),
      SHULKER("shulker", "Shulker Box", Items.SHULKER_BOX, -47873, true),
      BARREL("barrel", "Barrel", Items.BARREL, -7842560, true),
      SPAWNER("spawner", "Spawner", Items.SPAWNER, -16711936, true),
      HOPPER("hopper", "Hopper", Items.HOPPER, -7829368, false),
      FURNACE("furnace", "Furnace", Items.FURNACE, -7566196, false),
      BREWING_STAND("brewing_stand", "Brewing Stand", Items.BREWING_STAND, -13374209, false),
      DISPENSER("dispenser", "Dispenser", Items.DISPENSER, -16727604, false),
      DROPPER("dropper", "Dropper", Items.DROPPER, -16727604, false);

      final String key;
      final String label;
      final Item icon;
      final int defaultColor;
      final boolean defaultEnabled;

      private StorageType(String key, String label, Item icon, int defaultColor, boolean defaultEnabled) {
         this.key = key;
         this.label = label;
         this.icon = icon;
         this.defaultColor = defaultColor;
         this.defaultEnabled = defaultEnabled;
      }

      private static StorageType[] $values() {
         return new StorageType[]{CHEST, TRAPPED, ENDER, SHULKER, BARREL, SPAWNER, HOPPER, FURNACE, BREWING_STAND, DISPENSER, DROPPER};
      }

      // $FF: synthetic method
      private static StorageType[] $values$() {
         return new StorageType[]{CHEST, TRAPPED, ENDER, SHULKER, BARREL, SPAWNER, HOPPER, FURNACE, BREWING_STAND, DISPENSER, DROPPER};
      }
   }
}
