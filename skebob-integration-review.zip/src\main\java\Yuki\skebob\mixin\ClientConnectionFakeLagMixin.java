package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FakeLagModule;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class ClientConnectionFakeLagMixin {

    @Inject(
        method = "send(Lnet/minecraft/network/packet/Packet;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void skebob$sendPacket(
        Packet<?> packet,
        CallbackInfo ci
    ) {
        if (FakeLagModule.shouldHold(packet)) {
            ci.cancel();
        }
    }
}