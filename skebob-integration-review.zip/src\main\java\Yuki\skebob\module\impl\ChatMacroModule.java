package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.KeybindSetting;
import Yuki.skebob.settings.ModeSetting;
import Yuki.skebob.settings.StringSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;

public class ChatMacroModule extends Module {
   private static final int SLOTS = 3;
   public final ModeSetting slot = (ModeSetting)this.addSetting(new ModeSetting("Slot", "Macro slot to edit.", "1", new String[]{"1", "2", "3"}));
   public final BooleanSetting sendInstantly = (BooleanSetting)this.addSetting(new BooleanSetting("Send Instantly", "Skip the chat preview and send immediately.", true));
   private final StringSetting[] messages = new StringSetting[3];
   private final KeybindSetting[] keys = new KeybindSetting[3];

   public ChatMacroModule() {
      super("ChatMacro", "Bindable chat command macros.", Category.CLIENT);

      for(int i = 0; i < 3; ++i) {
         String num = Integer.toString(i + 1);
         this.messages[i] = (StringSetting)this.addSetting(new StringSetting("Message " + num, "Message or /command for slot " + num, "", 256, "/say hi"));
         this.keys[i] = (KeybindSetting)this.addSetting(new KeybindSetting("Key " + num, "Key that runs slot " + num, -1));
         this.messages[i].visibleWhen(() -> this.slot.is(num));
         this.keys[i].visibleWhen(() -> this.slot.is(num));
      }

   }

   public boolean onKeyPress(int keyCode) {
      boolean handled = false;

      for(int i = 0; i < 3; ++i) {
         if (this.keys[i].matches(keyCode)) {
            this.run((String)this.messages[i].get());
            handled = true;
         }
      }

      return handled;
   }

   private void run(String message) {
      if (message != null && !message.isBlank()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null && mc.player.networkHandler != null) {
            if (!(Boolean)this.sendInstantly.get()) {
               mc.setScreen(new ChatScreen(message, false));
            } else if (message.startsWith("/")) {
               mc.player.networkHandler.sendChatCommand(message.substring(1));
            } else {
               mc.player.networkHandler.sendChatMessage(message);
            }
         }
      }

   }
}
