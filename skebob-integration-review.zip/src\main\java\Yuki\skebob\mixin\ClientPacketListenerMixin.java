package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.impl.BlockEntityEspModule;
import Yuki.skebob.module.impl.SpawnerProtectModule;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ChunkData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayNetworkHandler.class})
public class ClientPacketListenerMixin {
   @Inject(
      method = {"sendChatCommand"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void SkebobClient$fakeCommands(String command, CallbackInfo ci) {
      ModuleManager modules = SkebobClient.modules();
      if (modules != null) {
         try {
            if (modules.fakePay != null && modules.fakePay.tryIntercept(command)) {
               ci.cancel();
               return;
            }

            if (modules.fakeStats != null && modules.fakeStats.tryInterceptBalance(command)) {
               ci.cancel();
            }
         } catch (Exception var5) {
         }
      }

   }

   @Inject(
      method = {"onChunkData"},
      at = {@At("TAIL")}
   )
   private void SkebobClient$blockEntityChunk(ChunkDataS2CPacket packet, CallbackInfo ci) {
      BlockEntityEspModule module = module();
      if (module != null && module.isEnabled() && module.chunkPacketsEnabled()) {
         try {
            packet.getChunkData().getBlockEntities(packet.getChunkX(), packet.getChunkZ()).accept((ChunkData.BlockEntityVisitor)(pos, type, tag) -> module.record(pos, type));
         } catch (Exception var5) {
         }
      }

   }

   @Inject(
      method = {"onBlockEntityUpdate"},
      at = {@At("TAIL")}
   )
   private void SkebobClient$blockEntityUpdate(BlockEntityUpdateS2CPacket packet, CallbackInfo ci) {
      BlockEntityEspModule module = module();
      if (module != null && module.isEnabled() && module.beUpdatePacketsEnabled()) {
         try {
            module.record(packet.getPos(), packet.getBlockEntityType());
         } catch (Exception var5) {
         }
      }

   }

   private static BlockEntityEspModule module() {
      ModuleManager modules = SkebobClient.modules();
      return modules != null ? modules.blockEntityEsp : null;
   }

   private static SpawnerProtectModule spawnerProtect() {
      ModuleManager modules = SkebobClient.modules();
      return modules != null ? modules.spawnerProtect : null;
   }

   @Inject(
      method = {"onBlockBreakingProgress"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$spawnerProtectDestruction(BlockBreakingProgressS2CPacket packet, CallbackInfo ci) {
      SpawnerProtectModule sp = spawnerProtect();
      if (sp != null && sp.isEnabled() && MinecraftClient.getInstance().isOnThread()) {
         try {
            sp.onBlockDestructionPacket(packet.getEntityId(), packet.getPos());
         } catch (Exception var5) {
         }
      }

   }

   @Inject(
      method = {"onBlockUpdate"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$spawnerProtectBlockUpdate(BlockUpdateS2CPacket packet, CallbackInfo ci) {
      SpawnerProtectModule sp = spawnerProtect();
      if (sp != null && sp.isEnabled() && sp.detectBlockUpdatesEnabled() && MinecraftClient.getInstance().isOnThread()) {
         try {
            sp.onServerBlockUpdate(packet.getPos(), packet.getState(), false);
         } catch (Exception var5) {
         }
      }

   }

   @Inject(
      method = {"onChunkDeltaUpdate"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$spawnerProtectSectionUpdate(ChunkDeltaUpdateS2CPacket packet, CallbackInfo ci) {
      SpawnerProtectModule sp = spawnerProtect();
      if (sp != null && sp.isEnabled() && sp.detectBlockUpdatesEnabled() && MinecraftClient.getInstance().isOnThread()) {
         try {
            packet.visitUpdates((pos, state) -> sp.onServerBlockUpdate(pos, state, true));
         } catch (Exception var5) {
         }
      }

   }
}
