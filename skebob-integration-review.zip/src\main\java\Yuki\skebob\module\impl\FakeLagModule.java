package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.SliderSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.VertexConsumerProvider;
import Yuki.skebob.render.EspBoxRenderer;
import Yuki.skebob.util.Colors;

public class FakeLagModule extends Module {

    private static volatile FakeLagModule instance;

    /*
     * Gooba:
     * Default 1000 ms
     * Min      50 ms
     * Max    5000 ms
     * Step     50 ms
     */
    private final SliderSetting delay = (SliderSetting) this.addSetting(
        new SliderSetting(
            "Delay",
            "Delay before the queued packets are released",
            1000.0,
            50.0,
            5000.0,
            50.0,
            " ms"
        )
    );

    /*
     * Gooba has two choices:
     * Model / Box
     *
     * Skebob does not currently have the same string mode setting,
     * so a 0/1 slider is used and displayed as the same two names.
     */
    private final SliderSetting mode = (SliderSetting) this.addSetting(
        new SliderSetting(
            "Mode",
            "Visual mode for the delayed server position",
            0.0,
            0.0,
            1.0,
            1.0
        ).withLabel(value -> value < 0.5 ? "Model" : "Box")
    );

    /*
     * Gooba buffers general outgoing packets.
     * CopyOnWriteArrayList was used there; an ArrayList is sufficient here
     * because access is synchronized and packets are released on the client thread.
     */
    private final List<Packet<?>> queuedPackets = new ArrayList<>();

    /*
     * Prevents packets sent while flushing from immediately being queued again.
     */
    private volatile boolean flushing;

    /*
     * Next release time.
     */
    private long releaseTime;

    /*
     * Last position the server is expected to know about.
     */
    private Vec3d serverPosition = Vec3d.ZERO;
    private float serverYaw;
    private float serverPitch;
    private float serverHeadYaw;
    private float serverBodyYaw;
    private boolean serverSneaking;
    private boolean serverSprinting;

    /*
     * Bounding box at the last known server position.
     */
    private Box serverBox;

    /*
     * Fake model entity.
     */
    private FakeLagPlayerEntity fakePlayer;

    public FakeLagModule() {
        super(
            "FakeLag",
            "Delays outgoing packets and shows the delayed server position",
            Category.MISC
        );

        instance = this;
    }

    public static FakeLagModule getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        synchronized (this.queuedPackets) {
            this.queuedPackets.clear();
        }

        this.flushing = false;

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.world != null) {
            this.captureServerState();
        } else {
            this.serverPosition = Vec3d.ZERO;
            this.serverBox = null;
        }

        this.releaseTime =
            System.currentTimeMillis() + this.delay.getInt();

        this.updateVisual();
    }

    @Override
protected void onDisable() {
    this.releaseQueuedPackets();

    this.releaseTime = 0L;
    this.flushing = false;

    synchronized (this.queuedPackets) {
        this.queuedPackets.clear();
    }

    this.removeFakePlayer();
    this.serverBox = null;
}
@Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        /*
         * Gooba clears the queue and removes the visual state if
         * the player/world/network handler is unavailable.
         */
        if (
            mc.player == null ||
            mc.world == null ||
            mc.getNetworkHandler() == null
        ) {
            synchronized (this.queuedPackets) {
                this.queuedPackets.clear();
            }

            this.releaseTime = 0L;
            this.removeFakePlayer();
            this.serverBox = null;
            return;
        }

        if (this.releaseTime == 0L) {
            this.releaseTime =
                System.currentTimeMillis() + this.delay.getInt();
        }

        this.updateVisual();

        long now = System.currentTimeMillis();

        if (now >= this.releaseTime) {
            this.releaseQueuedPackets();

            /*
             * Exactly like Gooba's continuous delay loop:
             * after flushing, schedule the next release.
             */
            this.releaseTime =
                System.currentTimeMillis() + this.delay.getInt();

            /*
             * The last queued movement is now the server-side position.
             * We use the player's current state as the resulting server state.
             */
            this.captureServerState();
            this.updateVisual();
        }
    }

    /**
     * Called by the ClientConnection mixin for every outgoing packet.
     *
     * Gooba does not restrict FakeLag to PlayerMoveC2SPacket.
     * It queues general outgoing packets.
     */
    public static boolean shouldHold(Packet<?> packet) {
        FakeLagModule module = instance;

        return module != null && module.holdPacket(packet);
    }

    private boolean holdPacket(Packet<?> packet) {
        if (!this.isEnabled()) {
            return false;
        }

        if (this.flushing) {
            return false;
        }

        if (packet == null) {
            return false;
        }

        /*
         * Gooba lets PERFORM_RESPAWN through immediately.
         */
        if (packet instanceof ClientStatusC2SPacket statusPacket) {
            if (
                statusPacket.getMode()
                    == ClientStatusC2SPacket.Mode.PERFORM_RESPAWN
            ) {
                return false;
            }
        }

        MinecraftClient mc = MinecraftClient.getInstance();

        if (
            mc.player == null ||
            mc.world == null ||
            mc.getNetworkHandler() == null
        ) {
            return false;
        }

        synchronized (this.queuedPackets) {
            this.queuedPackets.add(packet);
        }

        /*
         * The mixin cancels the original send.
         */
        return true;
    }

    private void releaseQueuedPackets() {
        List<Packet<?>> copy;

        synchronized (this.queuedPackets) {
            if (this.queuedPackets.isEmpty()) {
                return;
            }

            copy = new ArrayList<>(this.queuedPackets);
            this.queuedPackets.clear();
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();

        if (
            mc.player == null ||
            mc.world == null ||
            handler == null
        ) {
            return;
        }

        /*
         * Critical:
         * handler.sendPacket(...) will hit the same Mixin again.
         * flushing=true makes shouldHold() return false.
         */
        this.flushing = true;

        try {
            for (Packet<?> packet : copy) {
                handler.sendPacket(packet);
            }
        } finally {
            this.flushing = false;
        }
    }

    /**
     * Gooba explicitly resets FakeLag state when these server packets arrive.
     */
    public void onServerLifecyclePacket(Packet<?> packet) {
        if (
            packet instanceof PlayerRespawnS2CPacket ||
            packet instanceof GameJoinS2CPacket
        ) {
            synchronized (this.queuedPackets) {
                this.queuedPackets.clear();
            }

            this.releaseTime = 0L;
            this.serverBox = null;

            this.removeFakePlayer();
        }
    }

    private void captureServerState() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null || mc.world == null) {
            return;
        }

        this.serverPosition = new net.minecraft.util.math.Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        this.serverYaw = mc.player.getYaw();
        this.serverPitch = mc.player.getPitch();
        this.serverHeadYaw = mc.player.getHeadYaw();
        this.serverBodyYaw = mc.player.getBodyYaw();
        this.serverSneaking = mc.player.isSneaking();
        this.serverSprinting = mc.player.isSprinting();

        this.serverBox = mc.player.getBoundingBox();
    }

    private boolean isModelMode() {
        return this.mode.getInt() == 0;
    }

    private boolean isBoxMode() {
        return this.mode.getInt() == 1;
    }

    private void updateVisual() {
        if (this.isModelMode()) {
            this.updateFakePlayer();
        } else {
            this.removeFakePlayer();
        }
    }

    private void updateFakePlayer() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (
            mc.world == null ||
            mc.player == null ||
            !this.isEnabled()
        ) {
            return;
        }

        if (
            this.fakePlayer == null ||
            this.fakePlayer.isRemoved() ||
            this.fakePlayer.getEntityWorld() != mc.world
        ) {
            this.removeFakePlayer();

            com.mojang.authlib.GameProfile realProfile =
                mc.player.getGameProfile();

            com.mojang.authlib.GameProfile fakeProfile =
                new com.mojang.authlib.GameProfile(
                    java.util.UUID.randomUUID(),
                    realProfile.name(),
                    new com.mojang.authlib.properties.PropertyMap(
                        realProfile.properties()
                    )
                );

            this.fakePlayer =
                new FakeLagPlayerEntity(
                    mc.world,
                    fakeProfile
                );

            this.fakePlayer.setNoGravity(true);

        this.fakePlayer.setInvisible(
            mc.options.getPerspective().isFirstPerson()
        );

            mc.world.addEntity(this.fakePlayer);
        }

        /*
         * Keep the fake model exactly at the last server-known state.
         */
        this.fakePlayer.refreshPositionAndAngles(
            this.serverPosition.x,
            this.serverPosition.y,
            this.serverPosition.z,
            this.serverYaw,
            this.serverPitch
        );

        this.fakePlayer.setHeadYaw(
            this.serverHeadYaw
        );

        this.fakePlayer.setBodyYaw(
            this.serverBodyYaw
        );

        this.fakePlayer.setSneaking(
            this.serverSneaking
        );

        this.fakePlayer.setSprinting(
            this.serverSprinting
        );

        this.fakePlayer.setNoGravity(true);

        this.fakePlayer.setInvisible(
            mc.options.getPerspective().isFirstPerson()
        );
        this.fakePlayer.setVelocity(0.0, 0.0, 0.0);

        /*
         * Copy the current equipment just like Gooba does.
         */
        for (
            net.minecraft.entity.EquipmentSlot slot :
            net.minecraft.entity.EquipmentSlot.values()
        ) {
            this.fakePlayer.equipStack(
                slot,
                mc.player.getEquippedStack(slot).copy()
            );
        }
    }

    private void removeFakePlayer() {
        if (this.fakePlayer == null) {
            return;
        }

        if (!this.fakePlayer.isRemoved()) {
            this.fakePlayer.discard();
        }

        this.fakePlayer = null;
    }

    /**
     * Box mode renderer.
     *
     * Gooba displays the stored server-position box.
     */
    public static void renderBox(
        VertexConsumerProvider.Immediate bufferSource,
        MatrixStack matrices,
        Vec3d camera
    ) {
        FakeLagModule module = instance;

        if (
            module == null ||
            !module.isEnabled() ||
            !module.isBoxMode()
        ) {
            return;
        }

        Box box = module.serverBox;

        if (box == null) {
            return;
        }

        /*
         * Gooba applies a semi-transparent client color.
         * Skebob uses its own compatible packed-color helper.
         */
        int color =
            Colors.withAlpha(
                0xFF5500,
                72.0F / 255.0F
            );

        EspBoxRenderer.outline(
            bufferSource,
            matrices,
            camera,
            box.minX,
            box.minY,
            box.minZ,
            box.maxX,
            box.maxY,
            box.maxZ,
            color,
            2.0F
        );

        EspBoxRenderer.flush(bufferSource);
    }

    public int getQueuedPacketCount() {
        synchronized (this.queuedPackets) {
            return this.queuedPackets.size();
        }
    }

    public int getDelay() {
        return this.delay.getInt();
    }

    public String getModeName() {
        return this.isModelMode()
            ? "Model"
            : "Box";
    }
}