package Yuki.skebob.render;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.hud.HudDragController;
import Yuki.skebob.hud.HudManager;
import Yuki.skebob.module.impl.MotionBlurModule;
import Yuki.skebob.notification.NotificationManager;
import Yuki.skebob.render.nanovg.GlStateSnapshot;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.util.Colors;
import com.mojang.blaze3d.textures.GpuTexture;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.opengl.GL33C;

public final class OverlayRenderer {
private static HudManager hudManager;
private static int fbo = -1;
private static boolean crashed;


private OverlayRenderer() {
}

public static void init(HudManager hud, NotificationManager toasts) {
    hudManager = hud;
}

public static float uiScale() {
    MinecraftClient mc = MinecraftClient.getInstance();
    return Math.max(
            1.0F,
            (float) mc.getWindow().getFramebufferHeight() / 1080.0F
    );
}

public static void render() {
    if (!crashed && hudManager != null) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer target = mc.getFramebuffer();

        if (target != null) {
            GpuTexture var3 = target.getColorAttachment();

            if (var3 instanceof GlTexture) {
                GlTexture colorTexture = (GlTexture) var3;
                boolean var22 = mc.currentScreen instanceof NvgDrawable;
                boolean chatEditing = mc.currentScreen instanceof ChatScreen;
                boolean drawHud =
                        !mc.options.hudHidden
                                && mc.world != null
                                && !var22;

                MotionBlurModule mbModule =
                        SkebobClient.modules() != null
                                ? SkebobClient.modules().motionBlur
                                : null;

                boolean motionBlur =
                        mbModule != null
                                && mbModule.isEnabled()
                                && mc.world != null
                                && !var22;

                if (!var22 && !drawHud && !motionBlur) {
                    return;
                }

                try {
                    GlStateSnapshot state = GlStateSnapshot.capture();

                    try {
                        if (!bindOverlayFbo(
                                colorTexture,
                                target.textureWidth,
                                target.textureHeight
                        )) {
                            return;
                        }

                        NVGRenderer vg = NVGRenderer.get();

                        if (motionBlur) {
                            MotionBlurRenderer.render(
                                    vg,
                                    target.textureWidth,
                                    target.textureHeight,
                                    mbModule
                            );
                        }

                        if (vg.hasFont()) {
                            float scale = uiScale();
                            float uiWidth =
                                    (float) target.textureWidth / scale;
                            float uiHeight =
                                    (float) target.textureHeight / scale;

                            vg.beginFrame(
                                    (float) target.textureWidth,
                                    (float) target.textureHeight,
                                    1.0F
                            );

                            vg.save();
                            vg.scale(scale);

                            if (drawHud) {
                                if (chatEditing
                                        && HudDragController.isDragging()) {
                                    HudDragController.updateDrag(vg);
                                }

                                if (mc.currentScreen == null) {
                                    WorldNametagRenderer.render(vg);
                                }

                                hudManager.render(
                                        vg,
                                        uiWidth,
                                        uiHeight
                                );

                                if (chatEditing) {
                                    renderChatEditOverlay(
                                            vg,
                                            uiWidth,
                                            uiHeight
                                    );
                                }
                            }

                            if (var22) {
                                ((NvgDrawable) mc.currentScreen).renderNvg(
                                        vg,
                                        uiMouseX(),
                                        uiMouseY(),
                                        uiWidth,
                                        uiHeight
                                );
                            }

                            vg.restore();
                            vg.endFrame();
                            return;
                        }
                    } finally {
                        state.restore();
                    }

                    return;
                } catch (Throwable var18) {
                    var18.printStackTrace();
                    crashed = true;
                    return;
                }
            }
        }
    }
}

private static void renderChatEditOverlay(
        NVGRenderer vg,
        float uiWidth,
        float uiHeight
) {
    Theme theme = SkebobClient.themes().current();
    float mx = uiMouseX();
    float my = uiMouseY();

    for (HudManager.Placement p :
            hudManager.layout(vg, uiWidth, uiHeight, true)) {

        boolean hidden = !p.component().visible();

        if (!p.contains(mx, my)
                && p.component() != HudDragController.draggedComponent()) {
            boolean var13 = false;
        } else {
            boolean var10000 = true;
        }

        if (hidden) {
            vg.save();
            vg.alpha(1.0F);
            hudManager.renderPlacement(vg, p);
            vg.restore();
        }
    }

    if (HudDragController.isDragging()) {
        int guide =
                Colors.withAlpha(theme.textPrimary(), 0.55F);

        if (HudDragController.snapCenterX()) {
            vg.line(
                    uiWidth / 2.0F,
                    0.0F,
                    uiWidth / 2.0F,
                    uiHeight,
                    1.0F,
                    guide
            );
        } else if (HudDragController.snapEdgeX()) {
            float x = mx < uiWidth / 2.0F ? 0.0F : uiWidth;

            vg.line(
                    x,
                    0.0F,
                    x,
                    uiHeight,
                    1.0F,
                    guide
            );
        }

        if (HudDragController.snapCenterY()) {
            vg.line(
                    0.0F,
                    uiHeight / 2.0F,
                    uiWidth,
                    uiHeight / 2.0F,
                    1.0F,
                    guide
            );
        } else if (HudDragController.snapEdgeY()) {
            float y = my < uiHeight / 2.0F ? 0.0F : uiHeight;

            vg.line(
                    0.0F,
                    y,
                    uiWidth,
                    y,
                    1.0F,
                    guide
            );
        }
    }
}

private static boolean bindOverlayFbo(
        GlTexture colorTexture,
        int width,
        int height
) {
    if (fbo == -1) {
        fbo = GL33C.glGenFramebuffers();
    }

    GL33C.glBindFramebuffer(36160, fbo);

    GL33C.glFramebufferTexture2D(
            36160,
            36064,
            3553,
            colorTexture.getGlId(),
            0
    );

    if (GL33C.glCheckFramebufferStatus(36160) != 36053) {
        return false;
    } else {
        GL33C.glViewport(0, 0, width, height);
        GL33C.glDisable(3089);
        return true;
    }
}

public static float uiMouseX() {
    MinecraftClient mc = MinecraftClient.getInstance();

    return (float) (
            mc.mouse.getX()
                    * (double) mc.getWindow().getFramebufferWidth()
                    / (double) Math.max(
                            1,
                            mc.getWindow().getWidth()
                    )
    ) / uiScale();
}

public static float uiMouseY() {
    MinecraftClient mc = MinecraftClient.getInstance();

    return (float) (
            mc.mouse.getY()
                    * (double) mc.getWindow().getFramebufferHeight()
                    / (double) Math.max(
                            1,
                            mc.getWindow().getHeight()
                    )
    ) / uiScale();
}

public static float guiToUi(double guiCoord) {
    MinecraftClient mc = MinecraftClient.getInstance();

    float pixels =
            (float) (
                    guiCoord
                            * mc.getWindow().getScaleFactor()
            );

    return pixels / uiScale();
}

public static float uiWidth() {
    MinecraftClient mc = MinecraftClient.getInstance();

    return (float) mc.getWindow().getFramebufferWidth()
            / uiScale();
}

public static float uiHeight() {
    MinecraftClient mc = MinecraftClient.getInstance();

    return (float) mc.getWindow().getFramebufferHeight()
            / uiScale();
}


}
