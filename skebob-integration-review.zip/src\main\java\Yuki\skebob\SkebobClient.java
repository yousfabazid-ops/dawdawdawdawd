package Yuki.skebob;

import Yuki.skebob.config.ConfigManager;
import Yuki.skebob.config.ConfigStore;
import Yuki.skebob.gui.ClickGuiScreen;
import Yuki.skebob.gui.ClickGuiState;
import Yuki.skebob.gui.GambleRiggerOverlay;
import Yuki.skebob.hud.HudManager;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.impl.FreecamModule;
import Yuki.skebob.notification.NotificationManager;
import Yuki.skebob.render.MotionBlurRenderer;
import Yuki.skebob.render.OverlayRenderer;
import Yuki.skebob.render.SusChunkRenderer;
import Yuki.skebob.spotify.SpotifyService;
import Yuki.skebob.suschunk.ServerLightCache;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.UiSoundEvents;
import Yuki.skebob.util.UiSounds;
import java.util.Objects;
import java.util.function.Supplier;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;

public class SkebobClient implements ClientModInitializer {
   public static final String MOD_ID = "SkebobClient";
   public static final String NAME = "SkebobClient";
   public static final String VERSION = "1.0.0";
   private static ModuleManager modules;
   private static ThemeManager themes;
   private static ConfigManager config;
   private static ConfigStore configStore;
   private static HudManager hud;
   private static NotificationManager notifications;
   private static SpotifyService spotify;
   private static boolean startupSoundPlayed;

   public static ModuleManager modules() {
      return modules;
   }

   public static ThemeManager themes() {
      return themes;
   }

   public static ConfigManager config() {
      return config;
   }

   public static ConfigStore configStore() {
      return configStore;
   }

   public static HudManager hud() {
      return hud;
   }

   public static SpotifyService spotify() {
      return spotify;
   }

   public static NotificationManager notifications() {
      return notifications;
   }

   public void onInitializeClient() {
      UiSoundEvents.bootstrap();
      themes = new ThemeManager();
      modules = new ModuleManager();
      spotify = new SpotifyService();
      notifications = new NotificationManager(themes, modules.hud);
      hud = new HudManager(modules, themes, spotify, notifications);
      config = new ConfigManager(modules, themes);
      ConfigManager var10000 = config;
      HudManager var10002 = hud;
      Objects.requireNonNull(var10002);
      Objects.requireNonNull(var10002);
      Supplier var4 = var10002::toJson;
      HudManager var10003 = hud;
      Objects.requireNonNull(var10003);
      Objects.requireNonNull(var10003);
      var10000.addSection("hud", var4, var10003::fromJson);
      var10000 = config;
      ClickGuiState var5 = ClickGuiScreen.state();
      Objects.requireNonNull(var5);
      Objects.requireNonNull(var5);
      Supplier var6 = var5::toJson;
      ClickGuiState var9 = ClickGuiScreen.state();
      Objects.requireNonNull(var9);
      Objects.requireNonNull(var9);
      var10000.addSection("panels", var6, var9::fromJson);
      config.load();
      configStore = new ConfigStore(config);
      configStore.loadAll();
      modules.setOpenGuiAction(() -> MinecraftClient.getInstance().setScreen(new ClickGuiScreen()));
      modules.setToggleListener((module, enabled) -> {
         if (!ConfigStore.applying && module.getCategory() != Category.CLIENT && MinecraftClient.getInstance().world != null) {
            notifications.push(module.getName(), enabled);
            if (!modules.isKeybindToggle()) {
               UiSounds.notification(enabled);
            }
         }

      });
      OverlayRenderer.init(hud, notifications);
      GambleRiggerOverlay.register();
      spotify.start();
      ClientPlayConnectionEvents.JOIN.register((ClientPlayConnectionEvents.Join)(handler, sender, client) -> clearSusState());
      ClientPlayConnectionEvents.DISCONNECT.register((ClientPlayConnectionEvents.Disconnect)(handler, client) -> clearSusState());
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> modules.onTick());
      ClientTickEvents.START_CLIENT_TICK.register((ClientTickEvents.StartTick)(client) -> {
         FreecamModule f = modules.freecam;
         if (f != null && f.isActive()) {
            FreecamModule.reapplyBodyInput(client);
         }

         modules.onCombatTick();
      });
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientLifecycleEvents.ClientStopping)(client) -> {
         config.save();
         spotify.stop();
      });
   }

   private static void clearSusState() {
      ServerLightCache.get().clear();
      modules.susChunkFinder.scanner.clear();
      modules.susChunkFinderV2.scanner.clear();
      SusChunkRenderer.reset();
      if (modules.blockEntityEsp != null) {
         modules.blockEntityEsp.clear();
      }

      if (modules.hitParticles != null) {
         modules.hitParticles.clear();
      }

      if (modules.customAccessories != null) {
         modules.customAccessories.clear();
      }

      MotionBlurRenderer.reset();
   }
}
