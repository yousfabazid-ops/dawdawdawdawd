package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FreecamModule;
import Yuki.skebob.render.BlurHook;
import Yuki.skebob.render.OverlayRenderer;
import Yuki.skebob.render.WorldProjection;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GameRenderer.class})
public class GameRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/render/GuiRenderer;incrementFrame()V",
   shift = Shift.AFTER
)}
   )
   private void SkebobClient$renderOverlay(RenderTickCounter deltaTracker, boolean bl, CallbackInfo ci) {
      OverlayRenderer.render();
   }

   @Inject(
      method = {"renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/systems/RenderSystem;setProjectionMatrix(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lcom/mojang/blaze3d/systems/ProjectionType;)V"
)}
   )
   private void SkebobClient$captureProjection(RenderTickCounter deltaTracker, CallbackInfo ci, @Local(ordinal = 0) Matrix4f matrix4f) {
      WorldProjection.capture(matrix4f, deltaTracker.getTickProgress(false));
   }

   @ModifyArg(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gl/GlobalSettings;set(IIDJLnet/minecraft/client/render/RenderTickCounter;ILnet/minecraft/client/render/Camera;Z)V"
),
      index = 5
   )
   private int SkebobClient$overrideBlurRadius(int blurriness) {
      return BlurHook.apply(blurriness);
   }

   @ModifyExpressionValue(
      method = {"renderHand"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/Perspective;isFirstPerson()Z"
)}
   )
   private boolean SkebobClient$freecamRenderFirstPersonHands(boolean isFirstPerson) {
      FreecamModule freecam = FreecamModule.get();
      return freecam != null && freecam.isActive() && freecam.renderHands() ? true : isFirstPerson;
   }
}
