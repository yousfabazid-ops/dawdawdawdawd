package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.util.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.HitResult.Type;

public class AutoToolModule extends Module {
   public AutoToolModule() {
      super("AutoTool", "Automatically selects the best hotbar tool for the block being mined", Category.MISC);
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      ClientPlayerEntity player = client.player;
      if (player != null && client.world != null && client.interactionManager != null && client.options.attackKey.isPressed() && client.crosshairTarget != null && client.crosshairTarget.getType() == Type.BLOCK) {
         BlockPos blockPos = ((BlockHitResult)client.crosshairTarget).getBlockPos();
         float currentSpeed = speed(player.getMainHandStack(), client.world.getBlockState(blockPos));
         int bestSlot = player.getInventory().getSelectedSlot();
         float bestSpeed = currentSpeed;

         for(int slot = 0; slot < 9; ++slot) {
            float candidateSpeed = speed(player.getInventory().getStack(slot), client.world.getBlockState(blockPos));
            if (candidateSpeed > bestSpeed) {
               bestSpeed = candidateSpeed;
               bestSlot = slot;
            }
         }

         if (bestSlot != player.getInventory().getSelectedSlot()) {
            InventoryHelper.selectHotbarSlot(bestSlot);
         }

      }
   }

   private static float speed(ItemStack stack, BlockState state) {
      return !stack.isEmpty() && stack.isSuitableFor(state) ? stack.getMiningSpeedMultiplier(state) : 0.0F;
   }
}
