package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerInteractionManager.class})
public class MultiPlayerGameModeAttackMixin {
   @Inject(
      method = {"attackEntity"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$onAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
      if (player == MinecraftClient.getInstance().player && target != player) {
         ModuleManager modules = SkebobClient.modules();
         if (modules != null && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            modules.hitParticles.onHit(target);
         }
      }

   }
}
