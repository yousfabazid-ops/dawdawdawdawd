package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class StrafeModule extends Module {

    private final SliderSetting intensity = (SliderSetting) this.addSetting(
        new SliderSetting(
            "Intensity",
            "Strafe strength",
            0.1,
            0.0,
            0.3,
            0.01
        )
    );

    private final BooleanSetting onlyInAir = (BooleanSetting) this.addSetting(
        new BooleanSetting(
            "Only In Air",
            "Only apply strafe while in the air",
            true
        )
    );

    public StrafeModule() {
        super(
            "Strafe",
            "Improves directional control while moving",
            Category.MISC
        );
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null) {
            return;
        }

        if (this.onlyInAir.get() && mc.player.isOnGround()) {
            return;
        }

        float forward = mc.player.forwardSpeed;
        float sideways = mc.player.sidewaysSpeed;

        if (forward == 0.0F && sideways == 0.0F) {
            return;
        }

        Vec3d velocity = mc.player.getVelocity();

        double horizontalSpeed = Math.sqrt(
            velocity.x * velocity.x +
            velocity.z * velocity.z
        );

        /*
         * If the player has no horizontal movement yet,
         * don't create movement from nothing.
         */
        if (horizontalSpeed < 1.0E-6) {
            return;
        }

        /*
         * Convert the current keyboard input into a direction.
         */
        double inputLength = Math.sqrt(
            forward * forward +
            sideways * sideways
        );

        if (inputLength < 1.0E-6) {
            return;
        }

        forward /= inputLength;
        sideways /= inputLength;

        float yaw = mc.player.getYaw();
        double radians = Math.toRadians(yaw);

        double directionX =
            -Math.sin(radians) * forward
            + Math.cos(radians) * sideways;

        double directionZ =
            Math.cos(radians) * forward
            + Math.sin(radians) * sideways;

        /*
         * Intensity controls how strongly the current
         * horizontal velocity is redirected.
         *
         * 0.0 = keep current direction
         * 0.3 = stronger correction
         */
        double strength = this.intensity.get();

        double targetX = directionX * horizontalSpeed;
        double targetZ = directionZ * horizontalSpeed;

        double newX =
            velocity.x + (targetX - velocity.x) * strength;

        double newZ =
            velocity.z + (targetZ - velocity.z) * strength;

        mc.player.setVelocity(
            newX,
            velocity.y,
            newZ
        );
    }
}

