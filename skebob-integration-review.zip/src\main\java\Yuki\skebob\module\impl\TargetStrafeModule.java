package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class TargetStrafeModule extends Module {

   public final SliderSetting range = (SliderSetting) this.addSetting(
      new SliderSetting(
         "Range",
         "Maximum distance to target",
         6.0,
         2.0,
         10.0,
         0.1,
         "m"
      )
   );

   public final SliderSetting switchDelay = (SliderSetting) this.addSetting(
      new SliderSetting(
         "Switch Delay",
         "Ticks until direction switches automatically",
         40.0,
         10.0,
         100.0,
         1.0,
         "ticks"
      )
   );

   public final BooleanSetting onlyInAir = (BooleanSetting) this.addSetting(
      new BooleanSetting(
         "Only In Air",
         "Only strafe while in the air (for bhop)",
         true
      )
   );

   public final BooleanSetting reverseOnCollision = (BooleanSetting) this.addSetting(
      new BooleanSetting(
         "Reverse On Collision",
         "Change direction when hitting a wall",
         true
      )
   );

   private boolean clockwise = true;
   private int switchTimer = 0;

   public TargetStrafeModule() {
      super(
         "TargetStrafe",
         "Strafes around the nearest player in a circle",
         Category.MISC
      );
   }

   @Override
   protected void onEnable() {
      this.clockwise = true;
      this.switchTimer = 0;
   }

   @Override
   protected void onDisable() {
      this.switchTimer = 0;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || mc.world == null) return;

      // Original-Logik: nur in der Luft
      if (this.onlyInAir.get() && mc.player.isOnGround()) return;

      PlayerEntity target = this.findTarget(mc);
      if (target == null) return;

      // Richtung wechseln nach Timer
      this.switchTimer++;
      if (this.switchTimer > this.switchDelay.get()) {
         this.clockwise = !this.clockwise;
         this.switchTimer = 0;
      }

      // Richtung wechseln bei Wandkollision (wie im Original)
      if (this.reverseOnCollision.get() && mc.player.horizontalCollision) {
         this.clockwise = !this.clockwise;
         this.switchTimer = 0;
      }

      // Original-Berechnung
      double dx = mc.player.getX() - target.getX();
      double dz = mc.player.getZ() - target.getZ();
      double angle = Math.atan2(dz, dx);

      double strafeAngle = this.clockwise
         ? angle + Math.PI / 2.0
         : angle - Math.PI / 2.0;

      Vec3d vel = mc.player.getVelocity();
      double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);

      double mx = Math.cos(strafeAngle) * speed;
      double mz = Math.sin(strafeAngle) * speed;

      mc.player.setVelocity(mx, vel.y, mz);
   }

   private PlayerEntity findTarget(MinecraftClient mc) {
      double maxRange = this.range.get();

      return mc.world.getPlayers().stream()
         .filter(p -> p != mc.player)
         .filter(p -> p.isAlive() && !p.isRemoved())
         .filter(p -> mc.player.distanceTo(p) <= maxRange)
         .findFirst()
         .orElse(null);
   }
}