package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.KeybindSetting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.util.BlockHelper;
import Yuki.skebob.util.InventoryHelper;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public class DoubleAnchorModule extends Module {
   public final KeybindSetting activateKey = (KeybindSetting)this.addSetting(new KeybindSetting("Activate Key", "Hold to run the combo", 72));
   public final SliderSetting timing = (SliderSetting)this.addSetting(new SliderSetting("Timing", "Delay between the two blows", (double)120.0F, (double)40.0F, (double)400.0F, (double)10.0F, "ms"));
   public final SliderSetting detonateSlot = (SliderSetting)this.addSetting(new SliderSetting("Detonate Slot", "Hotbar slot to hold while detonating (anything but glowstone)", (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   public final BooleanSetting rePlace = (BooleanSetting)this.addSetting(new BooleanSetting("Re-Place", "Place a fresh anchor for the second blow if the first is consumed", true));
   public final BooleanSetting switchBack = (BooleanSetting)this.addSetting(new BooleanSetting("Switch Back", "Return to the previous hotbar slot when done", true));
   private int step;
   private int tickCounter;
   private BlockPos targetPos;
   private int previousSlot = -1;

   public DoubleAnchorModule() {
      super("Double Anchor", "Two rapid anchor chargeâ†’detonate cycles", Category.COMBAT);
   }

   protected void onEnable() {
      this.resetState();
   }

   protected void onDisable() {
      this.resetState();
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null && client.world != null && client.currentScreen == null) {
         if (this.step > 0) {
            this.processStep(client);
         } else if (this.keyDown(client)) {
            HitResult var3 = client.crosshairTarget;
            if (var3 instanceof BlockHitResult) {
               BlockHitResult hit = (BlockHitResult)var3;
               if (hit.getType() == Type.BLOCK) {
                  BlockPos pos = hit.getBlockPos();
                  if (!BlockHelper.isBlockAt(pos, Blocks.RESPAWN_ANCHOR)) {
                     return;
                  }

                  this.targetPos = pos.toImmutable();
                  this.previousSlot = client.player.getInventory().getSelectedSlot();
                  this.step = 1;
                  this.tickCounter = 0;
                  return;
               }
            }
         }
      } else if (this.step != 0) {
         this.resetState();
      }

   }

   private void processStep(MinecraftClient client) {
      ++this.tickCounter;
      HitResult var4 = client.crosshairTarget;
      BlockHitResult var10000;
      if (var4 instanceof BlockHitResult bhr) {
         var10000 = bhr;
      } else {
         var10000 = null;
      }

      switch (this.step) {
         case 1:
            if (!this.lookingAtTarget(var10000)) {
               this.resetState();
               return;
            }

            if (BlockHelper.isAnchorUncharged(this.targetPos)) {
               InventoryHelper.swapToItem(Items.GLOWSTONE);
               BlockHelper.interactBlock(var10000, true);
            }

            this.advance(2);
            break;
         case 2:
            if (!this.lookingAtTarget(var10000)) {
               this.resetState();
               return;
            }

            InventoryHelper.swap(this.detonateSlot.getInt() - 1);
            BlockHelper.interactBlock(var10000, true);
            this.advance(3);
            break;
         case 3:
            if (this.tickCounter >= this.gapTicks()) {
               this.advance(4);
            }
            break;
         case 4:
            if (BlockHelper.isBlockAt(this.targetPos, Blocks.RESPAWN_ANCHOR)) {
               if (this.lookingAtTarget(var10000) && BlockHelper.isAnchorUncharged(this.targetPos)) {
                  InventoryHelper.swapToItem(Items.GLOWSTONE);
                  BlockHelper.interactBlock(var10000, true);
               }

               this.advance(5);
            } else if ((Boolean)this.rePlace.get() && var10000 != null && InventoryHelper.getHotbarSlot(Items.RESPAWN_ANCHOR) >= 0) {
               InventoryHelper.swapToItem(Items.RESPAWN_ANCHOR);
               BlockHelper.interactBlock(var10000, true);
               this.targetPos = var10000.getBlockPos().offset(var10000.getSide()).toImmutable();
               this.advance(6);
            } else {
               this.finish(client);
            }
            break;
         case 5:
            if (this.lookingAtTarget(var10000) && BlockHelper.isBlockAt(this.targetPos, Blocks.RESPAWN_ANCHOR)) {
               InventoryHelper.swap(this.detonateSlot.getInt() - 1);
               BlockHelper.interactBlock(var10000, true);
            }

            this.finish(client);
            break;
         case 6:
            if (BlockHelper.isBlockAt(this.targetPos, Blocks.RESPAWN_ANCHOR)) {
               InventoryHelper.swapToItem(Items.GLOWSTONE);
               if (var10000 != null) {
                  BlockHelper.interactBlock(var10000, true);
               }

               this.advance(5);
            } else {
               this.finish(client);
            }
            break;
         default:
            this.finish(client);
      }

   }

   private boolean lookingAtTarget(BlockHitResult live) {
      return live != null && live.getType() == Type.BLOCK && live.getBlockPos().equals(this.targetPos);
   }

   private void advance(int next) {
      this.step = next;
      this.tickCounter = 0;
   }

   private int gapTicks() {
      return Math.max(1, this.timing.getInt() / 50);
   }

   private void finish(MinecraftClient client) {
      if ((Boolean)this.switchBack.get() && this.previousSlot >= 0) {
         InventoryHelper.swap(this.previousSlot);
      }

      this.resetState();
   }

   private boolean keyDown(MinecraftClient client) {
      int key = (Integer)this.activateKey.get();
      if (key == -1) {
         return false;
      } else {
         long handle = client.getWindow().getHandle();
         return key <= 7 ? GLFW.glfwGetMouseButton(handle, key) == 1 : GLFW.glfwGetKey(handle, key) == 1;
      }
   }

   private void resetState() {
      this.step = 0;
      this.tickCounter = 0;
      this.targetPos = null;
      this.previousSlot = -1;
   }
}
