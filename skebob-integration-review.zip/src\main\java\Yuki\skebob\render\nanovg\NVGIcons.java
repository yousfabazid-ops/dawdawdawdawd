package Yuki.skebob.render.nanovg;

import Yuki.skebob.module.Category;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.nanovg.NSVGImage;
import org.lwjgl.nanovg.NanoSVG;
import org.lwjgl.nanovg.NanoVG;
import org.lwjgl.system.MemoryUtil;

public final class NVGIcons {
private static final int RASTER_SIZE = 64;
private static final Map<String, Integer> ICONS = new HashMap();
private static boolean loaded;
private static int brand = -1;

private NVGIcons() {
}

public static int get(Category category) {
ensureLoaded();
return (Integer)ICONS.getOrDefault(category.getIconId(), -1);
}

public static int brand() {
ensureLoaded();
return brand;
}

private static void ensureLoaded() {
if (!loaded) {
loaded = true;

     for (Category category : Category.values()) {
        int handle = loadSvg("assets/skebob/icons/" + category.getIconId() + ".svg");

        if (handle > 0) {
           ICONS.put(category.getIconId(), handle);
        } else {
           System.err.println(
              "[SkebobClient] Failed to load category icon: "
                 + category.name()
                 + " -> "
                 + category.getIconId()
           );
        }
     }

     brand = loadSvg("assets/skebob/icons/brand.svg");

     if (brand <= 0) {
        System.err.println("[SkebobClient] Failed to load brand.svg");
     }
  }

}

private static int loadSvg(String resourcePath) {
long ctx = NVGRenderer.get().ctx();

  try {
     InputStream in = NVGIcons.class.getClassLoader().getResourceAsStream(resourcePath);

     if (in == null) {
        System.err.println("[SkebobClient] SVG resource not found: " + resourcePath);
        return -1;
     }

     String svg;

     try {
        svg = new String(in.readAllBytes(), StandardCharsets.UTF_8);
     } finally {
        in.close();
     }

     svg = svg
        .replaceAll("#[0-9a-fA-F]{6}", "#ffffff")
        .replaceAll("#[0-9a-fA-F]{3}\\b", "#fff")
        .replace("currentColor", "#ffffff")
        .replace("\"black\"", "\"white\"");

     ByteBuffer svgData = MemoryUtil.memUTF8(svg, true);
     ByteBuffer units = MemoryUtil.memASCII("px");

     NSVGImage image = null;
     long rasterizer = 0L;
     ByteBuffer pixels = null;

     try {
        image = NanoSVG.nsvgParse(svgData, units, 96.0F);

        if (image == null) {
           System.err.println("[SkebobClient] NanoSVG failed to parse: " + resourcePath);
           return -1;
        }

        rasterizer = NanoSVG.nsvgCreateRasterizer();

        if (rasterizer == 0L) {
           System.err.println("[SkebobClient] NanoSVG failed to create rasterizer: " + resourcePath);
           return -1;
        }

        float width = image.width();
        float height = image.height();

        if (width <= 0.0F || height <= 0.0F) {
           System.err.println(
              "[SkebobClient] Invalid SVG dimensions: "
                 + resourcePath
                 + " ("
                 + width
                 + "x"
                 + height
                 + ")"
           );
           return -1;
        }

        float scale = (float)RASTER_SIZE / Math.max(width, height);

        pixels = MemoryUtil.memAlloc(RASTER_SIZE * RASTER_SIZE * 4);

        NanoSVG.nsvgRasterize(
           rasterizer,
           image,
           0.0F,
           0.0F,
           scale,
           pixels,
           RASTER_SIZE,
           RASTER_SIZE,
           RASTER_SIZE * 4
        );

        int handle = NanoVG.nvgCreateImageRGBA(
           ctx,
           RASTER_SIZE,
           RASTER_SIZE,
           0,
           pixels
        );

        if (handle <= 0) {
           System.err.println(
              "[SkebobClient] NanoVG failed to create image: " + resourcePath
           );
           return -1;
        }

        return handle;
     } finally {
        if (pixels != null) {
           MemoryUtil.memFree(pixels);
        }

        if (rasterizer != 0L) {
           NanoSVG.nsvgDeleteRasterizer(rasterizer);
        }

        if (image != null) {
           NanoSVG.nsvgDelete(image);
        }

        MemoryUtil.memFree(svgData);
        MemoryUtil.memFree(units);
     }
  } catch (Throwable throwable) {
     System.err.println(
        "[SkebobClient] Exception while loading SVG: " + resourcePath
     );
     throwable.printStackTrace();
     return -1;
  }

}
}
