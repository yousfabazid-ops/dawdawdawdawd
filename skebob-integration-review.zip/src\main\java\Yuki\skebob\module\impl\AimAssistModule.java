package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.ModeSetting;
import Yuki.skebob.settings.SliderSetting;

import java.util.Comparator;
import java.util.List;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class AimAssistModule extends Module {

   public final SliderSetting range =
      (SliderSetting)this.addSetting(new SliderSetting(
         "Range",
         "Maximum distance for targets",
         4.5,
         1.0,
         6.0,
         0.1,
         "m"
      ));

   public final SliderSetting fov =
      (SliderSetting)this.addSetting(new SliderSetting(
         "FOV",
         "FOV used when selecting a new target",
         100.0,
         10.0,
         180.0,
         1.0,
         "Â°"
      ));

   public final SliderSetting smoothness =
      (SliderSetting)this.addSetting(new SliderSetting(
         "Smoothness",
         "0 = instant aim, higher = smoother",
         3.0,
         0.0,
         16.0,
         0.5
      ));

   public final ModeSetting aimPoint =
      (ModeSetting)this.addSetting(new ModeSetting(
         "Aim Point",
         "Where to aim on the target",
         "Chest",
         "Chest",
         "Head",
         "Feet"
      ));

   public final ModeSetting targetMode =
      (ModeSetting)this.addSetting(new ModeSetting(
         "Target Mode",
         "Types of entities that can be targeted",
         "Players",
         "Players",
         "Hostiles",
         "Mobs",
         "Everything"
      ));

   public final BooleanSetting targetLock =
      (BooleanSetting)this.addSetting(new BooleanSetting(
         "Target Lock",
         "Keeps the current target outside the FOV",
         true
      ));

   public final BooleanSetting throughWalls =
      (BooleanSetting)this.addSetting(new BooleanSetting(
         "Through Walls",
         "Allows aiming at targets behind blocks",
         false
      ));

   public final BooleanSetting teams =
      (BooleanSetting)this.addSetting(new BooleanSetting(
         "Teams",
         "Allow targeting players on the same team",
         false
      ));

   private LivingEntity currentTarget;

   public AimAssistModule() {
      super(
         "AimAssist",
         "Aims toward nearby targets with target lock",
         Category.COMBAT
      );
   }

   @Override
   protected void onEnable() {
      this.currentTarget = null;
   }

   @Override
   protected void onDisable() {
      this.currentTarget = null;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();

      if (mc.player == null
            || mc.world == null
            || mc.currentScreen != null) {

         this.currentTarget = null;
         return;
      }

      if (this.currentTarget != null
            && this.targetLock.get()
            && this.isValidLockedTarget(this.currentTarget)) {

         this.aimAt(mc, this.currentTarget);
         return;
      }

      this.currentTarget = this.findBestTarget();

      if (this.currentTarget == null) {
         return;
      }

      this.aimAt(mc, this.currentTarget);
   }

   private LivingEntity findBestTarget() {
      MinecraftClient mc = MinecraftClient.getInstance();

      double maxRange = this.range.get();

      Box searchBox =
         mc.player.getBoundingBox().expand(maxRange);

      List<LivingEntity> entities =
         mc.world.getEntitiesByClass(
            LivingEntity.class,
            searchBox,
            entity -> this.isValidTarget(entity)
         );

      return entities.stream()
         .filter(this::isInsideFov)
         .min(
            Comparator
               .comparingDouble(
                  (LivingEntity entity) ->
                     this.getAngleDifference(entity)
               )
               .thenComparingDouble(
                  entity ->
                     mc.player.distanceTo(entity)
               )
         )
         .orElse(null);
   }

   private boolean isValidLockedTarget(
         LivingEntity entity
   ) {
      MinecraftClient mc =
         MinecraftClient.getInstance();

      if (entity == null
            || entity == mc.player
            || !entity.isAlive()
            || entity.isRemoved()) {
         return false;
      }

      if (mc.player.distanceTo(entity)
            > this.range.getFloat()) {
         return false;
      }

      if (!this.throughWalls.get()
            && !mc.player.canSee(entity)) {
         return false;
      }

      return this.isTargetTypeAllowed(entity);
   }

   private boolean isValidTarget(
         LivingEntity entity
   ) {
      MinecraftClient mc =
         MinecraftClient.getInstance();

      if (entity == null
            || entity == mc.player
            || !entity.isAlive()
            || entity.isRemoved()) {
         return false;
      }

      if (mc.player.distanceTo(entity)
            > this.range.getFloat()) {
         return false;
      }

      if (!this.throughWalls.get()
            && !mc.player.canSee(entity)) {
         return false;
      }

      return this.isTargetTypeAllowed(entity);
   }

   private boolean isTargetTypeAllowed(
         LivingEntity entity
   ) {
      MinecraftClient mc =
         MinecraftClient.getInstance();

      if (entity instanceof PlayerEntity) {
         PlayerEntity player =
            (PlayerEntity)entity;

         if (!this.teams.get()
               && mc.player.getScoreboardTeam() != null
               && mc.player.getScoreboardTeam()
                     .equals(player.getScoreboardTeam())) {
            return false;
         }

         return this.targetMode.is("Players")
            || this.targetMode.is("Everything");
      }

      if (entity instanceof HostileEntity) {
         return this.targetMode.is("Hostiles")
            || this.targetMode.is("Mobs")
            || this.targetMode.is("Everything");
      }

      return this.targetMode.is("Mobs")
         || this.targetMode.is("Everything");
   }

   private boolean isInsideFov(
         LivingEntity entity
   ) {
      return this.getAngleDifference(entity)
         <= this.fov.getFloat() * 0.5F;
   }

   private double getAngleDifference(
         LivingEntity entity
   ) {
      MinecraftClient mc =
         MinecraftClient.getInstance();

      Vec3d eye =
         mc.player.getEyePos();

      Vec3d target =
         this.getAimPoint(entity);

      double dx =
         target.x - eye.x;

      double dz =
         target.z - eye.z;

      double targetYaw =
         Math.toDegrees(
            Math.atan2(dz, dx)
         ) - 90.0;

      return Math.abs(
         wrapDegrees(
            targetYaw
               - mc.player.getYaw()
         )
      );
   }

   private void aimAt(
         MinecraftClient mc,
         LivingEntity target
   ) {
      Vec3d eye =
         mc.player.getEyePos();

      Vec3d aim =
         this.getAimPoint(target);

      double dx =
         aim.x - eye.x;

      double dy =
         aim.y - eye.y;

      double dz =
         aim.z - eye.z;

      double horizontal =
         Math.sqrt(
            dx * dx + dz * dz
         );

      if (horizontal < 0.0001) {
         return;
      }

      float targetYaw =
         (float)(
            Math.toDegrees(
               Math.atan2(dz, dx)
            ) - 90.0
         );

      float targetPitch =
         (float)(
            -Math.toDegrees(
               Math.atan2(
                  dy,
                  horizontal
               )
            )
         );

      /*
       * 0 = sofortige Rotation.
       */
      if (this.smoothness.get() <= 0.0) {
         mc.player.setYaw(targetYaw);

         mc.player.setPitch(
            clamp(
               targetPitch,
               -90.0F,
               90.0F
            )
         );

         return;
      }

      /*
       * Smooth rotation.
       *
       * Es gibt absichtlich keinen Turn-Speed-Regler mehr.
       * Die Bewegung wird direkt anhand der Differenz
       * berechnet und lÃ¤uft dadurch gleichmÃ¤ÃŸig zum Ziel.
       */
      float yawDifference =
         (float)wrapDegrees(
            (double)targetYaw
               - mc.player.getYaw()
         );

      float pitchDifference =
         targetPitch
            - mc.player.getPitch();

      double smooth =
         this.smoothness.get();

      /*
       * Je kleiner der Wert, desto direkter.
       * Je grÃ¶ÃŸer der Wert, desto weicher.
       */
      double factor =
         1.0 / Math.max(1.0, smooth);

      float yawStep =
         (float)(yawDifference * factor);

      float pitchStep =
         (float)(pitchDifference * factor);

      /*
       * Verhindert winzige Restbewegungen.
       */
      if (Math.abs(yawDifference) < 0.05F) {
         yawStep = yawDifference;
      }

      if (Math.abs(pitchDifference) < 0.05F) {
         pitchStep = pitchDifference;
      }

      mc.player.setYaw(
         mc.player.getYaw()
            + yawStep
      );

      mc.player.setPitch(
         clamp(
            mc.player.getPitch()
               + pitchStep,
            -90.0F,
            90.0F
         )
      );
   }

   private Vec3d getAimPoint(
         LivingEntity entity
   ) {
      Box box =
         entity.getBoundingBox();

      double x =
         (box.minX + box.maxX)
            * 0.5;

      double z =
         (box.minZ + box.maxZ)
            * 0.5;

      double y;

      if (this.aimPoint.is("Head")) {
         y =
            box.maxY - 0.15;
      } else if (this.aimPoint.is("Feet")) {
         y =
            box.minY + 0.1;
      } else {
         y =
            box.minY
            + (box.maxY - box.minY)
               * 0.55;
      }

      return new Vec3d(
         x,
         y,
         z
      );
   }

   private static double wrapDegrees(
         double value
   ) {
      value %= 360.0;

      if (value >= 180.0) {
         value -= 360.0;
      }

      if (value < -180.0) {
         value += 360.0;
      }

      return value;
   }

   private static float clamp(
         float value,
         float min,
         float max
   ) {
      return Math.max(
         min,
         Math.min(
            max,
            value
         )
      );
   }
}