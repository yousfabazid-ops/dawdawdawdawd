package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.ModeSetting;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextContent;
import net.minecraft.text.PlainTextContent;

public class FakeRolesModule extends Module {
   public static final String ROLE_NONE = "None";
   public static final String ROLE_MOD = "Mod";
   public static final String ROLE_MEDIA = "MEDIA";
   private static final int GRAY = 8355711;
   private static final int GREEN = 5635925;
   private static final int PINK = 16733695;
   private static final int RED = 16733269;
   private static final int WHITE = 16777215;
   public final ModeSetting role = (ModeSetting)this.addSetting(new ModeSetting("Role", "Which fake rank tag to wear in front of your name", "None", new String[]{"None", "Mod", "MEDIA"}));

   public FakeRolesModule() {
      super("FakeRoles", "Fake [Mod] / [MEDIA] rank tag on your own name", Category.MISC);
   }

   public boolean isActive() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return this.isEnabled() && !this.role.is("None") && mc.player != null;
   }

   private String selfName() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player == null ? null : mc.player.getGameProfile().name();
   }

   private boolean isSelf(String exactName) {
      String me = this.selfName();
      return me != null && !me.isEmpty() && me.equals(exactName);
   }

   private int roleColor() {
      String value = (String)this.role.get();
      if (!value.equals("Mod") && !value.equals("SR.MOD")) {
         return value.equals("MEDIA") ? 16733695 : 16777215;
      } else {
         return 5635925;
      }
   }

   private Style bracketStyle() {
      return Style.EMPTY.withColor(8355711).withBold(false);
   }

   private Style tagStyle() {
      return Style.EMPTY.withColor(this.roleColor()).withBold(true);
   }

   private Style nameStyle() {
      String value = (String)this.role.get();
      if (!value.equals("Mod") && !value.equals("SR.MOD")) {
         return value.equals("MEDIA") ? Style.EMPTY.withColor(16777215).withBold(false) : Style.EMPTY;
      } else {
         return Style.EMPTY.withColor(5635925).withBold(true);
      }
   }

   public Text tagComponent() {
      return Text.empty().append(Text.literal("[").setStyle(this.bracketStyle())).append(Text.literal((String)this.role.get()).setStyle(this.tagStyle())).append(Text.literal("] ").setStyle(this.bracketStyle()));
   }

   public Text buildPrefixedDisplayName(String name) {
      return this.isActive() && name != null ? Text.empty().append(this.tagComponent()).append(Text.literal(name).setStyle(this.nameStyle())) : null;
   }

   public Text decorateNametag(Text tag) {
      return this.isActive() ? this.modifyText(tag) : tag;
   }

   public Text decorateTab(Text display, String realName) {
      if (this.isActive()) {
         Text prefixed = this.isSelf(realName) ? this.buildPrefixedDisplayName(realName) : null;
         return prefixed != null ? prefixed : display;
      } else {
         return display;
      }
   }

   public Text decorateChat(Text input) {
      return this.isActive() ? this.modifyText(input) : input;
   }

   private Text modifyText(Text input) {
      if (input == null) {
         return null;
      } else {
         String me = this.selfName();
         return me != null && !me.isBlank() && input.getString().contains(me) ? this.splice(input, me, new boolean[]{false}) : input;
      }
   }

   private Text splice(Text c, String name, boolean[] done) {
      TextContent contents = c.getContent();
      MutableText result;
      if (!done[0] && contents instanceof PlainTextContent ptc) {
         String text = ptc.string();
         int idx = text.indexOf(name);
         if (idx >= 0) {
            done[0] = true;
            result = Text.empty();
            if (idx > 0) {
               result.append(Text.literal(text.substring(0, idx)).setStyle(c.getStyle()));
            }

            result.append(this.buildPrefixedDisplayName(name));
            int end = idx + name.length();
            if (end < text.length()) {
               result.append(Text.literal(text.substring(end)).setStyle(c.getStyle()));
            }
         } else {
            result = MutableText.of(contents).setStyle(c.getStyle());
         }
      } else if (!done[0] && contents instanceof TranslatableTextContent tc) {
         Object[] args = tc.getArgs();
         Object[] out = new Object[args.length];

         for(int i = 0; i < args.length; ++i) {
            Object arg = args[i];
            if (arg instanceof Text ac) {
               out[i] = this.splice(ac, name, done);
            } else {
               if (!done[0] && arg instanceof String s) {
                  if (s.contains(name)) {
                     done[0] = true;
                     int idx = s.indexOf(name);
                     MutableText split = Text.empty();
                     if (idx > 0) {
                        split.append(Text.literal(s.substring(0, idx)));
                     }

                     split.append(this.buildPrefixedDisplayName(name));
                     int end = idx + name.length();
                     if (end < s.length()) {
                        split.append(Text.literal(s.substring(end)));
                     }

                     out[i] = split;
                     continue;
                  }
               }

               out[i] = arg;
            }
         }

         result = MutableText.of(new TranslatableTextContent(tc.getKey(), tc.getFallback(), out)).setStyle(c.getStyle());
      } else {
         result = MutableText.of(contents).setStyle(c.getStyle());
      }

      for(Text sibling : c.getSiblings()) {
         result.append(this.splice(sibling, name, done));
      }

      return result;
   }
}
