package Yuki.skebob.render;

import Yuki.skebob.module.impl.FreecamModule;
import Yuki.skebob.module.impl.StorageEspModule;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BrewingStandBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.DropperBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.block.AbstractFurnaceBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.SpawnerBlock;
import net.minecraft.block.TrappedChestBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.ChestType;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.client.MinecraftClient;
import net.minecraft.block.BarrelBlock;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class StorageEspRenderer {
   private static final int MAX_CHUNK_RADIUS = 16;
   private static final int MAX_RESULTS = 1500;
   private static final int MAX_RENDERED = 32;
   private static final float BOX_INFLATE = 0.002F;
   private static final double CHEST_INSET = (double)0.0625F;
   private static final int INTERACTED_RGB = 6579300;
   private static final float LINE_WIDTH = 1.0F;
   private static final float TRACER_WIDTH = 1.15F;
   private static final int TRACER_ALPHA = 180;
   private static final IncrementalScan<Hit> SCAN = new IncrementalScan<Hit>(20, 20000, 10);

   private StorageEspRenderer() {
   }

   public static int cachedCount() {
      return SCAN.get().size();
   }

   public static long cachedShulkerCount() {
      return SCAN.get().stream().filter((h) -> h.type() == StorageEspModule.StorageType.SHULKER).count();
   }

   public static void resetScan() {
      SCAN.clear();
   }

   public static void scan(StorageEspModule module) {
      MinecraftClient client = MinecraftClient.getInstance();
      Vec3d camOrigin = client.gameRenderer.getCamera().getCameraPos();
      FreecamModule freecam = FreecamModule.get();
      Vec3d origin;
      if (freecam == null || !freecam.isActive()) {
         origin = client.player != null ? client.player.getEntityPos() : camOrigin;
      } else {
         origin = camOrigin;
      }

      double range = (Double)module.range.get();
      double rangeSq = range * range;
      int wanted = (int)Math.ceil(range / (double)16.0F) + 1;
      int chunkRadius = Math.min(16, wanted);
      int centerChunkX = (int)Math.floor(origin.x) >> 4;
      int centerChunkZ = (int)Math.floor(origin.z) >> 4;
      SCAN.tick(chunkRadius, centerChunkX, centerChunkZ, (chunk, out) -> scanChunk(chunk, origin, rangeSq, out));
   }

   private static int scanChunk(WorldChunk chunk, Vec3d origin, double rangeSq, List<Hit> out) {
      if (MinecraftClient.getInstance().player == null) {
         return 0;
      } else {
         Map<BlockPos, BlockEntity> blockEntities = chunk.getBlockEntities();
         int added = 0;

         for(Map.Entry<BlockPos, BlockEntity> entry : blockEntities.entrySet()) {
            if (out.size() >= 1500) {
               return added;
            }

            BlockPos pos = (BlockPos)entry.getKey();
            StorageEspModule.StorageType type = classify(chunk.getBlockState(pos).getBlock());
            if (type != null) {
               double dx = origin.x - ((double)pos.getX() + (double)0.5F);
               double dz = origin.z - ((double)pos.getZ() + (double)0.5F);
               if (!(dx * dx + dz * dz > rangeSq)) {
                  out.add(new Hit(pos.getX(), pos.getY(), pos.getZ(), type));
                  ++added;
               }
            }
         }

         ChunkSection[] sections = chunk.getSectionArray();
         int bottomY = chunk.getBottomY();

         for(int si = 0; si < sections.length; ++si) {
            ChunkSection section = sections[si];
            if (section != null && !section.isEmpty() && out.size() < 1500) {
               int sectionY = bottomY + si * 16;

               for(int lx = 0; lx < 16; ++lx) {
                  for(int lz = 0; lz < 16; ++lz) {
                     for(int ly = 0; ly < 16; ++ly) {
                        if (out.size() >= 1500) {
                           return added;
                        }

                        BlockPos pos = new BlockPos(chunk.getPos().getStartX() + lx, sectionY + ly, chunk.getPos().getStartZ() + lz);
                        BlockState state = section.getBlockState(lx, ly, lz);
                        if (!state.hasBlockEntity()) {
                           StorageEspModule.StorageType type = classify(state.getBlock());
                           if (type != null) {
                              double dx = origin.x - ((double)pos.getX() + (double)0.5F);
                              double dz = origin.z - ((double)pos.getZ() + (double)0.5F);
                              if (!(dx * dx + dz * dz > rangeSq)) {
                                 out.add(new Hit(pos.getX(), pos.getY(), pos.getZ(), type));
                                 ++added;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return added;
      }
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, StorageEspModule module) {
      List<Hit> snapshot = SCAN.get();
      if (!snapshot.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         ClientWorld level = mc.world;
         if (level != null) {
            boolean fill = true;
            int alphaBits = ((Number)module.highlightAlpha.get()).intValue() << 24;
            int rendered = 0;
            boolean tracers = (Boolean)module.tracers.get();
            Vector3fc forward = new Vector3f(0.0F, 0.0F, 0.0F);
            if (tracers && mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
               forward = mc.gameRenderer.getCamera().getHorizontalPlane();
            }

            BlockPos.Mutable renderPos = new BlockPos.Mutable();
            double maxDistSq = ((Number)module.range.get()).doubleValue();
            maxDistSq *= maxDistSq;

            for(Hit hit : snapshot) {
               if (rendered >= 32) {
                  break;
               }

               double dx = (double)hit.x() + (double)0.5F - cam.x;
               double dz = (double)hit.z() + (double)0.5F - cam.z;
               if (!(dx * dx + dz * dz > maxDistSq)) {
                  StorageEspModule.StorageType type = hit.type();
                  if (module.isTypeEnabled(type)) {
                     renderPos.set(hit.x(), hit.y(), hit.z());
                     boolean interacted = module.isInteracted(renderPos);
                     int rgb = interacted ? 6579300 : module.colorFor(type) & 16777215;
                     int color = alphaBits | rgb;
                     double x1 = (double)hit.x();
                     double y1 = (double)hit.y();
                     double z1 = (double)hit.z();
                     double x2 = x1 + (double)1.0F;
                     double y2 = y1 + (double)1.0F;
                     double z2 = z1 + (double)1.0F;
                     if (type == StorageEspModule.StorageType.CHEST || type == StorageEspModule.StorageType.TRAPPED || type == StorageEspModule.StorageType.ENDER) {
                        x1 += (double)0.0625F;
                        z1 += (double)0.0625F;
                        x2 -= (double)0.0625F;
                        y2 -= (double)0.125F;
                        z2 -= (double)0.0625F;
                        if (type == StorageEspModule.StorageType.CHEST || type == StorageEspModule.StorageType.TRAPPED) {
                           BlockState st = level.getBlockState(renderPos);
                           if (st.getBlock() instanceof ChestBlock && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                              Direction facing = (Direction)st.get(ChestBlock.FACING);
                              ChestType ct = (ChestType)st.get(ChestBlock.CHEST_TYPE);
                              Direction nb = ct == ChestType.LEFT ? facing.rotateYClockwise() : facing.rotateYCounterclockwise();
                              if (nb == Direction.WEST) {
                                 x1 = (double)hit.x();
                              } else if (nb == Direction.EAST) {
                                 x2 = (double)hit.x() + (double)2.0F - (double)0.0625F;
                              } else if (nb == Direction.NORTH) {
                                 z1 = (double)hit.z();
                              } else if (nb == Direction.SOUTH) {
                                 z2 = (double)hit.z() + (double)2.0F - (double)0.0625F;
                              }
                           }
                        }
                     }

                     if (fill) {
                        EspBoxRenderer.fill(bufferSource, poseStack, cam, x1 - (double)0.002F, y1 - (double)0.002F, z1 - (double)0.002F, x2 + (double)0.002F, y2 + (double)0.002F, z2 + (double)0.002F, color);
                     } else {
                        EspBoxRenderer.outline(bufferSource, poseStack, cam, x1, y1, z1, x2, y2, z2, color, 1.0F);
                     }

                     if (tracers) {
                        int tracerColor = -1275068416 | rgb;
                        EspBoxRenderer.tracer(bufferSource, poseStack, cam, forward, (x1 + x2) * (double)0.5F, (y1 + y2) * (double)0.5F, (z1 + z2) * (double)0.5F, tracerColor, 1.15F);
                     }

                     ++rendered;
                  }
               }
            }

            EspBoxRenderer.flush(bufferSource);
         }
      }

   }

   private static boolean isStorage(BlockState state) {
      return classify(state.getBlock()) != null;
   }

   private static StorageEspModule.StorageType classify(Block b) {
      if (b instanceof TrappedChestBlock) {
         return StorageEspModule.StorageType.TRAPPED;
      } else if (b instanceof ChestBlock) {
         return StorageEspModule.StorageType.CHEST;
      } else if (b instanceof EnderChestBlock) {
         return StorageEspModule.StorageType.ENDER;
      } else if (b instanceof ShulkerBoxBlock) {
         return StorageEspModule.StorageType.SHULKER;
      } else if (b instanceof BarrelBlock) {
         return StorageEspModule.StorageType.BARREL;
      } else if (b instanceof SpawnerBlock) {
         return StorageEspModule.StorageType.SPAWNER;
      } else if (b instanceof HopperBlock) {
         return StorageEspModule.StorageType.HOPPER;
      } else if (b instanceof AbstractFurnaceBlock) {
         return StorageEspModule.StorageType.FURNACE;
      } else if (b instanceof BrewingStandBlock) {
         return StorageEspModule.StorageType.BREWING_STAND;
      } else if (b instanceof DispenserBlock) {
         return StorageEspModule.StorageType.DISPENSER;
      } else {
         return b instanceof DropperBlock ? StorageEspModule.StorageType.DROPPER : null;
      }
   }

   public static record Hit(int x, int y, int z, StorageEspModule.StorageType type) {
   }
}
