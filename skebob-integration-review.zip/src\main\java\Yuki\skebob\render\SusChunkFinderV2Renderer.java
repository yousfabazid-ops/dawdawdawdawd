package Yuki.skebob.render;

import Yuki.skebob.module.impl.SusChunkFinderV2Module;
import Yuki.skebob.util.Colors;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

/** Renderer dedicated to Sus Chunk Finder V2. */
public final class SusChunkFinderV2Renderer {
    private static final int SUS_RED = 0xFF0000;

    private SusChunkFinderV2Renderer() {
    }

    public static void render(VertexConsumerProvider.Immediate bufferSource,
                              MatrixStack poseStack,
                              Vec3d camera,
                              SusChunkFinderV2Module module) {
        int alpha = Math.max(10, Math.min(255, module.alpha.getInt()));
        float strength = Math.min(1.0F, alpha / 255.0F);
        for (long key : module.scanner.suspiciousChunks()) {
            ChunkPos pos = new ChunkPos(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key));
            FlatOverlay.fillQuad(
                bufferSource,
                poseStack,
                camera,
                pos.getStartX(),
                pos.getStartZ(),
                pos.getStartX() + 16.0,
                pos.getStartZ() + 16.0,
                47.0,
                Colors.withAlpha(SUS_RED, strength)
            );
        }
        FlatOverlay.flush(bufferSource);
    }
}