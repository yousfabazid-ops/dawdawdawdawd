package Yuki.skebob.render;

import Yuki.skebob.module.Modules;
import Yuki.skebob.util.Colors;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import org.joml.Vector3fc;

public final class ClusterEspRenderer {
   private static final int COLOR = -6596097;
   private static final int MAX_BOXES = 400;

   private ClusterEspRenderer() {
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d camera, Modules.ClusterEspModule module) {
      int rendered = 0;
      Vector3fc forward = MinecraftClient.getInstance().gameRenderer.getCamera().getHorizontalPlane();

      for(BlockPos pos : module.scanner.amethystCells()) {
         if (rendered++ >= 400) {
            break;
         }

         EspBoxRenderer.fill(bufferSource, poseStack, camera, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)pos.getX() + (double)1.0F, (double)pos.getY() + (double)1.0F, (double)pos.getZ() + (double)1.0F, Colors.withAlpha(-6596097, 0.22F));
         if ((Boolean)module.tracers.get()) {
            EspBoxRenderer.tracer(bufferSource, poseStack, camera, forward, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F, Colors.withAlpha(-6596097, 0.8F), 1.2F);
         }
      }

      EspBoxRenderer.flush(bufferSource);
   }
}
