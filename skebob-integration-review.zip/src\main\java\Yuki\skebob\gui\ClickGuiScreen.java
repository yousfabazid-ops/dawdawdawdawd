package Yuki.skebob.gui;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.gui.config.ConfigPanel;
import Yuki.skebob.gui.panel.CategoryPanel;
import Yuki.skebob.gui.panel.Panel;
import Yuki.skebob.gui.picker.BlockGridModel;
import Yuki.skebob.gui.picker.IconListGridModel;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.Modules;
import Yuki.skebob.module.impl.BlockEspModule;
import Yuki.skebob.render.BlurHook;
import Yuki.skebob.render.NvgDrawable;
import Yuki.skebob.render.OverlayRenderer;
import Yuki.skebob.render.anim.Animation;
import Yuki.skebob.render.nanovg.NVGIcons;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.settings.BlockListSetting;
import Yuki.skebob.settings.IconListSetting;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.Colors;
import Yuki.skebob.util.UiSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

public class ClickGuiScreen extends Screen implements NvgDrawable {
   private static final ClickGuiState STATE = new ClickGuiState();
   private final List<Panel> panels;
   private final Animation openAnim;
   private boolean closing;
   private final ConfigPanel configPanel;
   private static final float FIDGET_W = 118.0F;
   private static final float FIDGET_H = 28.0F;
   private boolean fidgetHovered;
   private static final float SEARCH_H = 32.0F;
   private static final float FRAME_W = 860.0F;
   private static final float FRAME_H = 550.0F;
   private static final float RAIL_W = 64.0F;
   private static final float CONTENT_PAD = 18.0F;
   private static final float CONTENT_W = 760.0F;
   private static final float SEARCH_W = 260.0F;
   private static final int CONFIG_TAB = 4;
   private final StringBuilder search;
   private int activeCategory;
   private boolean searchFocused;
   private Panel dragging;
   private float dragOffsetX;
   private float dragOffsetY;
   private float pressX;
   private float pressY;
   private boolean dragMoved;
   private Panel pressedContentPanel;
   private final Screen parent;

   public ClickGuiScreen() {
      this((Screen)null);
   }

   public ClickGuiScreen(Screen parent) {
      super(Text.literal("SkebobClient"));
      this.panels = new ArrayList();
      this.openAnim = new Animation(180.0F, 0.0F);
      this.configPanel = new ConfigPanel();
      this.search = new StringBuilder();
      this.parent = parent;
      STATE.ensureDefaultLayout(OverlayRenderer.uiWidth(), OverlayRenderer.uiHeight());
      ModuleManager modules = SkebobClient.modules();
      ThemeManager themes = SkebobClient.themes();

      for(Category category : Category.values()) {
         if (category != Category.VISUALS) {
            this.panels.add(new CategoryPanel(category, modules, themes, STATE));
         }
      }

      this.activeCategory = Category.COMBAT.ordinal();
      this.openAnim.setTarget(1.0F);
   }

   public void onDisplayed() {
      super.onDisplayed();
   }

   public static ClickGuiState state() {
      return STATE;
   }

   private Modules.ClickGuiModule guiModule() {
      return SkebobClient.modules().clickGui;
   }

   public boolean shouldPause() {
      return false;
   }

   public void close() {
      if (!this.closing) {
         this.closing = true;
         this.openAnim.setTarget(0.0F);
      }

   }

   public void removed() {
      BlurHook.clear();
      SkebobClient.config().save();
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      int alpha = (int)(48.0F * this.openAnim.value());
      context.fill(0, 0, this.width, this.height, alpha << 24 | 394506);
      this.finishCloseIfDone();
   }

   public void tick() {
      this.finishCloseIfDone();
   }

   private void finishCloseIfDone() {
      if (this.closing && this.openAnim.isDone()) {
         this.client.setScreen(this.parent);
      }

   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      if (this.client.world == null) {
         this.renderPanoramaBackground(context, deltaTicks);
      }

      if ((Boolean)this.guiModule().blur.get()) {
         BlurHook.set(this.guiModule().blurStrength.getFloat() * this.openAnim.value());
         context.applyBlur();
      } else {
         BlurHook.clear();
      }

   }

   public void renderNvg(NVGRenderer vg, float mouseX, float mouseY, float uiWidth, float uiHeight) {
      if (vg.hasFont()) {
         float t = this.openAnim.value();
         if (!(t <= 0.002F) || !this.closing) {
            vg.save();
            vg.alpha(t);
            float scale = 0.93F + 0.07F * t;
            vg.translate(uiWidth / 2.0F, uiHeight / 2.0F);
            vg.scale(scale);
            vg.translate(-uiWidth / 2.0F, -uiHeight / 2.0F);
            String query = this.search.toString();

            for(Panel panel : this.panels) {
               if (panel instanceof CategoryPanel) {
                  CategoryPanel categoryPanel = (CategoryPanel)panel;
                  categoryPanel.setFilter(query);
               }
            }

            this.renderFrame(vg, uiWidth, uiHeight);
            if (this.configPanel.isOpen()) {
               this.configPanel.setEmbeddedBounds(this.frameX(uiWidth) + 64.0F + 18.0F, this.frameY(uiHeight) + 30.0F, 760.0F, 508.0F);
               this.configPanel.render(vg, mouseX, mouseY, uiWidth, uiHeight);
            } else {
               CategoryPanel active = this.activePanel();
               active.moveTo(this.frameX(uiWidth) + 64.0F + 18.0F, this.frameY(uiHeight) + 66.0F);
               vg.save();
               vg.scissor(this.frameX(uiWidth) + 64.0F, this.frameY(uiHeight) + 66.0F, 796.0F, 468.0F);
               active.render(vg, mouseX, mouseY, uiWidth, uiHeight);
               vg.restore();
            }

            this.renderSearchBar(vg, uiWidth);
            vg.restore();
         }
      }

   }

   private CategoryPanel activePanel() {
      return (CategoryPanel)this.panels.get(Math.clamp((long)this.activeCategory, 0, this.panels.size() - 1));
   }

   private float frameX(float uiWidth) {
      return (uiWidth - 860.0F) / 2.0F;
   }

   private float frameY(float uiHeight) {
      return (uiHeight - 550.0F) / 2.0F;
   }

   private void renderFrame(NVGRenderer vg, float uiWidth, float uiHeight) {
      Theme theme = SkebobClient.themes().current();
      float x = this.frameX(uiWidth);
      float y = this.frameY(uiHeight);
      vg.glow(x, y, 860.0F, 550.0F, 14.0F, 12.0F, Colors.withAlpha(theme.accent(), 0.05F));
      vg.rect(x, y, 860.0F, 550.0F, 20.0F, -16579837);
      vg.rectVarying(x, y, 64.0F, 550.0F, 14.0F, 0.0F, 0.0F, 14.0F, -16185079);
      float dividerX = x + 64.0F;
      float dividerY = y + 66.0F;
      float dividerH = 466.0F;
      vg.rectGradient(dividerX, dividerY, 1.0F, dividerH * 0.25F, 0.0F, Colors.withAlpha(-1, 0.04F), Colors.withAlpha(-1, 0.42F), true);
      vg.rect(dividerX, dividerY + dividerH * 0.25F, 1.0F, dividerH * 0.5F, 0.0F, Colors.withAlpha(-1, 0.42F));
      vg.rectGradient(dividerX, dividerY + dividerH * 0.75F, 1.0F, dividerH * 0.25F, 0.0F, Colors.withAlpha(-1, 0.42F), Colors.withAlpha(-1, 0.04F), true);
      int brand = NVGIcons.brand();
      if (brand > 0) {
         vg.image(brand, x + 10.0F, y + 8.0F, 46.0F, 46.0F, theme.accentBright());
      }

      float tabY = y + 78.0F;
      int tabIndex = 0;

      for(Category category : Category.values()) {
         if (category != Category.VISUALS) {
            boolean selected = !this.configPanel.isOpen() && tabIndex++ == this.activeCategory;
            int fill = selected ? Colors.withAlpha(theme.accent(), 0.035F) : 0;
            if (fill != 0) {
               vg.rect(x + 17.0F, tabY - 15.0F, 30.0F, 30.0F, 8.0F, fill);
            }

            int icon = NVGIcons.get(category);
            if (icon > 0) {
               vg.image(icon, x + 21.0F, tabY - 11.0F, 22.0F, 22.0F, selected ? theme.accentBright() : theme.textMuted());
            }

            tabY += 38.0F;
         }
      }

      boolean configSelected = this.configPanel.isOpen();
      if (configSelected) {
         vg.rect(x + 17.0F, tabY - 15.0F, 30.0F, 30.0F, 8.0F, Colors.withAlpha(theme.accent(), 0.035F));
      }

      int configColor = configSelected ? theme.accentBright() : theme.textMuted();
      vg.rect(x + 29.0F, tabY - 7.0F, 18.0F, 14.0F, 3.0F, Colors.withAlpha(configColor, 0.45F));
      vg.rect(x + 24.0F, tabY - 11.0F, 18.0F, 14.0F, 3.0F, configColor);
      vg.text(this.categoryTitle(), x + 64.0F + 18.0F, y + 34.0F, 18.0F, theme.textPrimary());
   }

   private void renderFidget(NVGRenderer vg, float mouseX, float mouseY, float uiWidth, float uiHeight) {
      Theme theme = SkebobClient.themes().current();
      float fx = fidgetX(uiWidth);
      float fy = fidgetY(uiHeight);
      boolean hover = mouseX >= fx && mouseX <= fx + 760.0F && mouseY >= fy && mouseY <= fy + 28.0F;
      boolean lit = hover || this.configPanel.isOpen();
      if (lit != this.fidgetHovered) {
         this.fidgetHovered = lit;
         if (lit) {
         }
      }

      float width = 760.0F;
      vg.rect(fx, fy, width, 28.0F, 5.0F, lit ? Colors.withAlpha(theme.accent(), 0.18F) : theme.headerTop());
      vg.rectOutline(fx, fy, width, 28.0F, 5.0F, 1.0F, Colors.withAlpha(lit ? theme.accentBright() : theme.border(), 0.75F));
      vg.text("Configs", fx + 14.0F, fy + 14.0F, 12.5F, lit ? theme.textPrimary() : theme.textMuted());
      vg.text("Manage profiles", fx + width - 92.0F, fy + 14.0F, 10.5F, theme.textDisabled());
   }

   private static float fidgetX(float uiWidth) {
      return (uiWidth - 860.0F) / 2.0F + 64.0F + 18.0F;
   }

   private static float fidgetY(float uiHeight) {
      return (uiHeight - 550.0F) / 2.0F + 550.0F - 42.0F;
   }

   private boolean fidgetHit(float mx, float my) {
      float fx = fidgetX(OverlayRenderer.uiWidth());
      float fy = fidgetY(OverlayRenderer.uiHeight());
      return mx >= fx && mx <= fx + 860.0F - 64.0F - 32.0F && my >= fy && my <= fy + 28.0F;
   }

   private void renderSearchBar(NVGRenderer vg, float uiWidth) {
      Theme theme = SkebobClient.themes().current();
      float sx = this.frameX(uiWidth) + 64.0F + 18.0F + 760.0F - 260.0F;
      float sy = this.frameY(OverlayRenderer.uiHeight()) + 16.0F;
      vg.rect(sx, sy, 260.0F, 32.0F, 12.0F, -16053493);
      vg.rectOutline(sx, sy, 260.0F, 32.0F, 12.0F, 1.0F, Colors.withAlpha(theme.borderBright(), 0.62F));
      float ix = sx + 16.0F;
      float iy = sy + 16.0F;
      vg.circleOutline(ix, iy - 1.5F, 4.5F, 1.6F, theme.textMuted());
      vg.line(ix + 3.4F, iy + 2.2F, ix + 6.5F, iy + 5.4F, 1.6F, theme.textMuted());
      float textX = sx + 30.0F;
      if (this.search.isEmpty() && !this.searchFocused) {
         vg.text("Search modulesâ€¦", textX, iy, 13.0F, theme.textDisabled());
      } else {
         float w = vg.text(this.search.toString(), textX, iy, 13.0F, theme.textPrimary());
         if (this.searchFocused && System.nanoTime() / 400000000L % 2L == 0L) {
            vg.rect(textX + w + 2.0F, iy - 7.0F, 1.5F, 14.0F, 0.75F, theme.accentBright());
         }
      }

      if (!this.search.isEmpty()) {
         vg.cross(sx + 260.0F - 26.0F, iy - 6.0F, 12.0F, 1.6F, theme.textMuted());
      }

   }

   public void openSearch(String query) {
      this.search.setLength(0);
      this.search.append(query);
      this.searchFocused = true;
   }

   public ConfigPanel configPanel() {
      return this.configPanel;
   }

   private boolean searchBarHit(float mx, float my) {
      float sx = this.frameX(OverlayRenderer.uiWidth()) + 64.0F + 18.0F + 760.0F - 260.0F;
      float sy = this.frameY(OverlayRenderer.uiHeight()) + 16.0F;
      return mx >= sx && mx <= sx + 260.0F && my >= sy && my <= sy + 32.0F;
   }

   private boolean tabHit(float mx, float my) {
      float x = this.frameX(OverlayRenderer.uiWidth());
      float y = this.frameY(OverlayRenderer.uiHeight()) + 62.0F;
      return mx >= x + 4.0F && mx <= x + 64.0F - 4.0F && my >= y && my <= y + 38.0F * (float)(this.panels.size() + 1);
   }

   private int tabAt(float my) {
      float start = this.frameY(OverlayRenderer.uiHeight()) + 62.0F;
      return Math.clamp((long)((int)((my - start) / 38.0F)), 0, 4);
   }

   private String categoryTitle() {
      if (this.configPanel.isOpen()) {
         return "Configs";
      } else {
         int index = Math.clamp((long)this.activeCategory, 0, this.panels.size() - 1);
         int current = 0;

         for(Category category : Category.values()) {
            if (category != Category.VISUALS && current++ == index) {
               return category.getDisplayName();
            }
         }

         return "Modules";
      }
   }

   private float uiX(double guiX) {
      return OverlayRenderer.guiToUi(guiX);
   }

   private float uiY(double guiY) {
      return OverlayRenderer.guiToUi(guiY);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      float mx = this.uiX(click.comp_4798());
      float my = this.uiY(click.comp_4799());
      NVGRenderer vg = NVGRenderer.get();
      float uiHeight = OverlayRenderer.uiHeight();
      if (this.configPanel.isOpen()) {
         this.configPanel.mouseClicked(mx, my, click.button());
         return true;
      } else if (this.tabHit(mx, my)) {
         int category = this.tabAt(my);
         if (category == 4) {
            this.configPanel.open();
         } else if (category != this.activeCategory) {
            this.activeCategory = category;
            this.search.setLength(0);
            UiSounds.select();
         }

         return true;
      } else if (!this.searchBarHit(mx, my)) {
         this.searchFocused = false;
         Panel panel = this.activePanel();
         if (panel.headerHit(mx, my)) {
            if (click.button() == 0) {
               this.dragging = panel;
               this.dragOffsetX = mx - panel.x();
               this.dragOffsetY = my - panel.y();
               this.pressX = mx;
               this.pressY = my;
               this.dragMoved = false;
            } else if (click.button() == 1) {
               panel.toggleCollapsed();
            }

            return true;
         } else if (panel.bodyHit(vg, mx, my, uiHeight)) {
            this.pressedContentPanel = panel;
            panel.mouseClicked(mx, my, click.button());
            return true;
         } else {
            return true;
         }
      } else {
         float clearX = this.frameX(OverlayRenderer.uiWidth()) + 64.0F + 18.0F + 760.0F - 260.0F + 260.0F - 26.0F;
         if (!this.search.isEmpty() && mx >= clearX - 4.0F && mx <= clearX + 16.0F) {
            this.search.setLength(0);
         } else {
            this.searchFocused = true;
         }

         UiSounds.select();
         return true;
      }
   }

   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      if (this.configPanel.isOpen()) {
         return true;
      } else {
         float mx = this.uiX(click.comp_4798());
         float my = this.uiY(click.comp_4799());
         if (this.dragging != null) {
            if (Math.abs(mx - this.pressX) + Math.abs(my - this.pressY) > 3.0F) {
               this.dragMoved = true;
            }

            if (this.dragMoved) {
               this.dragging.moveTo(mx - this.dragOffsetX, my - this.dragOffsetY);
            }

            return true;
         } else if (this.pressedContentPanel != null) {
            this.pressedContentPanel.mouseDragged(mx, my);
            return true;
         } else {
            return true;
         }
      }
   }

   public boolean mouseReleased(Click click) {
      if (this.configPanel.isOpen()) {
         return true;
      } else if (this.dragging == null) {
         if (this.pressedContentPanel != null) {
            this.pressedContentPanel.mouseReleased();
            this.pressedContentPanel = null;
         }

         return true;
      } else {
         if (!this.dragMoved && click.button() == 0) {
            this.dragging.toggleCollapsed();
         } else if (this.dragMoved) {
            STATE.markCustomized();
         }

         this.dragging = null;
         return true;
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (this.configPanel.isOpen()) {
         return true;
      } else {
         float mx = this.uiX(mouseX);
         float my = this.uiY(mouseY);
         NVGRenderer vg = NVGRenderer.get();
         float uiHeight = OverlayRenderer.uiHeight();
         Panel panel = this.activePanel();
         if (!panel.bodyHit(vg, mx, my, uiHeight) && !panel.headerHit(mx, my)) {
            return true;
         } else {
            panel.onScroll(verticalAmount);
            return true;
         }
      }
   }

   public boolean keyPressed(KeyInput input) {
      if (this.configPanel.isOpen()) {
         this.configPanel.keyPressed(input.comp_4795());
         return true;
      } else if (this.activePanel().isListening()) {
         this.activePanel().keyPressed(input.comp_4795());
         return true;
      } else if (this.searchFocused) {
         switch (input.comp_4795()) {
            case 256:
               this.search.setLength(0);
               this.searchFocused = false;
               break;
            case 257:
            case 335:
               this.searchFocused = false;
               break;
            case 259:
               if (!this.search.isEmpty()) {
                  this.search.deleteCharAt(this.search.length() - 1);
               }
         }

         return true;
      } else if (!input.isEscape() && !this.guiModule().getKeybind().matches(input.comp_4795())) {
         return super.keyPressed(input);
      } else {
         this.close();
         return true;
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.configPanel.isOpen()) {
         this.configPanel.charTyped(input.comp_4793());
         return true;
      } else if (this.activePanel().isListening()) {
         this.activePanel().charTyped(input.comp_4793());
         return true;
      } else if (this.searchFocused && input.isValidChar()) {
         if (this.search.length() < 32) {
            this.search.append(input.asString());
         }

         return true;
      } else {
         return super.charTyped(input);
      }
   }

   private void bringToFront(Panel panel) {
      if (this.panels.remove(panel)) {
         this.panels.addFirst(panel);
      }

   }

   public void openBlockPicker(BlockListSetting setting) {
      BlockGridModel model = new BlockGridModel(setting, () -> {
         BlockEspModule blockEsp = SkebobClient.modules().blockEsp;
         return blockEsp != null ? (Integer)blockEsp.lineColor.get() : -16711736;
      }, "Pick Block");
      this.client.setScreen(new IconPickerScreen(this, model, SkebobClient.themes()));
   }

   public void openIconPicker(IconListSetting setting) {
      IconListGridModel model = new IconListGridModel(setting);
      this.client.setScreen(new IconPickerScreen(this, model, SkebobClient.themes()));
   }
}
