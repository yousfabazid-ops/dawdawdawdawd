package Yuki.skebob.mixin;

import Yuki.skebob.render.custommodel.CustomPlayerModelState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Locale;

@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererSkinChangerMixin {
    @Inject(
        method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void skebob$hideArmorForFlatPhoto(MatrixStack matrices, OrderedRenderCommandQueue queue,
                                               int light, BipedEntityRenderState state,
                                               float limbAngle, float limbDistance, CallbackInfo ci) {
        if (state instanceof CustomPlayerModelState customState) {
            String key = customState.skebob$getCustomModel();
            if (key != null) {
                String normalized = key.toLowerCase(Locale.ROOT).trim()
                    .replaceAll("[\\s-]+", "_");
                if (normalized.equals("sweetie_fox_2d")
                        || normalized.equals("sweetie_fox_v2")) {
                    ci.cancel();
                }
            }
        }
    }
}