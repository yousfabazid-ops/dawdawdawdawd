package Yuki.skebob.render;

import Yuki.skebob.module.impl.BlockEntityEspModule;
import java.util.Collection;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector3fc;

public final class BlockEntityEspRenderer {
   private static final double INSET = 0.002;
   private static final float TRACER_WIDTH = 1.2F;

   private BlockEntityEspRenderer() {
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, BlockEntityEspModule module) {
      Collection<BlockEntityEspModule.Cached> snapshot = module.entries();
      if (!snapshot.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         ClientWorld level = mc.world;
         if (level != null) {
            boolean fill = module.mode.is("Full");
            int alpha = Math.clamp((long)module.highlightAlpha.getInt(), 0, 255);
            boolean showGhosts = (Boolean)module.showGhosts.get();
            boolean tracers = (Boolean)module.tracers.get();
            int ghostTint = (Integer)module.ghostTint.get();
            Vector3fc forward = tracers ? mc.gameRenderer.getCamera().getHorizontalPlane() : null;

            for(BlockEntityEspModule.Cached entry : snapshot) {
               String key = entry.typeKey();
               if (module.blockEntities.isEnabled(key)) {
                  BlockPos p = entry.pos();
                  boolean ghost = level.getBlockEntity(p) == null;
                  if (!ghost || showGhosts) {
                     int rgb = tint(module.blockEntities.color(key) & 16777215, ghost, ghostTint);
                     int argb = rgb | alpha << 24;
                     double x0 = (double)p.getX();
                     double y0 = (double)p.getY();
                     double z0 = (double)p.getZ();
                     double x1 = x0 + (double)1.0F;
                     double y1 = y0 + (double)1.0F;
                     double z1 = z0 + (double)1.0F;
                     if (fill) {
                        EspBoxRenderer.fill(bufferSource, poseStack, cam, x0 - 0.002, y0 - 0.002, z0 - 0.002, x1 + 0.002, y1 + 0.002, z1 + 0.002, argb);
                     } else {
                        EspBoxRenderer.outline(bufferSource, poseStack, cam, x0, y0, z0, x1, y1, z1, argb, 1.6F);
                     }

                     if (tracers) {
                        int tracerColor = rgb | Math.max(alpha, 160) << 24;
                        EspBoxRenderer.tracer(bufferSource, poseStack, cam, forward, x0 + (double)0.5F, y0 + (double)0.5F, z0 + (double)0.5F, tracerColor, 1.2F);
                     }
                  }
               }
            }

            EspBoxRenderer.flush(bufferSource);
         }
      }

   }

   private static int tint(int rgb, boolean ghost, int ghostTintArgb) {
      if (!ghost) {
         return rgb;
      } else {
         int r = rgb >> 16 & 255;
         int g = rgb >> 8 & 255;
         int b = rgb & 255;
         int tr = ghostTintArgb >> 16 & 255;
         int tg = ghostTintArgb >> 8 & 255;
         int tb = ghostTintArgb & 255;
         return (r + tr) / 2 << 16 | (g + tg) / 2 << 8 | (b + tb) / 2;
      }
   }
}
