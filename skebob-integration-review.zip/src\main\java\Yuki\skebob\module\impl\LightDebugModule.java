package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.MinecraftClient;

public final class LightDebugModule extends Module {
   public static final int MIN_LIGHT = 1;
   public static final int MAX_LIGHT = 15;
   private static final int MIN_Y = -51;
   private static final int MAX_Y = 20;
   private final Map<ChunkPos, List<Cell>> cells = new ConcurrentHashMap();
   private final AtomicBoolean scanning = new AtomicBoolean();
   private ExecutorService executor;
   private ChunkPos lastChunk;
   private int ticks;

   public LightDebugModule() {
      super("LightDebug", "Shows block light as black (dark) and white (lit)", Category.RENDER);
   }

   protected void onEnable() {
      this.cells.clear();
      this.lastChunk = null;
      this.ticks = 0;
      this.scanning.set(false);
   }

   protected void onDisable() {
      this.cells.clear();
      if (this.executor != null) {
         this.executor.shutdownNow();
      }

   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null && client.player != null) {
         ChunkPos center = client.player.getChunkPos();
         boolean moved = !center.equals(this.lastChunk);
         this.lastChunk = center;
         if ((++this.ticks % 10 == 0 || moved) && this.scanning.compareAndSet(false, true)) {
            if (this.executor == null || this.executor.isShutdown()) {
               this.executor = Executors.newSingleThreadExecutor((task) -> {
                  Thread thread = new Thread(task, "lightdebug-scan");
                  thread.setDaemon(true);
                  return thread;
               });
            }

            List<ChunkPos> positions = new ArrayList();

            for(int x = -3; x <= 3; ++x) {
               for(int z = -3; z <= 3; ++z) {
                  ChunkPos position = new ChunkPos(center.x + x, center.z + z);
                  if (client.world.getChunkManager().getWorldChunk(position.x, position.z, false) != null) {
                     positions.add(position);
                  }
               }
            }

            this.cells.keySet().removeIf((positionx) -> Math.abs(positionx.x - center.x) > 4 || Math.abs(positionx.z - center.z) > 4);
            this.executor.submit(() -> {
               try {
                  for(int index = 0; index < positions.size(); ++index) {
                     ChunkPos position = (ChunkPos)positions.get(index);
                     List<Cell> found = this.scan(position);
                     if (found.isEmpty()) {
                        this.cells.remove(position);
                     } else {
                        this.cells.put(position, found);
                     }
                  }
               } finally {
                  this.scanning.set(false);
               }

            });
         }
      }
   }

   private List<Cell> scan(ChunkPos position) {
      List<Cell> found = new ArrayList();
      MinecraftClient client = MinecraftClient.getInstance();
      int startX = position.x << 4;
      int startZ = position.z << 4;

      for(int y = -51; y <= 20; ++y) {
         for(int x = 0; x < 16; ++x) {
            for(int z = 0; z < 16; ++z) {
               BlockPos block = new BlockPos(startX + x, y, startZ + z);
               int light = client.world.getLightLevel(LightType.BLOCK, block);
               if (light >= 1 && light <= 15) {
                  found.add(new Cell(block, light));
               }
            }
         }
      }

      return found;
   }

   public Map<ChunkPos, List<Cell>> cells() {
      return this.cells;
   }

   public static final class Cell {
      private final BlockPos pos;
      private final int light;

      private Cell(BlockPos pos, int light) {
         this.pos = pos;
         this.light = light;
      }

      public BlockPos pos() {
         return this.pos;
      }

      public int light() {
         return this.light;
      }
   }
}
