package Yuki.skebob.gui.panel;

import Yuki.skebob.gui.ClickGuiState;
import Yuki.skebob.gui.widget.BlockListWidget;
import Yuki.skebob.gui.widget.BooleanWidget;
import Yuki.skebob.gui.widget.ColorWidget;
import Yuki.skebob.gui.widget.IconListWidget;
import Yuki.skebob.gui.widget.KeybindWidget;
import Yuki.skebob.gui.widget.ModeWidget;
import Yuki.skebob.gui.widget.SettingWidget;
import Yuki.skebob.gui.widget.SliderWidget;
import Yuki.skebob.gui.widget.StringWidget;
import Yuki.skebob.module.Module;
import Yuki.skebob.render.anim.Animation;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.settings.BlockListSetting;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.ColorSetting;
import Yuki.skebob.settings.IconListSetting;
import Yuki.skebob.settings.KeybindSetting;
import Yuki.skebob.settings.ModeSetting;
import Yuki.skebob.settings.Setting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.settings.StringSetting;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.Colors;
import Yuki.skebob.util.UiSounds;
import java.util.ArrayList;
import java.util.List;

public class ModuleEntry {
   public static final float ROW_H = 34.0F;
   private static final float RADIUS = 8.0F;
   private static final float SETTING_INDENT = 12.0F;
   private final Module module;
   private final ThemeManager themes;
   private final ClickGuiState state;
   private final String key;
   private final List<SettingWidget> widgets = new ArrayList();
   private final Animation hover = new Animation(140.0F, 0.0F);
   private final Animation enable = new Animation(160.0F, 0.0F);
   private final Animation expand;
   private float x;
   private float y;
   private float width;

   public ModuleEntry(Module module, ThemeManager themes, ClickGuiState state) {
      this.module = module;
      this.themes = themes;
      this.state = state;
      String var10001 = module.getName();
      this.key = var10001 + "@" + module.getCategory().name();
      this.expand = new Animation(190.0F, state.isExpanded(this.key) ? 1.0F : 0.0F);
      this.enable.snapTo(module.isEnabled() ? 1.0F : 0.0F);

      for(Setting<?> setting : module.getSettings()) {
         if (setting instanceof BooleanSetting b) {
            this.widgets.add(new BooleanWidget(themes, b));
         } else if (setting instanceof SliderSetting s) {
            this.widgets.add(new SliderWidget(themes, s));
         } else if (setting instanceof ModeSetting m) {
            this.widgets.add(new ModeWidget(themes, m));
         } else if (setting instanceof ColorSetting c) {
            this.widgets.add(new ColorWidget(themes, c));
         } else if (setting instanceof BlockListSetting bl) {
            this.widgets.add(new BlockListWidget(themes, bl));
         } else if (setting instanceof IconListSetting il) {
            this.widgets.add(new IconListWidget(themes, il));
         } else if (setting instanceof StringSetting str) {
            this.widgets.add(new StringWidget(themes, str));
         } else if (setting instanceof KeybindSetting k) {
            this.widgets.add(new KeybindWidget(themes, k));
         }
      }

      this.widgets.add(new KeybindWidget(themes, module.getKeybind()));
   }

   public Module getModule() {
      return this.module;
   }

   public void setBounds(float x, float y, float width) {
      this.x = x;
      this.y = y;
      this.width = width;
   }

   private float settingsHeight(NVGRenderer vg) {
      float h = 6.0F;

      for(SettingWidget widget : this.widgets) {
         if (widget.isVisible()) {
            h += widget.height(vg) + 3.0F;
         }
      }

      return h + 3.0F;
   }

   public float height(NVGRenderer vg) {
      float t = this.expand.value();
      return 34.0F + (t <= 0.005F ? 0.0F : t * this.settingsHeight(vg));
   }

   public void render(NVGRenderer vg, float mx, float my, float fadeAlpha) {
      Theme theme = this.theme();
      boolean hovered = mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + 30.0F;
      if (hovered && this.hover.getTarget() < 0.5F) {
      }

      this.hover.setTarget(hovered ? 1.0F : 0.0F);
      this.enable.setTarget(this.module.isEnabled() ? 1.0F : 0.0F);
      float hoverT = this.hover.value();
      float enableT = this.enable.value();
      float expandT = this.expand.value();
      vg.save();
      vg.alpha(fadeAlpha);
      if (hoverT > 0.01F) {
         vg.rect(this.x, this.y, this.width, 34.0F, 13.0F, Colors.withAlpha(theme.accent(), 0.08F * hoverT));
      }

      int rowBorder = this.module.isEnabled() ? Colors.withAlpha(theme.accentBright(), 0.3F) : Colors.withAlpha(theme.border(), 0.28F + 0.2F * hoverT);
      vg.rectOutline(this.x, this.y, this.width, 34.0F, 13.0F, 1.0F, rowBorder);
      float textY = this.y + 17.0F;
      if (enableT > 0.01F) {
         vg.save();
         vg.alpha(enableT);
         vg.text(this.module.getName(), this.x + 12.0F, textY, 13.5F, theme.accentBright());
         vg.restore();
      }

      if (enableT < 0.99F) {
         vg.save();
         vg.alpha(1.0F - enableT);
         int idle = Colors.lerp(theme.textMuted(), theme.textPrimary(), hoverT);
         vg.text(this.module.getName(), this.x + 12.0F, textY, 13.5F, idle);
         vg.restore();
      }

      float switchX = this.x + this.width - 42.0F;
      float switchY = this.y + 10.0F;
      int switchFill = Colors.lerp(theme.statusDisabled(), theme.accent(), enableT);
      vg.rect(switchX, switchY, 30.0F, 14.0F, 7.0F, Colors.withAlpha(switchFill, 0.78F));
      vg.rectOutline(switchX, switchY, 30.0F, 14.0F, 7.0F, 1.0F, Colors.withAlpha(theme.borderBright(), 0.32F + enableT * 0.35F));
      vg.circle(switchX + 7.0F + 16.0F * enableT, this.y + 17.0F, 5.0F, theme.textPrimary());
      if (expandT > 0.005F) {
         float settingsH = this.settingsHeight(vg) * expandT;
         vg.save();
         vg.scissor(this.x, this.y + 34.0F, this.width, settingsH);
         vg.alpha(expandT);
         vg.rect(this.x + 4.0F, this.y + 34.0F - 4.0F, this.width - 8.0F, settingsH + 0.0F, 6.0F, -16579837);
         float wy = this.y + 34.0F + 6.0F;

         for(SettingWidget widget : this.widgets) {
            if (widget.isVisible()) {
               widget.setBounds(this.x + 12.0F, wy, this.width - 24.0F);
               widget.render(vg, mx, my);
               wy += widget.height(vg) + 3.0F;
            }
         }

         vg.restore();
      }

      vg.restore();
   }

   private Theme theme() {
      return this.themes.current();
   }

   public boolean mouseClicked(float mx, float my, int button) {
      if (mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + 34.0F) {
         if (button == 0) {
            this.module.toggle();
            UiSounds.toggle(this.module.isEnabled());
         } else if (button == 1) {
            boolean expanded = !(this.expand.getTarget() > 0.5F);
            this.expand.setTarget(expanded ? 1.0F : 0.0F);
            this.state.setExpanded(this.key, expanded);
            UiSounds.select();
         }

         return true;
      } else if (this.expand.getTarget() > 0.5F && my >= this.y + 34.0F && my <= this.y + this.height((NVGRenderer)null)) {
         for(SettingWidget widget : this.widgets) {
            if (widget.isVisible() && widget.mouseClicked(mx, my, button)) {
               return true;
            }
         }

         return mx >= this.x && mx <= this.x + this.width;
      } else {
         return false;
      }
   }

   public void mouseDragged(float mx, float my) {
      for(SettingWidget widget : this.widgets) {
         widget.mouseDragged(mx, my);
      }

   }

   public void mouseReleased() {
      for(SettingWidget widget : this.widgets) {
         widget.mouseReleased();
      }

   }

   public boolean keyPressed(int keyCode) {
      for(SettingWidget widget : this.widgets) {
         if (widget.keyPressed(keyCode)) {
            return true;
         }
      }

      return false;
   }

   public boolean charTyped(int codepoint) {
      for(SettingWidget widget : this.widgets) {
         if (widget.charTyped(codepoint)) {
            return true;
         }
      }

      return false;
   }

   public boolean isListening() {
      for(SettingWidget widget : this.widgets) {
         if (widget.isListening()) {
            return true;
         }
      }

      return false;
   }
}
