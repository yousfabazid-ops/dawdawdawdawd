package Yuki.skebob.module.impl;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;

public class FakeLagPlayerEntity extends OtherClientPlayerEntity {

    public FakeLagPlayerEntity(
        ClientWorld world,
        GameProfile profile
    ) {
        super(world, profile);
    }

    /*
     * Same anti-interaction behavior as Gooba's fake player.
     */
    @Override
    public boolean canHit() {
        return false;
    }

    @Override
    public boolean isCollidable(Entity entity) {
        return false;
    }

    @Override
    public boolean collidesWith(Entity entity) {
        return false;
    }

    @Override
    public void pushAwayFrom(Entity entity) {
        // Intentionally no push interaction.
    }

    @Override
    public boolean isPushable() {
        return false;
    }
}