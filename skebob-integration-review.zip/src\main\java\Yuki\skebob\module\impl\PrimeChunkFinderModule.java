package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.client.MinecraftClient;
import net.minecraft.block.entity.BeehiveBlockEntity;

public class PrimeChunkFinderModule extends Module {
   public final ConcurrentHashMap<ChunkPos, String> markedChunks = new ConcurrentHashMap();
   public final AtomicBoolean scanning = new AtomicBoolean(false);
   private ExecutorService executor;
   private long lastScanTime = 0L;
   private long lastMarkTime = 0L;
   private long lastRepScanTime = 0L;
   private long scanStartTime = 0L;
   private boolean scanActive = false;
   private static final long SCAN_INTERVAL_MS = 20000L;
   private static final long REPEATER_SCAN_INTERVAL_MS = 200L;
   private static final long COOLDOWN_MS = 50000L;
   private static final float SCAN_DURATION_MS = 800.0F;

   public PrimeChunkFinderModule() {
      super("Prime Chunk Finder", "Detects repeater chunks and base indicators", Category.RENDER);
   }

   public void onEnable() {
      this.markedChunks.clear();
      this.lastScanTime = 0L;
      this.lastMarkTime = 0L;
      this.lastRepScanTime = 0L;
      this.scanActive = false;
   }

   public void onDisable() {
      this.markedChunks.clear();
      if (this.executor != null) {
         this.executor.shutdownNow();
      }

      this.scanning.set(false);
      this.scanActive = false;
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && mc.player != null) {
         if (this.scanActive && (float)(System.currentTimeMillis() - this.scanStartTime) > 800.0F) {
            this.scanActive = false;
         }

         long now = System.currentTimeMillis();
         if (now - this.lastRepScanTime >= 200L && !this.scanning.get()) {
            this.lastRepScanTime = now;
            ChunkPos chunkPos = mc.player.getChunkPos();
            int radius = Math.min(mc.options.getClampedViewDistance(), 8);
            ArrayList<ChunkPos> chunkPositions = new ArrayList();
            ArrayList<WorldChunk> chunks = new ArrayList();

            for(int offsetX = -radius; offsetX <= radius; ++offsetX) {
               for(int offsetZ = -radius; offsetZ <= radius; ++offsetZ) {
                  ChunkPos chunkPos2 = new ChunkPos(chunkPos.x + offsetX, chunkPos.z + offsetZ);
                  WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(chunkPos2.x, chunkPos2.z, false);
                  if (chunk != null && !chunk.isEmpty()) {
                     chunkPositions.add(chunkPos2);
                     chunks.add(chunk);
                  }
               }
            }

            if (this.executor == null || this.executor.isShutdown()) {
               this.executor = Executors.newSingleThreadExecutor((r) -> {
                  Thread thread = new Thread(r, "prime-repeater-scan");
                  thread.setDaemon(true);
                  return thread;
               });
            }

            this.executor.submit(() -> {
               for(int i = 0; i < chunkPositions.size(); ++i) {
                  WorldChunk chunk5 = (WorldChunk)chunks.get(i);
                  int count = 0;

                  for(ChunkSection section : chunk5.getSectionArray()) {
                     if (section != null && !section.isEmpty() && section.hasAny((statex) -> statex.isOf(Blocks.REPEATER))) {
                        for(int x = 0; x < 16; ++x) {
                           for(int y = 0; y < 16; ++y) {
                              for(int z = 0; z < 16; ++z) {
                                 BlockState state = section.getBlockState(x, y, z);
                                 if (state.isOf(Blocks.REPEATER) && (Boolean)state.get(RepeaterBlock.POWERED)) {
                                    ++count;
                                    if (count >= 3) {
                                       this.markedChunks.clear();
                                       this.markedChunks.put((ChunkPos)chunkPositions.get(i), "repeater");
                                       return;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }

            });
         }

         if (now - this.lastScanTime >= 20000L && this.scanning.compareAndSet(false, true)) {
            if (this.executor == null || this.executor.isShutdown()) {
               this.executor = Executors.newSingleThreadExecutor((r) -> {
                  Thread thread = new Thread(r, "prime-chunk-scan");
                  thread.setDaemon(true);
                  return thread;
               });
            }

            this.lastScanTime = now;
            this.scanActive = true;
            this.scanStartTime = now;
            ChunkPos center = mc.player.getChunkPos();
            int radius2 = Math.min(mc.options.getClampedViewDistance(), 8);
            ArrayList<ChunkPos> chunkPositions = new ArrayList();
            ArrayList<WorldChunk> chunks = new ArrayList();

            for(int offsetX = -radius2; offsetX <= radius2; ++offsetX) {
               for(int offsetZ = -radius2; offsetZ <= radius2; ++offsetZ) {
                  ChunkPos chunkPos4 = new ChunkPos(center.x + offsetX, center.z + offsetZ);
                  WorldChunk chunk6 = mc.world.getChunkManager().getWorldChunk(chunkPos4.x, chunkPos4.z, false);
                  if (chunk6 != null && !chunk6.isEmpty()) {
                     chunkPositions.add(chunkPos4);
                     chunks.add(chunk6);
                  }
               }
            }

            this.executor.submit(() -> {
               try {
                  ChunkPos foundRepeater = null;

                  label570:
                  for(int i = 0; i < chunkPositions.size(); ++i) {
                     WorldChunk chunk2 = (WorldChunk)chunks.get(i);
                     int count = 0;

                     for(ChunkSection section : chunk2.getSectionArray()) {
                        if (section != null && !section.isEmpty() && section.hasAny((statexx) -> statexx.isOf(Blocks.REPEATER))) {
                           for(int x = 0; x < 16; ++x) {
                              for(int y = 0; y < 16; ++y) {
                                 for(int z = 0; z < 16; ++z) {
                                    BlockState state = section.getBlockState(x, y, z);
                                    if (state.isOf(Blocks.REPEATER) && (Boolean)state.get(RepeaterBlock.POWERED)) {
                                       ++count;
                                       if (count >= 3) {
                                          foundRepeater = (ChunkPos)chunkPositions.get(i);
                                          break label570;
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }

                  if (foundRepeater == null) {
                     ChunkPos foundNormal = null;

                     for(int i = 0; i < chunkPositions.size(); ++i) {
                        ChunkPos pos = (ChunkPos)chunkPositions.get(i);
                        WorldChunk chunk7 = (WorldChunk)chunks.get(i);
                        boolean active = false;

                        for(BlockEntity be : chunk7.getBlockEntities().values()) {
                           BlockState state3 = chunk7.getBlockState(be.getPos());
                           if ((state3.isOf(Blocks.BEEHIVE) || state3.isOf(Blocks.BEE_NEST)) && be instanceof BeehiveBlockEntity) {
                              BeehiveBlockEntity beehive = (BeehiveBlockEntity)be;
                              if (beehive.getBeeCount() > 0) {
                                 active = true;
                                 break;
                              }
                           }
                        }

                        boolean active2 = false;
                        if (!active) {
                           int count = 0;
                           int bottomY = chunk7.getBottomY();
                           ChunkSection[] sections = chunk7.getSectionArray();

                           label737:
                           for(int s = 0; s < sections.length; ++s) {
                              int sectionY = bottomY + s * 16;
                              if (sectionY > 20) {
                                 break;
                              }

                              if (sectionY + 16 >= 0) {
                                 ChunkSection section = sections[s];
                                 if (section != null && !section.isEmpty() && section.hasAny((statexx) -> statexx.isOf(Blocks.COBBLED_DEEPSLATE))) {
                                    for(int x = 0; x < 16; ++x) {
                                       for(int z = 0; z < 16; ++z) {
                                          for(int y = 0; y < 16; ++y) {
                                             int worldY = sectionY + y;
                                             if (worldY >= 0 && worldY <= 20 && section.getBlockState(x, y, z).isOf(Blocks.COBBLED_DEEPSLATE)) {
                                                ++count;
                                                if (count >= 50) {
                                                   active2 = true;
                                                   break label737;
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        boolean active3 = false;
                        if (!active) {
                           int count = 0;

                           for(ChunkSection section : chunk7.getSectionArray()) {
                              if (section != null && !section.isEmpty() && section.hasAny((statexx) -> statexx.isOf(Blocks.VINE))) {
                                 for(int x = 0; x < 16; ++x) {
                                    for(int y = 0; y < 16; ++y) {
                                       for(int z = 0; z < 16; ++z) {
                                          if (section.getBlockState(x, y, z).isOf(Blocks.VINE)) {
                                             ++count;
                                             if (count >= 150) {
                                                active3 = true;
                                                break;
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        boolean active4 = false;
                        if (!active && !active3) {
                           int count = 0;
                           ChunkSection[] sections2 = chunk7.getSectionArray();
                           int bottomY = chunk7.getBottomY();

                           for(int s = 0; s < sections2.length && bottomY + s * 16 <= 70; ++s) {
                              ChunkSection section = sections2[s];
                              if (section != null && !section.isEmpty() && section.hasAny((statexx) -> statexx.isOf(Blocks.SEAGRASS) || statexx.isOf(Blocks.TALL_SEAGRASS))) {
                                 for(int x = 0; x < 16; ++x) {
                                    for(int y = 0; y < 16; ++y) {
                                       for(int z = 0; z < 16; ++z) {
                                          BlockState state = section.getBlockState(x, y, z);
                                          if (state.isOf(Blocks.SEAGRASS) || state.isOf(Blocks.TALL_SEAGRASS)) {
                                             ++count;
                                             if (count >= 30) {
                                                active4 = true;
                                                break;
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        boolean active9 = false;
                        if (!active && !active3 && !active4 && !active2) {
                           int count = 0;

                           label619:
                           for(ChunkSection section : chunk7.getSectionArray()) {
                              if (section != null && !section.isEmpty() && section.hasAny((statexx) -> statexx.isOf(Blocks.REPEATER))) {
                                 for(int x = 0; x < 16; ++x) {
                                    for(int y = 0; y < 16; ++y) {
                                       for(int z = 0; z < 16; ++z) {
                                          if (section.getBlockState(x, y, z).isOf(Blocks.REPEATER)) {
                                             ++count;
                                             if (count >= 3) {
                                                active9 = true;
                                                break label619;
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        if (active || active3 || active4 || active2 || active9) {
                           foundNormal = pos;
                           break;
                        }
                     }

                     if (foundNormal == null) {
                        return;
                     }

                     boolean flag = System.currentTimeMillis() - this.lastMarkTime >= 50000L;
                     if (flag) {
                        this.lastMarkTime = System.currentTimeMillis();
                        this.markedChunks.clear();
                        this.markedChunks.put(foundNormal, "normal");
                     }

                     return;
                  }

                  this.lastMarkTime = System.currentTimeMillis();
                  this.markedChunks.clear();
                  this.markedChunks.put(foundRepeater, "repeater");
               } finally {
                  this.scanning.set(false);
               }

            });
         }

      }
   }
}
