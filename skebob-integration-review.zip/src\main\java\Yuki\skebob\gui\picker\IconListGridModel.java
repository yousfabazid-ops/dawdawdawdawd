package Yuki.skebob.gui.picker;

import Yuki.skebob.settings.ColorSetting;
import Yuki.skebob.settings.IconListSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public final class IconListGridModel implements PickerGrid {
   private final IconListSetting setting;
   private List<PickerGrid.Cell> cells;

   public IconListGridModel(IconListSetting setting) {
      this.setting = setting;
   }

   public String title() {
      return this.setting.getName();
   }

   public long activeCount() {
      return this.setting.enabledCount();
   }

   public List<PickerGrid.Cell> cells() {
      if (this.cells == null) {
         List<PickerGrid.Cell> out = new ArrayList(this.setting.entries().size());

         for(IconListSetting.Entry entry : this.setting.entries()) {
            out.add(new EntryCell(entry));
         }

         this.cells = out;
      }

      return this.cells;
   }

   private static final class EntryCell implements PickerGrid.Cell {
      private final IconListSetting.Entry entry;
      private final ItemStack icon;

      EntryCell(IconListSetting.Entry entry) {
         this.entry = entry;
         this.icon = new ItemStack(entry.icon());
      }

      public ItemStack icon() {
         return this.icon;
      }

      public Identifier fallbackTexture() {
         Identifier var10000;
         switch (this.entry.key()) {
            case "chest":
               var10000 = Identifier.of("minecraft", "textures/entity/chest/normal.png");
               break;
            case "trapped":
               var10000 = Identifier.of("minecraft", "textures/entity/chest/trapped.png");
               break;
            case "ender":
               var10000 = Identifier.of("minecraft", "textures/entity/chest/ender.png");
               break;
            case "barrel":
               var10000 = Identifier.of("minecraft", "textures/entity/barrel.png");
               break;
            case "shulker":
               var10000 = Identifier.of("minecraft", "textures/entity/shulker/shulker.png");
               break;
            case "spawner":
               var10000 = Identifier.of("minecraft", "textures/entity/mob spawner.png");
               break;
            case "hopper":
               var10000 = Identifier.of("minecraft", "textures/block/hopper_top.png");
               break;
            case "furnace":
               var10000 = Identifier.of("minecraft", "textures/block/furnace_front.png");
               break;
            default:
               Identifier id = Identifier.tryParse(this.entry.key());
               var10000 = id == null ? null : Identifier.of(id.getNamespace(), "textures/block/" + id.getPath() + ".png");
         }

         return var10000;
      }

      public String label() {
         return this.entry.label();
      }

      public boolean matches(String lowerQuery) {
         return this.entry.matches(lowerQuery);
      }

      public boolean tracked() {
         return true;
      }

      public boolean enabled() {
         return (Boolean)this.entry.enabled.get();
      }

      public boolean selected() {
         return (Boolean)this.entry.enabled.get();
      }

      public int color() {
         return (Integer)this.entry.color.get();
      }

      public void toggle() {
         this.entry.enabled.toggle();
      }

      public ColorSetting colorTarget() {
         return this.entry.color;
      }
   }
}
