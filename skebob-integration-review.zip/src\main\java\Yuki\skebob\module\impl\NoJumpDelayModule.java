package Yuki.skebob.module.impl;

import Yuki.skebob.mixin.ILivingEntity;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import net.minecraft.client.MinecraftClient;

public class NoJumpDelayModule extends Module {

    public NoJumpDelayModule() {
        super(
            "NoJumpDelay",
            "Removes the delay between jumps",
            Category.MISC
        );
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null) {
            return;
        }

        ((ILivingEntity) mc.player).setJumpingCooldown(0);
    }
}