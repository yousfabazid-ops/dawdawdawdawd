package Yuki.skebob.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.item.Item;

@SuppressWarnings({"unchecked", "rawtypes"})
public class IconListSetting extends Setting<List> {
   private final Map<String, Entry> byKey = new LinkedHashMap();

   public IconListSetting(String name, String description) {
      super(name, description, new ArrayList());
   }

   public Entry add(String key, String label, Item icon, boolean enabled, int color) {
      Entry entry = new Entry(key, label, icon, enabled, color);
      ((List)this.value).add(entry);
      this.byKey.put(key, entry);
      return entry;
   }

   public List<Entry> entries() {
      return this.value;
   }

   public Entry get(String key) {
      return (Entry)this.byKey.get(key);
   }

   public boolean isEnabled(String key) {
      Entry e = (Entry)this.byKey.get(key);
      return e != null && (Boolean)e.enabled.get();
   }

   public int color(String key) {
      Entry e = (Entry)this.byKey.get(key);
      return e != null ? (Integer)e.color.get() : -1;
   }

   @SuppressWarnings("unchecked")
   public int size() {
      return ((List<Entry>)(List<?>)this.value).size();
   }

   @SuppressWarnings("unchecked")
   public long enabledCount() {
      return ((List<Entry>)(List<?>)this.value).stream().filter((e) -> (Boolean)e.enabled.get()).count();
   }

   @SuppressWarnings("unchecked")
   public JsonElement toJson() {
      JsonArray arr = new JsonArray();

      for(Entry e : (List<Entry>)(List<?>)this.value) {
         JsonObject o = new JsonObject();
         o.addProperty("key", e.key);
         o.addProperty("enabled", (Boolean)e.enabled.get());
         o.addProperty("color", (Number)e.color.get());
         arr.add(o);
      }

      return arr;
   }

   public void fromJson(JsonElement element) {
      if (element != null && element.isJsonArray()) {
         for(JsonElement el : element.getAsJsonArray()) {
            if (el.isJsonObject()) {
               JsonObject o = el.getAsJsonObject();
               if (o.has("key")) {
                  Entry e = (Entry)this.byKey.get(o.get("key").getAsString());
                  if (e != null) {
                     if (o.has("enabled")) {
                        e.enabled.set(o.get("enabled").getAsBoolean());
                     }

                     if (o.has("color")) {
                        e.color.set(o.get("color").getAsInt());
                     }
                  }
               }
            }
         }
      }

   }

   public static final class Entry {
      private final String key;
      private final String label;
      private final Item icon;
      public final BooleanSetting enabled;
      public final ColorSetting color;

      Entry(String key, String label, Item icon, boolean enabled, int color) {
         this.key = key;
         this.label = label;
         this.icon = icon;
         this.enabled = new BooleanSetting("Enabled", "Highlight this type", enabled);
         this.color = new ColorSetting(label, "Highlight color", color);
      }

      public String key() {
         return this.key;
      }

      public String label() {
         return this.label;
      }

      public Item icon() {
         return this.icon;
      }

      public boolean matches(String lowerQuery) {
         return this.label.toLowerCase(Locale.ROOT).contains(lowerQuery) || this.key.contains(lowerQuery);
      }
   }
}
