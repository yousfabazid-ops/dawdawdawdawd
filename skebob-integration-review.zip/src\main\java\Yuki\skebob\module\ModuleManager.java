package Yuki.skebob.module;

import Yuki.skebob.module.impl.SusChunkFinderV2Module;

import Yuki.skebob.module.impl.AimAssistModule;
import Yuki.skebob.module.impl.AnchorMacroModule;
import Yuki.skebob.module.impl.AutoCrystalModule;
import Yuki.skebob.module.impl.AutoInventoryTotemModule;
import Yuki.skebob.module.impl.AutoToolModule;
import Yuki.skebob.module.impl.AutoTotemModule;
import Yuki.skebob.module.impl.BlockEntityEspModule;
import Yuki.skebob.module.impl.BlockEspModule;
import Yuki.skebob.module.impl.CustomAccessoriesModule;
import Yuki.skebob.module.impl.DoubleAnchorModule;
import Yuki.skebob.module.impl.ElytraSwapModule;
import Yuki.skebob.module.impl.FakeLagModule;
import Yuki.skebob.module.impl.FakePayModule;
import Yuki.skebob.module.impl.FakeRolesModule;
import Yuki.skebob.module.impl.FakeStatsModule;
import Yuki.skebob.module.impl.FastUseModule;
import Yuki.skebob.module.impl.FreeLookModule;
import Yuki.skebob.module.impl.FreecamModule;
import Yuki.skebob.module.impl.FullbrightModule;
import Yuki.skebob.module.impl.GambleRiggerModule;
import Yuki.skebob.module.impl.HitBoxModule;
import Yuki.skebob.module.impl.HitParticlesModule;
import Yuki.skebob.module.impl.HoverTotemModule;
import Yuki.skebob.module.impl.HopModule;
import Yuki.skebob.module.impl.LightDebugModule;
import Yuki.skebob.module.impl.MaceBomberModule;
import Yuki.skebob.module.impl.MaceSwapModule;
import Yuki.skebob.module.impl.MotionBlurModule;
import Yuki.skebob.module.impl.NameProtectModule;
import Yuki.skebob.module.impl.NameTagsModule;
import Yuki.skebob.module.impl.NoJumpDelayModule;
import Yuki.skebob.module.impl.PlayerEspModule;
import Yuki.skebob.module.impl.PrimeChunkFinderModule;
import Yuki.skebob.module.impl.ShieldBreakerModule;
import Yuki.skebob.module.impl.SkinProtectModule;
import Yuki.skebob.module.impl.SkinChangerModule;
import Yuki.skebob.module.impl.SpawnerProtectModule;
import Yuki.skebob.module.impl.StaffListModule;
import Yuki.skebob.module.impl.StorageEspModule;
import Yuki.skebob.module.impl.StrafeModule;
import Yuki.skebob.module.impl.SwingSpeedModule;
import Yuki.skebob.module.impl.TargetStrafeModule;
import Yuki.skebob.module.impl.TriggerbotModule;
import Yuki.skebob.settings.Setting;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public class ModuleManager {
   private final List<Module> modules = new ArrayList();
   private final Map<Category, List<Module>> byCategory = new LinkedHashMap();
   public final Modules.ClickGuiModule clickGui;
   public final Modules.HudModule hud;
   public final Modules.SpotifyModule spotify;
   public final Modules.SusChunkFinderModule susChunkFinder;
   public final SusChunkFinderV2Module susChunkFinderV2;
   public final Modules.ClusterEspModule clusterEsp;
   public final PrimeChunkFinderModule primeChunkFinder;
   public final LightDebugModule lightDebug;
   public FullbrightModule fullbright;
   public SwingSpeedModule swingSpeed;
   public StorageEspModule storageEsp;
   public BlockEspModule blockEsp;
   public AutoTotemModule autoTotem;
   public AutoToolModule autoTool;
   public MaceSwapModule maceSwap;
   public AnchorMacroModule anchorMacro;
   public AutoCrystalModule autoCrystal;
   public HitBoxModule hitBox;
   public ElytraSwapModule elytraSwap;
   public HoverTotemModule hoverTotem;
   public ShieldBreakerModule shieldBreaker;
   public AimAssistModule aimAssist;
   public FakeLagModule fakeLag;
   public TriggerbotModule triggerbot;
   public DoubleAnchorModule doubleAnchor;
   public MaceBomberModule maceBomber;
   public NameProtectModule nameProtect;
   public SkinProtectModule skinProtect;
   public SkinChangerModule skinChanger;
   public NameTagsModule nameTags;
   public FastUseModule fastUse;
   public AutoInventoryTotemModule autoInventoryTotem;
   public PlayerEspModule playerEsp;
   public BlockEntityEspModule blockEntityEsp;
   public FreecamModule freecam;
   public HitParticlesModule hitParticles;
   public MotionBlurModule motionBlur;
   public CustomAccessoriesModule customAccessories;
   public FreeLookModule freeLook;
   public FakePayModule fakePay;
   public FakeStatsModule fakeStats;
   public FakeRolesModule fakeRoles;
   public StaffListModule staffList;
   public SpawnerProtectModule spawnerProtect;
   public GambleRiggerModule gambleRigger;
   public TargetStrafeModule targetStrafe;
   public StrafeModule strafe;
   public HopModule hop;
   public NoJumpDelayModule noJumpDelay;
   private Runnable openGuiAction = () -> {
   };
   private BiConsumer<Module, Boolean> toggleListener = (m, e) -> {
   };
   private boolean keybindToggle;

   public ModuleManager() {
      for (Category category : Category.values()) {
         this.byCategory.put(category, new ArrayList());
      }

      this.susChunkFinder = new Modules.SusChunkFinderModule();
      this.susChunkFinderV2 = new SusChunkFinderV2Module();
      this.clusterEsp = new Modules.ClusterEspModule();
      this.primeChunkFinder = new PrimeChunkFinderModule();
      this.lightDebug = new LightDebugModule();
      this.registerPlaceholders();
      this.register(this.hitParticles = new HitParticlesModule());
      this.register(this.customAccessories = new CustomAccessoriesModule());
      this.register(this.motionBlur = new MotionBlurModule());
      this.register(this.hud = new Modules.HudModule());
      this.register(this.spotify = new Modules.SpotifyModule());
      this.register(this.swingSpeed = new SwingSpeedModule());
      this.register(this.clickGui = new Modules.ClickGuiModule());
   }

   private void registerPlaceholders() {
      this.register(this.autoTotem = new AutoTotemModule());
      this.register(this.autoTool = new AutoToolModule());
      this.register(this.autoCrystal = new AutoCrystalModule());
      this.register(this.anchorMacro = new AnchorMacroModule());
      this.register(this.doubleAnchor = new DoubleAnchorModule());
      this.register(this.autoInventoryTotem = new AutoInventoryTotemModule());
      this.register(this.maceSwap = new MaceSwapModule());
      this.register(this.hitBox = new HitBoxModule());
      this.register(this.elytraSwap = new ElytraSwapModule());
      this.register(this.hoverTotem = new HoverTotemModule());
      this.register(this.shieldBreaker = new ShieldBreakerModule());
      this.register(this.aimAssist = new AimAssistModule());
      this.register(this.fakeLag = new FakeLagModule());
      this.register(this.triggerbot = new TriggerbotModule());
      this.register(this.maceBomber = new MaceBomberModule());
      this.register(this.skinProtect = new SkinProtectModule());
      this.register(this.skinChanger = new SkinChangerModule());
      this.register(this.nameProtect = new NameProtectModule());
      this.register(this.freecam = new FreecamModule());
      this.register(this.fastUse = new FastUseModule());
      this.register(this.nameTags = new NameTagsModule());
      this.register(this.fakePay = new FakePayModule());
      this.register(this.fakeStats = new FakeStatsModule());
      this.register(this.fakeRoles = new FakeRolesModule());
      this.register(this.staffList = new StaffListModule());
      this.register(this.freeLook = new FreeLookModule());
      this.register(this.spawnerProtect = new SpawnerProtectModule());
      this.register(this.gambleRigger = new GambleRiggerModule());
      this.register(this.targetStrafe = new TargetStrafeModule());
      this.register(this.strafe = new StrafeModule());
      this.register(this.hop = new HopModule());
      this.register(this.noJumpDelay = new NoJumpDelayModule());
      this.register(this.blockEsp = new BlockEspModule());
      this.register(this.storageEsp = new StorageEspModule());
      this.register(this.blockEntityEsp = new BlockEntityEspModule());
      this.register(this.fullbright = new FullbrightModule());
      this.register(this.playerEsp = new PlayerEspModule());
      this.register(this.susChunkFinder);
      this.register(this.susChunkFinderV2);
      this.register(this.clusterEsp);
      this.register(this.primeChunkFinder);
      this.register(this.lightDebug);
   }

   private void ph(String name, String description, Category category, Setting<?>... settings) {
      this.register(new Modules.Placeholder(name, description, category, settings));
   }

   public void register(Module module) {
      this.modules.add(module);
      ((List)this.byCategory.get(module.getCategory())).add(module);
      module.setToggleCallback(this::notifyToggle);
   }

   public List<Module> all() {
      return this.modules;
   }

   public List<Module> inCategory(Category category) {
      return (List)this.byCategory.get(category);
   }

   public void setOpenGuiAction(Runnable action) {
      this.openGuiAction = action;
   }

   public void setToggleListener(BiConsumer<Module, Boolean> listener) {
      this.toggleListener = listener;
   }

   public void notifyToggle(Module module, boolean enabled) {
      this.toggleListener.accept(module, enabled);
   }

   public boolean onKeyPressed(int keyCode) {
      if (this.clickGui.getKeybind().matches(keyCode)) {
         this.openGuiAction.run();
         return true;
      } else {
         boolean handled = false;

         for (Module module : this.modules) {
            if (module != this.clickGui && module.getKeybind().matches(keyCode)) {
               this.keybindToggle = true;
               try {
                  module.toggle();
               } finally {
                  this.keybindToggle = false;
               }
               handled = true;
            }
         }

         for (Module module : this.modules) {
            if (module.isEnabled() && module.onKeyPress(keyCode)) {
               handled = true;
            }
         }

         return handled;
      }
   }

   public void onTick() {
      for (Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() != Category.COMBAT) {
            module.onTick();
         }
      }
   }

   public boolean isKeybindToggle() {
      return this.keybindToggle;
   }

   public void onCombatTick() {
      for (Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() == Category.COMBAT) {
            module.onTick();
         }
      }
   }
}