package Yuki.skebob.render;

import Yuki.skebob.module.impl.PlayerEspModule;
import Yuki.skebob.util.Colors;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.joml.Vector3fc;

public final class EntityEspRenderer {
   private static final float TRACER_WIDTH = 1.2F;

   private EntityEspRenderer() {
   }

   public static void renderPlayers(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, PlayerEspModule module) {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld level = mc.world;
      if (level != null && mc.player != null) {
         int color = (Integer)module.color.get();
         boolean tracers = (Boolean)module.tracers.get();
         Vector3fc forward = tracers ? mc.gameRenderer.getCamera().getHorizontalPlane() : null;

         for(AbstractClientPlayerEntity player : level.getPlayers()) {
            if (player != mc.player && player.isAlive() && !player.isSpectator()) {
               Box playerBox = interpolatedBox(player);
               box(bufferSource, poseStack, cam, playerBox, color);
               if (tracers) {
                  tracer(bufferSource, poseStack, cam, forward, playerBox, color);
               }
            }
         }

         EspBoxRenderer.flush(bufferSource);
      }

   }

   private static void box(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, Box b, int color) {
      EspBoxRenderer.outline(bufferSource, poseStack, cam, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, color, 2.0F);
      EspBoxRenderer.fill(bufferSource, poseStack, cam, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, Colors.withAlpha(color, 0.18F));
   }

   private static Box interpolatedBox(Entity entity) {
      Box box = entity.getBoundingBox();
      Vec3d currentPos = new Vec3d(entity.getX(), entity.getY(), entity.getZ());
      Vec3d renderPos = entity.getLerpedPos(WorldProjection.partialTick());
      return box.offset(renderPos.x - currentPos.x, renderPos.y - currentPos.y, renderPos.z - currentPos.z);
   }

   private static void tracer(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, Vec3d cam, Vector3fc forward, Box b, int color) {
      EspBoxRenderer.tracer(bufferSource, poseStack, cam, forward, (b.minX + b.maxX) / (double)2.0F, (b.minY + b.maxY) / (double)2.0F, (b.minZ + b.maxZ) / (double)2.0F, Colors.withAlpha(color, 0.72F), 1.2F);
   }
}
