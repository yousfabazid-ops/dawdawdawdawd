package Yuki.skebob.gui.widget;

import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.settings.KeybindSetting;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.Colors;
import Yuki.skebob.util.UiSounds;

public class KeybindWidget extends SettingWidget {
   public static final float HEIGHT = 22.0F;
   private final KeybindSetting setting;
   private boolean listening;

   public KeybindWidget(ThemeManager themes, KeybindSetting setting) {
      super(themes, setting);
      this.setting = setting;
   }

   public float height(NVGRenderer vg) {
      return 22.0F;
   }

   public void render(NVGRenderer vg, float mx, float my) {
      Theme theme = this.theme();
      float cy = this.y + 11.0F;
      vg.text(this.setting.getName(), this.x, cy, 12.5F, theme.textMuted());
      String label = this.listening ? "..." : this.setting.keyName();
      float chipW = Math.max(30.0F, vg.textWidth(label, 11.5F) + 12.0F);
      float chipX = this.x + this.width - chipW;
      float chipH = 16.0F;
      float chipY = cy - chipH / 2.0F;
      int fill = this.listening ? Colors.withAlpha(theme.accent(), 0.3F) : Colors.withAlpha(-16777216, 0.45F);
      vg.rect(chipX, chipY, chipW, chipH, chipH / 2.0F, fill);
      if (this.listening) {
         float pulse = (float)((double)0.5F + (double)0.5F * Math.sin((double)System.nanoTime() / (double)2.2E8F));
         vg.rectOutline(chipX, chipY, chipW, chipH, chipH / 2.0F, 1.2F, Colors.withAlpha(theme.accentBright(), 0.4F + 0.6F * pulse));
      }

      vg.text(label, chipX + (chipW - vg.textWidth(label, 11.5F)) / 2.0F, cy, 11.5F, this.listening ? theme.accentBright() : theme.textPrimary());
   }

   public boolean mouseClicked(float mx, float my, int button) {
      if (this.listening) {
         if (button == 0) {
            this.listening = false;
            return this.contains(mx, my);
         } else {
            this.setting.set(button);
            this.listening = false;
            UiSounds.keybindSet();
            return true;
         }
      } else if (button == 0 && this.contains(mx, my)) {
         this.listening = true;
         UiSounds.keybindListen();
         return true;
      } else {
         return false;
      }
   }

   public boolean keyPressed(int keyCode) {
      if (!this.listening) {
         return false;
      } else {
         if (keyCode == 256) {
            this.setting.set(-1);
         } else {
            this.setting.set(keyCode);
         }

         this.listening = false;
         UiSounds.keybindSet();
         return true;
      }
   }

   public boolean isListening() {
      return this.listening;
   }
}
