package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.ColorSetting;

public class PlayerEspModule extends Module {
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Highlight color", -1));
   public final BooleanSetting tracers = (BooleanSetting)this.addSetting(new BooleanSetting("Tracers", "Draw lines from the crosshair to each player", false));

   public PlayerEspModule() {
      super("PlayerESP", "Highlights players through walls", Category.RENDER);
   }
}
