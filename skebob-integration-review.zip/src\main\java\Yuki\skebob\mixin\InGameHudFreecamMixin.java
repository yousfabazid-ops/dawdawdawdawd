package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FreecamModule;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({InGameHud.class})
public class InGameHudFreecamMixin {
   @ModifyExpressionValue(
      method = {"renderCrosshair"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/Perspective;isFirstPerson()Z"
)}
   )
   private boolean SkebobClient$showFreecamCrosshair(boolean firstPerson) {
      FreecamModule freecam = FreecamModule.get();
      return firstPerson || freecam != null && freecam.isActive();
   }
}
