package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.world.ClientChunkManager;

public class FreeLookModule extends Module {
   private static FreeLookModule instance;
   public final SliderSetting sensitivity = (SliderSetting)this.addSetting(new SliderSetting("Camera Sensitivity", "How fast the camera moves in Camera mode.", (double)8.0F, (double)0.0F, (double)10.0F, 0.1));
   private float cameraYaw;
   private float cameraPitch;
   private Perspective prePers;
   private ChunkPos lastCameraChunk;
   private int lastLoadDistance = Integer.MIN_VALUE;

   public FreeLookModule() {
      super("FreeLook", "Allows more rotation options in third person.", Category.MISC);
      instance = this;
   }

   public static FreeLookModule get() {
      return instance;
   }

   protected void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         this.cameraYaw = mc.player.getYaw();
         this.cameraPitch = mc.player.getPitch();
         this.prePers = mc.options.getPerspective();
         if (this.prePers != Perspective.THIRD_PERSON_BACK) {
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         }
      }

   }

   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.prePers != null && mc.options.getPerspective() != this.prePers) {
         mc.options.setPerspective(this.prePers);
      }

      this.restoreChunkLoading(mc);
   }

   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         mc.player.setPitch(MathHelper.clamp(mc.player.getPitch(), -90.0F, 90.0F));
         this.cameraPitch = MathHelper.clamp(this.cameraPitch, -90.0F, 90.0F);
      }

   }

   public void syncChunkLoading(Camera camera) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.isActive() && mc.world != null && mc.player != null) {
         ClientChunkManager chunks = mc.world.getChunkManager();
         ChunkPos cameraChunk = new ChunkPos((int)Math.floor(camera.getCameraPos().x) >> 4, (int)Math.floor(camera.getCameraPos().z) >> 4);
         int distance = Math.max(2, Math.min(32, mc.options.getClampedViewDistance()));
         if (distance != this.lastLoadDistance) {
            chunks.updateLoadDistance(distance);
            this.lastLoadDistance = distance;
         }

         if (this.lastCameraChunk == null || cameraChunk.x != this.lastCameraChunk.x || cameraChunk.z != this.lastCameraChunk.z) {
            chunks.setChunkMapCenter(cameraChunk.x, cameraChunk.z);
            this.lastCameraChunk = cameraChunk;
            if (mc.worldRenderer != null) {
               mc.worldRenderer.scheduleTerrainUpdate();
            }
         }
      }

   }

   private void restoreChunkLoading(MinecraftClient mc) {
      this.lastCameraChunk = null;
      this.lastLoadDistance = Integer.MIN_VALUE;
      if (mc.world != null && mc.player != null) {
         ClientChunkManager chunks = mc.world.getChunkManager();
         ChunkPos playerChunk = mc.player.getChunkPos();
         chunks.setChunkMapCenter(playerChunk.x, playerChunk.z);
         chunks.updateLoadDistance(mc.options.getClampedViewDistance());
      }

   }

   public boolean isActive() {
      return this.isEnabled() && MinecraftClient.getInstance().player != null;
   }

   public boolean seeThroughWalls() {
      return this.isActive();
   }

   public boolean cameraMode() {
      return this.isActive();
   }

   public boolean playerMode() {
      return false;
   }

   public void addCameraLook(double deltaX, double deltaY) {
      float sens = this.sensitivity.getFloat();
      if (sens <= 0.0F) {
         sens = 1.0F;
      }

      this.cameraYaw += (float)(deltaX / (double)sens);
      this.cameraPitch += (float)(deltaY / (double)sens);
      if (Math.abs(this.cameraPitch) > 90.0F) {
         this.cameraPitch = this.cameraPitch > 0.0F ? 90.0F : -90.0F;
      }

   }

   public float getCameraYaw() {
      return this.cameraYaw;
   }

   public float getCameraPitch() {
      return this.cameraPitch;
   }
}
