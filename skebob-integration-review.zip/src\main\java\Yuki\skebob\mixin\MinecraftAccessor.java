package Yuki.skebob.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface MinecraftAccessor {
   @Accessor("itemUseCooldown")
   void SkebobClient$setRightClickDelay(int var1);

   @Invoker("doAttack")
   boolean SkebobClient$startAttack();

   @Invoker("doItemUse")
   void SkebobClient$startUseItem();
}
