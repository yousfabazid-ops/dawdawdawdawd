package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FreecamModule;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Camera.class})
public abstract class CameraFreecamMixin {
   @Shadow
   protected abstract void setPos(Vec3d var1);

   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Inject(
      method = {"update"},
      at = {@At("TAIL")}
   )
   private void SkebobClient$freecam(World level, Entity entity, boolean detached, boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
      FreecamModule freecam = FreecamModule.get();
      if (freecam != null && freecam.isActive()) {
         freecam.updatePerFrame(MinecraftClient.getInstance());
         freecam.updateRenderState(partialTick);
         this.setRotation(freecam.getRenderYaw(), freecam.getRenderPitch());
         this.setPos(freecam.getRenderPos());
      }

   }
}
