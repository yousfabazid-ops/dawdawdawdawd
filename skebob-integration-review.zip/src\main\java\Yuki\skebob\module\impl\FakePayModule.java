package Yuki.skebob.module.impl;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.settings.StringSetting;
import Yuki.skebob.util.Amounts;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;

public class FakePayModule extends Module {
   private static final int WHITE = 16777215;
   private static final int RED = 16733525;
   private static final int CURRENCY_COLOR = -16740609;
   public final StringSetting command = (StringSetting)this.addSetting(new StringSetting("Command", "Command name to hijack, without the slash.", "pay", 32, "pay"));
   public final StringSetting currency = (StringSetting)this.addSetting(new StringSetting("Currency", "Symbol before the amount (colored).", "$", 4, "$"));

   public FakePayModule() {
      super("FakePay", "Fakes a /pay for clips â€” blocks the real command", Category.MISC);
   }

   public boolean tryIntercept(String rawCommand) {
      if (this.isEnabled() && rawCommand != null) {
         String[] parts = rawCommand.trim().split("\\s+");
         if (parts.length == 0) {
            return false;
         } else {
            String name = parts[0];
            if (name.startsWith("/")) {
               name = name.substring(1);
            }

            String target = ((String)this.command.get()).trim();
            if (!target.isEmpty() && name.equalsIgnoreCase(target)) {
               this.handle(parts);
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void handle(String[] parts) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null) {
         if (parts.length < 3) {
            this.show(mc, Text.literal("Usage: /" + parts[0] + " <player> <amount>").withColor(16733525));
            this.fail(mc);
         } else {
            String player = parts[1];
            double amount = Amounts.parse(parts[2]);
            if (!Double.isNaN(amount) && !(amount <= (double)0.0F)) {
               if (player.equalsIgnoreCase(mc.player.getGameProfile().name())) {
                  this.show(mc, Text.literal("You can't pay yourself!").withColor(16733525));
                  this.fail(mc);
               } else {
                  FakeStatsModule stats = this.stats();
                  boolean useStats = stats != null && stats.isEnabled();
                  if (useStats && stats.getLiveBalance() < amount) {
                     this.show(mc, Text.literal("You don't have enough money!").withColor(16733525));
                     this.fail(mc);
                  } else {
                     if (useStats) {
                        stats.deduct(amount);
                     }

                     MutableText line = Text.empty().append(Text.literal("You paid " + player).withColor(16777215));
                     String symbol = (String)this.currency.get();
                     if (!symbol.isEmpty()) {
                        line.append(Text.literal(" " + symbol).withColor(36607)).append(Text.literal(Amounts.shortForm(amount)).withColor(16777215));
                     } else {
                        line.append(Text.literal(" " + Amounts.shortForm(amount)).withColor(16777215));
                     }

                     this.show(mc, line);
                     this.succeed(mc);
                  }
               }
            } else {
               this.show(mc, Text.literal("Invalid amount: " + parts[2]).withColor(16733525));
               this.fail(mc);
            }
         }
      }

   }

   private void show(MinecraftClient mc, Text component) {
      if (mc.player != null) {
         mc.player.sendMessage(component, true);
         mc.player.sendMessage(component, false);
      }

   }

   private void succeed(MinecraftClient mc) {
      this.play(mc, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0F);
   }

   private void fail(MinecraftClient mc) {
      this.play(mc, SoundEvents.ENTITY_VILLAGER_NO, 1.0F);
   }

   private void play(MinecraftClient mc, SoundEvent event, float pitch) {
      mc.getSoundManager().play(PositionedSoundInstance.master(event, pitch, 1.0F));
   }

   private FakeStatsModule stats() {
      ModuleManager modules = SkebobClient.modules();
      return modules == null ? null : modules.fakeStats;
   }
}
