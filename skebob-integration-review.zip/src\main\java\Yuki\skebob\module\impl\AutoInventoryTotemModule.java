package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

public class AutoInventoryTotemModule extends Module {
   public final SliderSetting delay = (SliderSetting)this.addSetting(new SliderSetting("Delay", "", (double)4.0F, (double)1.0F, (double)40.0F, (double)1.0F));
   public final BooleanSetting forceTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Force Totem", "", false));
   public final BooleanSetting hotbarTotem = (BooleanSetting)this.addSetting(new BooleanSetting("Hotbar Totem", "", false));
   public final SliderSetting hotbarSlot = (SliderSetting)this.addSetting(new SliderSetting("Hotbar Slot", "", (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   public final SliderSetting hotbarDelay = (SliderSetting)this.addSetting(new SliderSetting("Hotbar Delay", "", (double)4.0F, (double)1.0F, (double)40.0F, (double)1.0F));
   private int tickCounter;

   public AutoInventoryTotemModule() {
      super("Inv Totem", "Moves totems only while inventory (E) is open â€” click-based, not world-auto", Category.COMBAT);
   }

   protected void onEnable() {
      this.tickCounter = 0;
   }

   protected void onDisable() {
      this.tickCounter = 0;
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null && client.currentScreen instanceof InventoryScreen) {
         ++this.tickCounter;
         int wait = (Boolean)this.hotbarTotem.get() && this.needsHotbarWork(client) && !this.needsOffhandWork(client) ? this.hotbarDelay.getInt() : this.delay.getInt();
         if (this.tickCounter >= wait) {
            this.tickCounter = 0;
            if ((Boolean)this.hotbarTotem.get() && this.needsHotbarWork(client)) {
               int source = findTotemInMainInventory(client);
               if (source != -1) {
                  int hotbarIndex = this.hotbarSlot.getInt() - 1;
                  if (hotbarIndex >= 0 && hotbarIndex <= 8) {
                     this.performHotbarSwap(client, source, hotbarIndex);
                  }
               }
            } else if (this.needsOffhandWork(client)) {
               int totemIdx = findTotemForOffhand(client);
               if (totemIdx != -1) {
                  this.performOffhandSwap(client, totemIdx);
               }
            }
         }
      }

   }

   private boolean needsOffhandWork(MinecraftClient client) {
      boolean hasTotemOffhand = client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
      return (Boolean)this.forceTotem.get() || !hasTotemOffhand;
   }

   private boolean needsHotbarWork(MinecraftClient client) {
      if (!(Boolean)this.hotbarTotem.get()) {
         return false;
      } else {
         int slot = this.hotbarSlot.getInt() - 1;
         return !client.player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING);
      }
   }

   private static int findTotemInMainInventory(MinecraftClient client) {
      for(int i = 9; i < 36; ++i) {
         if (client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
            return i;
         }
      }

      return -1;
   }

   private static int findTotemInHotbar(MinecraftClient client) {
      for(int i = 0; i < 9; ++i) {
         if (client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
            return i;
         }
      }

      return -1;
   }

   private static int findTotemForOffhand(MinecraftClient client) {
      int main = findTotemInMainInventory(client);
      return main != -1 ? main : findTotemInHotbar(client);
   }

   private static int toScreenSlot(int invIndex) {
      return invIndex < 9 ? invIndex + 36 : invIndex;
   }

   private void performOffhandSwap(MinecraftClient client, int totemInvIndex) {
      int syncId = client.player.currentScreenHandler.syncId;
      int screenSlot = toScreenSlot(totemInvIndex);
      client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, client.player);
      client.interactionManager.clickSlot(syncId, 45, 0, SlotActionType.PICKUP, client.player);
      client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, client.player);
   }

   private void performHotbarSwap(MinecraftClient client, int sourceInvIndex, int hotbarIndex) {
      int syncId = client.player.currentScreenHandler.syncId;
      client.interactionManager.clickSlot(syncId, sourceInvIndex, hotbarIndex, SlotActionType.SWAP, client.player);
   }
}
