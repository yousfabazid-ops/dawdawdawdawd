package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FreecamModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public abstract class LocalPlayerFreecamMixin {
   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$freecamReapplyBeforeAiStep(CallbackInfo ci) {
      this.SkebobClient$reapply();
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")}
   )
   private void SkebobClient$freecamReapplyBeforeSendPosition(CallbackInfo ci) {
      this.SkebobClient$reapply();
   }

   private void SkebobClient$reapply() {
      ClientPlayerEntity self = (ClientPlayerEntity)(Object)this;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == self) {
         FreecamModule f = FreecamModule.get();
         if (f != null && f.isActive()) {
            FreecamModule.reapplyBodyInput(mc);
         }
      }

   }
}
