package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.gui.ClickGuiScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public class KeyboardHandlerMixin {
   @Inject(
      method = {"onKey(JILnet/minecraft/client/input/KeyInput;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void SkebobClient$dispatchModuleKeybinds(long window, int action, KeyInput keyEvent, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (SkebobClient.modules() != null && action == 1) {
         if (minecraft.currentScreen == null && minecraft.world != null) {
            if (SkebobClient.modules().onKeyPressed(keyEvent.comp_4795())) {
               ci.cancel();
            }
         } else if ((keyEvent.comp_4795() == 340 || keyEvent.comp_4795() == 344) && minecraft.currentScreen != null && shiftOpensGui(minecraft.currentScreen)) {
            minecraft.setScreen(new ClickGuiScreen(minecraft.currentScreen));
            ci.cancel();
         }
      }

   }

   private static boolean shiftOpensGui(Screen screen) {
      if (!(screen instanceof ClickGuiScreen) && !(screen instanceof ChatScreen) && !(screen instanceof HandledScreen) && !(screen instanceof AbstractSignEditScreen) && !(screen instanceof BookEditScreen)) {
         Element var2 = screen.getFocused();
         if (var2 instanceof TextFieldWidget) {
            TextFieldWidget editBox = (TextFieldWidget)var2;
            if (editBox.isFocused()) {
               boolean var10000 = false;
               return var10000;
            }
         }

         boolean var10000 = true;
         return var10000;
      } else {
         return false;
      }
   }
}
