package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.settings.StringSetting;
import Yuki.skebob.util.Amounts;
import java.util.Locale;
import java.util.Objects;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

public class FakeStatsModule extends Module {
   private static final int GRAY = 11184810;
   private static final int GREEN = 5635925;
   private static final String[] MONEY_KEYS = new String[]{"money", "balance", "coins", "cash"};
   private static final String[] SHARD_KEYS = new String[]{"shard"};
   private static final String[] KILL_KEYS = new String[]{"kill"};
   private static final String[] DEATH_KEYS = new String[]{"death"};
   private static final String[] PLAYTIME_KEYS = new String[]{"playtime", "play time", "time played", "played"};
   public final StringSetting money = (StringSetting)this.addSetting(new StringSetting("Money", "Your fake balance (1m, 67k, 250000). Wired to FakePay. Blank = off.", "1m", 32, "e.g. 1m, 250k"));
   public final StringSetting shards = (StringSetting)this.addSetting(new StringSetting("Shards", "Fake shard count. Blank = off.", "", 32, "e.g. 9,999"));
   public final SliderSetting shardsLine = (SliderSetting)this.addSetting((new SliderSetting("Shards Line", "Which sidebar line is shards. 0 = auto by name.", (double)2.0F, (double)0.0F, (double)15.0F, (double)1.0F)).withLabel(FakeStatsModule::lineLabel));
   public final StringSetting kills = (StringSetting)this.addSetting(new StringSetting("Kills", "Fake kill count. Blank = off.", "", 32, "e.g. 1,000"));
   public final SliderSetting killsLine = (SliderSetting)this.addSetting((new SliderSetting("Kills Line", "Which sidebar line is kills. 0 = auto by name.", (double)3.0F, (double)0.0F, (double)15.0F, (double)1.0F)).withLabel(FakeStatsModule::lineLabel));
   public final StringSetting deaths = (StringSetting)this.addSetting(new StringSetting("Deaths", "Fake death count. Blank = off.", "", 32, "e.g. 0"));
   public final SliderSetting deathsLine = (SliderSetting)this.addSetting((new SliderSetting("Deaths Line", "Which sidebar line is deaths. 0 = auto by name.", (double)4.0F, (double)0.0F, (double)15.0F, (double)1.0F)).withLabel(FakeStatsModule::lineLabel));
   public final StringSetting playtime = (StringSetting)this.addSetting(new StringSetting("Playtime", "Fake playtime, any text. Blank = off.", "", 32, "e.g. 365d 12h"));
   public final SliderSetting playtimeLine = (SliderSetting)this.addSetting((new SliderSetting("Playtime Line", "Which sidebar line is playtime. 0 = auto by name.", (double)5.0F, (double)0.0F, (double)15.0F, (double)1.0F)).withLabel(FakeStatsModule::lineLabel));
   private String lastMoneyText;
   private double liveBalance;
   private int widthIndex;
   private int drawIndex;

   public FakeStatsModule() {
      super("FakeStats", "Fake balance + editable leaderboard, wired to FakePay", Category.MISC);
      this.shardsLine.visibleWhen(() -> !((String)this.shards.get()).isBlank());
      this.killsLine.visibleWhen(() -> !((String)this.kills.get()).isBlank());
      this.deathsLine.visibleWhen(() -> !((String)this.deaths.get()).isBlank());
      this.playtimeLine.visibleWhen(() -> !((String)this.playtime.get()).isBlank());
   }

   protected void onEnable() {
      this.lastMoneyText = null;
      this.syncFromSetting();
   }

   private static String lineLabel(double v) {
      return (int)v == 0 ? "Auto" : "Line " + (int)v;
   }

   private void syncFromSetting() {
      String text = (String)this.money.get();
      if (!Objects.equals(text, this.lastMoneyText)) {
         this.lastMoneyText = text;
         double parsed = Amounts.parse(text);
         this.liveBalance = Double.isNaN(parsed) ? (double)0.0F : Math.max((double)0.0F, parsed);
      }

   }

   public double getLiveBalance() {
      this.syncFromSetting();
      return this.liveBalance;
   }

   public void deduct(double amount) {
      this.syncFromSetting();
      this.liveBalance = Math.max((double)0.0F, this.liveBalance - Math.max((double)0.0F, amount));
   }

   public void beginSidebar() {
      this.widthIndex = 0;
      this.drawIndex = 0;
   }

   public Text rewriteForWidth(Text comp) {
      return this.rewriteLine(comp, true);
   }

   public Text rewriteForDraw(Text comp) {
      return this.rewriteLine(comp, false);
   }

   private Text rewriteLine(Text comp, boolean widthPass) {
      if (this.isEnabled()) {
         String text = stripCodes(comp.getString());
         if (text.isBlank()) {
            return comp;
         } else {
            int var10000;
            if (widthPass) {
               int var10002 = this.widthIndex;
               var10000 = var10002;
               this.widthIndex = var10002 + 1;
            } else {
               int var5 = this.drawIndex;
               var10000 = var5;
               this.drawIndex = var5 + 1;
            }

            return this.applyOverride(var10000, text.toLowerCase(Locale.ROOT), comp);
         }
      } else {
         return comp;
      }
   }

   private Text applyOverride(int line, String lower, Text comp) {
      if (!((String)this.money.get()).isBlank() && line == 0) {
         return Amounts.replaceNumberStyled(comp, Amounts.shortForm(this.getLiveBalance()));
      } else if (!((String)this.shards.get()).isBlank() && matches(this.shardsLine, line, lower, SHARD_KEYS)) {
         return Amounts.replaceNumberStyled(comp, ((String)this.shards.get()).trim());
      } else if (!((String)this.kills.get()).isBlank() && matches(this.killsLine, line, lower, KILL_KEYS)) {
         return Amounts.replaceNumberStyled(comp, ((String)this.kills.get()).trim());
      } else if (!((String)this.deaths.get()).isBlank() && matches(this.deathsLine, line, lower, DEATH_KEYS)) {
         return Amounts.replaceNumberStyled(comp, ((String)this.deaths.get()).trim());
      } else {
         return !((String)this.playtime.get()).isBlank() && matches(this.playtimeLine, line, lower, PLAYTIME_KEYS) ? Amounts.replaceValueStyled(comp, ((String)this.playtime.get()).trim()) : comp;
      }
   }

   private static boolean matches(SliderSetting lineSetting, int line, String lower, String[] keys) {
      int configured = lineSetting.getInt();
      if (configured > 0) {
         return line + 1 == configured;
      } else {
         return containsAny(lower, keys);
      }
   }

   private static boolean containsAny(String haystack, String[] keys) {
      for(String k : keys) {
         if (haystack.contains(k)) {
            return true;
         }
      }

      return false;
   }

   public boolean tryInterceptBalance(String command) {
      if (this.isEnabled()) {
         String[] parts = command.trim().split("\\s+");
         if (parts.length == 0) {
            return false;
         } else {
            String name = parts[0];
            if (name.startsWith("/")) {
               name = name.substring(1);
            }

            if (!name.equalsIgnoreCase("bal") && !name.equalsIgnoreCase("balance")) {
               return false;
            } else {
               MinecraftClient mc = MinecraftClient.getInstance();
               if (mc.player == null) {
                  return false;
               } else if (parts.length >= 2 && !parts[1].equalsIgnoreCase(mc.player.getGameProfile().name())) {
                  return false;
               } else {
                  String amount = Amounts.shortForm(this.getLiveBalance());
                  Text line = Text.empty().append(Text.literal("You have ").withColor(11184810)).append(Text.literal(amount).withColor(5635925));
                  mc.player.sendMessage(line, false);
                  mc.player.sendMessage(line, true);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private static String stripCodes(String s) {
      return s == null ? "" : s.replaceAll("(?i)Â§[0-9A-FK-OR]", "");
   }
}
