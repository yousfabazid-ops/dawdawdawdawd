package Yuki.skebob.render;

import Yuki.skebob.module.Modules;
import Yuki.skebob.suschunk.SusChunkScanner;
import Yuki.skebob.util.Colors;

import java.util.Map;
import java.util.Set;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class SusChunkRenderer {

   private static final int SUS_RED = 0xFF0000;
   private static final int DEEPSLATE_CYAN = 0x00FFFF;

   private SusChunkRenderer() {
   }

   public static void reset() {
   }

   public static String debugState() {
      return "Sus Chunk Finder";
   }

   public static void render(
      VertexConsumerProvider.Immediate bufferSource,
      MatrixStack poseStack,
      Vec3d camera,
      Modules.SusChunkFinderModule module
   ) {
      SusChunkScanner scanner =
         module.scanner;

      int alpha =
         module.alpha.getInt();

      if (alpha < 10) {
         alpha = 10;
      }

      if (alpha > 255) {
         alpha = 255;
      }

      renderHeatmap(
         bufferSource,
         poseStack,
         camera,
         scanner,
         alpha
      );

      renderDeepslate(
         bufferSource,
         poseStack,
         camera,
         scanner,
         alpha
      );

      FlatOverlay.flush(bufferSource);
   }

   private static void renderHeatmap(
      VertexConsumerProvider.Immediate bufferSource,
      MatrixStack poseStack,
      Vec3d camera,
      SusChunkScanner scanner,
      int alpha
   ) {
      Map<Long, Integer> heatmap =
         scanner.chunkHeatmap();

      int minimum =
         scanner.sensitivity();

      for (Map.Entry<Long, Integer> entry :
           heatmap.entrySet()) {

         long key =
            entry.getKey();

         int count =
            entry.getValue();

         if (count < minimum) {
            continue;
         }

         ChunkPos pos =
            new ChunkPos(
               ChunkPos.getPackedX(key),
               ChunkPos.getPackedZ(key)
            );

         if (!scanner.loadedChunkPositions()
               .contains(key)) {
            continue;
         }

         int neighbourCount = 0;

         for (int dx = -1;
              dx <= 1;
              dx++) {

            for (int dz = -1;
                 dz <= 1;
                 dz++) {

               if (dx == 0 && dz == 0) {
                  continue;
               }

               long neighbourKey =
                  ChunkPos.toLong(
                     pos.x + dx,
                     pos.z + dz
                  );

               if (scanner.loadedChunkPositions()
                     .contains(neighbourKey)) {

                  neighbourCount++;
               }
            }
         }

         if (neighbourCount < 3) {
            continue;
         }

         double x0 =
            pos.getStartX();

         double z0 =
            pos.getStartZ();

         float strength =
            Math.min(
               1.0F,
               alpha / 255.0F
            );

         FlatOverlay.fillQuad(
            bufferSource,
            poseStack,
            camera,
            x0,
            z0,
            x0 + 16.0,
            z0 + 16.0,
            63.0,
            Colors.withAlpha(
               SUS_RED,
               strength
            )
         );
      }
   }

   private static void renderDeepslate(
      VertexConsumerProvider.Immediate bufferSource,
      MatrixStack poseStack,
      Vec3d camera,
      SusChunkScanner scanner,
      int alpha
   ) {
      Set<BlockPos> blocks =
         scanner.suspiciousDeepslateBlocks();

      if (blocks.isEmpty()) {
         return;
      }

      float strength =
         Math.min(
            1.0F,
            alpha / 255.0F
         );

      for (BlockPos pos : blocks) {
         ChunkPos chunk =
            new ChunkPos(
               pos.getX() >> 4,
               pos.getZ() >> 4
            );

         if (!scanner.loadedChunkPositions()
               .contains(chunk.toLong())) {
            continue;
         }

         FlatOverlay.fillQuad(
            bufferSource,
            poseStack,
            camera,
            pos.getX(),
            pos.getZ(),
            pos.getX() + 1.0,
            pos.getZ() + 1.0,
            pos.getY(),
            Colors.withAlpha(
               DEEPSLATE_CYAN,
               strength
            )
         );
      }
   }
}
