package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FakeLagModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class FakeLagRendererMixin {

    @Inject(
        method = "renderTargetBlockOutline(Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/util/math/MatrixStack;ZLnet/minecraft/client/render/state/WorldRenderState;)V",
        at = @At("TAIL")
    )
    private void skebob$renderFakeLagBox(
        VertexConsumerProvider.Immediate bufferSource,
        MatrixStack poseStack,
        boolean translucentPass,
        WorldRenderState levelRenderState,
        CallbackInfo ci
    ) {
        MinecraftClient mc =
            MinecraftClient.getInstance();

        if (mc.gameRenderer == null) {
            return;
        }

        if (mc.gameRenderer.getCamera() == null) {
            return;
        }

        FakeLagModule.renderBox(
            bufferSource,
            poseStack,
            mc.gameRenderer.getCamera().getCameraPos()
        );
    }
}