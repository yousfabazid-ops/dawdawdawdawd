package Yuki.skebob.mixin;

import Yuki.skebob.module.impl.FakeLagModule;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class FakeLagPacketListenerMixin {

    @Inject(
        method = "onGameJoin",
        at = @At("HEAD")
    )
    private void skebob$gameJoin(
        GameJoinS2CPacket packet,
        CallbackInfo ci
    ) {
        FakeLagModule module =
            FakeLagModule.getInstance();

        if (module != null) {
            module.onServerLifecyclePacket(packet);
        }
    }

    @Inject(
        method = "onPlayerRespawn",
        at = @At("HEAD")
    )
    private void skebob$playerRespawn(
        PlayerRespawnS2CPacket packet,
        CallbackInfo ci
    ) {
        FakeLagModule module =
            FakeLagModule.getInstance();

        if (module != null) {
            module.onServerLifecyclePacket(packet);
        }
    }
}