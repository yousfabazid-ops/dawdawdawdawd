package Yuki.skebob.mixin;

import Yuki.skebob.render.custommodel.CustomPlayerModelState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(PlayerEntityRenderState.class)
public abstract class PlayerEntityRenderStateSkinChangerMixin implements CustomPlayerModelState {
    @Unique private String skebob$customModel = "";

    @Override
    public boolean skebob$hasCustomModel() {
        return !this.skebob$customModel.isEmpty();
    }

    @Override
    public String skebob$getCustomModel() {
        return this.skebob$customModel;
    }

    @Override
    public void skebob$setCustomModel(String model) {
        this.skebob$customModel = model == null ? "" : model;
    }
}
