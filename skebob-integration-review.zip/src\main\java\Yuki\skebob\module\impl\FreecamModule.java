package Yuki.skebob.module.impl;

import Yuki.skebob.mixin.ClientInputAccessor;
import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.SliderSetting;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.network.ClientPlayerEntity;

public class FreecamModule extends Module {
   private static FreecamModule instance;
   public final SliderSetting speed = (SliderSetting)this.addSetting(new SliderSetting("Speed", "Camera fly speed", (double)1.0F, 0.1, (double)50.0F, 0.1, "x"));
   private double currentX;
   private double currentY;
   private double currentZ;
   private double velocityX;
   private double velocityY;
   private double velocityZ;
   private double prevX;
   private double prevY;
   private double prevZ;
   private float currentYaw;
   private float currentPitch;
   private float prevYaw;
   private float prevPitch;
   private double renderX;
   private double renderY;
   private double renderZ;
   private float renderYaw;
   private float renderPitch;
   private long lastFrameNanos;
   private boolean renderStateInitialized;
   private double savedX;
   private double savedY;
   private double savedZ;
   private float savedYaw;
   private float savedPitch;
   private boolean savedAbilitiesFlying;
   private boolean savedSmartCull;
   private Perspective perspectiveBeforeFreecam;
   private boolean switchedPerspectiveForBody;
   private ChunkPos lastSyncedCamChunk;
   private int lastSyncedLoadDistance = Integer.MIN_VALUE;
   private boolean activationPending;
   private boolean active = false;
   private boolean latchedForward;
   private boolean latchedBack;
   private boolean latchedLeft;
   private boolean latchedRight;
   private boolean latchedJump;
   private boolean latchedSneak;
   private boolean latchedSprint;
   private int autopilotWarmupTicks;

   public FreecamModule() {
      super("Freecam", "Detached camera (WASD = fly). Body can keep walking; mining uses real aim.", Category.MISC);
      instance = this;
   }

   public static FreecamModule get() {
      return instance;
   }

   protected void onEnable() {
      this.activationPending = true;
      this.active = false;
      this.velocityX = this.velocityY = this.velocityZ = (double)0.0F;
      this.lastFrameNanos = 0L;
   }

   protected void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      this.clearMovementLatches();
      this.activationPending = false;
      this.active = false;
      this.velocityX = this.velocityY = this.velocityZ = (double)0.0F;
      this.lastFrameNanos = 0L;
      if (this.switchedPerspectiveForBody) {
         mc.options.setPerspective(this.perspectiveBeforeFreecam);
         this.switchedPerspectiveForBody = false;
      }

      this.restoreViewOnlyClientState(mc);
      this.restoreVanillaChunkLoading(mc);
      if (mc.player != null) {
         mc.player.getAbilities().flying = this.savedAbilitiesFlying;
      }

   }

   public void tryCompleteActivation(MinecraftClient mc) {
      if (this.isEnabled() && this.activationPending && mc.player != null && mc.world != null) {
         this.savedX = mc.player.getX();
         this.savedY = mc.player.getY();
         this.savedZ = mc.player.getZ();
         this.savedYaw = mc.player.getYaw();
         this.savedPitch = mc.player.getPitch();
         this.currentX = this.prevX = this.savedX;
         this.currentY = this.prevY = this.savedY + (double)mc.player.getStandingEyeHeight();
         this.currentZ = this.prevZ = this.savedZ;
         this.currentYaw = this.prevYaw = this.savedYaw;
         this.currentPitch = this.prevPitch = this.savedPitch;
         this.velocityX = this.velocityY = this.velocityZ = (double)0.0F;
         this.lastFrameNanos = 0L;
         this.renderStateInitialized = false;
         this.savedAbilitiesFlying = mc.player.getAbilities().flying;
         this.switchedPerspectiveForBody = false;
         this.perspectiveBeforeFreecam = mc.options.getPerspective();
         if (this.perspectiveBeforeFreecam.isFirstPerson()) {
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            this.switchedPerspectiveForBody = true;
         }

         this.activationPending = false;
         this.active = true;
         this.captureMovementLatches(mc);
         this.maybeLatchWalkFromVelocity(mc);
         this.autopilotWarmupTicks = 40;
         this.lastSyncedCamChunk = null;
         this.lastSyncedLoadDistance = Integer.MIN_VALUE;
         this.applyViewOnlyClientState(mc);
         this.syncFreecamChunkLoading(mc);
         reapplyBodyInput(mc);
      }

   }

   private void captureMovementLatches(MinecraftClient mc) {
      GameOptions o = mc.options;
      ClientPlayerEntity player = mc.player;
      PlayerInput ki = player != null ? player.input.playerInput : PlayerInput.DEFAULT;
      this.latchedForward = o.forwardKey.isPressed() || ki.comp_3159();
      this.latchedBack = o.backKey.isPressed() || ki.comp_3160();
      this.latchedLeft = o.leftKey.isPressed() || ki.comp_3161();
      this.latchedRight = o.rightKey.isPressed() || ki.comp_3162();
      this.latchedJump = o.jumpKey.isPressed() || ki.comp_3163();
      this.latchedSneak = o.sneakKey.isPressed() || ki.sneak() || player != null && player.isSneaking();
      this.latchedSprint = o.sprintKey.isPressed() || ki.comp_3165();
      this.mergeLatchFromLivingSpeed(mc.player);
   }

   public void mergeAutopilotFromCurrentState(MinecraftClient mc) {
      if (mc.player != null) {
         this.latchedSneak |= mc.player.isSneaking();
         this.mergeLatchFromLivingSpeed(mc.player);
         this.mergeVelocityIntoLatch(mc.player);
      }

   }

   private void mergeLatchFromLivingSpeed(ClientPlayerEntity player) {
      if (player != null) {
         float fs = player.forwardSpeed;
         float ss = player.sidewaysSpeed;
         if (fs > 0.015F) {
            this.latchedForward = true;
         }

         if (fs < -0.015F) {
            this.latchedBack = true;
         }

         if (ss > 0.015F) {
            this.latchedLeft = true;
         }

         if (ss < -0.015F) {
            this.latchedRight = true;
         }
      }

   }

   private void mergeVelocityIntoLatch(ClientPlayerEntity player) {
      Vec3d vel = player.getVelocity();
      double vx = vel.x;
      double vz = vel.z;
      if (!(vx * vx + vz * vz < 1.0E-10)) {
         Vec3d flatLook = flatLook(player.getYaw());
         double dot = vx * flatLook.x + vz * flatLook.z;
         double perp = vx * -flatLook.z + vz * flatLook.x;
         if (Math.abs(dot) >= Math.abs(perp)) {
            if (dot > 0.008) {
               this.latchedForward = true;
            } else if (dot < -0.008) {
               this.latchedBack = true;
            }
         } else if (perp > 0.008) {
            this.latchedLeft = true;
         } else if (perp < -0.008) {
            this.latchedRight = true;
         }
      }

   }

   private void maybeLatchWalkFromVelocity(MinecraftClient mc) {
      if (mc.player != null && !this.latchedForward && !this.latchedBack && !this.latchedLeft && !this.latchedRight) {
         Vec3d vel = mc.player.getVelocity();
         double vx = vel.x;
         double vz = vel.z;
         if (!(vx * vx + vz * vz < 1.0E-8)) {
            Vec3d flatLook = flatLook(mc.player.getYaw());
            double dot = vx * flatLook.x + vz * flatLook.z;
            double perp = vx * -flatLook.z + vz * flatLook.x;
            if (Math.abs(dot) > Math.abs(perp)) {
               if (dot > 0.008) {
                  this.latchedForward = true;
               } else if (dot < -0.008) {
                  this.latchedBack = true;
               }
            } else if (perp > 0.008) {
               this.latchedLeft = true;
            } else if (perp < -0.008) {
               this.latchedRight = true;
            }
         }
      }

   }

   private static Vec3d flatLook(float yawDeg) {
      double yawRad = Math.toRadians((double)yawDeg);
      return new Vec3d(-Math.sin(yawRad), (double)0.0F, Math.cos(yawRad));
   }

   private void clearMovementLatches() {
      this.latchedForward = this.latchedBack = this.latchedLeft = this.latchedRight = false;
      this.latchedJump = this.latchedSneak = this.latchedSprint = false;
      this.autopilotWarmupTicks = 0;
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (this.isEnabled()) {
         this.tryCompleteActivation(client);
         if (this.active && client.player != null) {
            if (this.autopilotWarmupTicks > 0) {
               --this.autopilotWarmupTicks;
               this.mergeAutopilotFromCurrentState(client);
            }

            ClientPlayerEntity p = client.player;
            if (p.getAbilities().creativeMode) {
               p.getAbilities().flying = false;
            }

            this.syncFreecamChunkLoading(client);
         }
      }

   }

   public void updatePerFrame(MinecraftClient client) {
      if (this.active && client.player != null) {
         long now = System.nanoTime();
         if (this.lastFrameNanos == 0L) {
            this.lastFrameNanos = now;
         } else {
            double deltaSeconds = Math.min(0.1, Math.max((double)0.0F, (double)(now - this.lastFrameNanos) / (double)1.0E9F));
            this.lastFrameNanos = now;
            if (!(deltaSeconds < 0.001)) {
               GameOptions options = client.options;
               double forward = options.forwardKey.isPressed() ? (double)1.0F : (double)0.0F;
               forward -= options.backKey.isPressed() ? (double)1.0F : (double)0.0F;
               double strafe = options.leftKey.isPressed() ? (double)1.0F : (double)0.0F;
               strafe -= options.rightKey.isPressed() ? (double)1.0F : (double)0.0F;
               double vertical = options.jumpKey.isPressed() ? (double)1.0F : (double)0.0F;
               vertical -= options.sneakKey.isPressed() ? (double)1.0F : (double)0.0F;
               double horizontalLength = Math.sqrt(forward * forward + strafe * strafe);
               if (horizontalLength > (double)1.0F) {
                  forward /= horizontalLength;
                  strafe /= horizontalLength;
               }

               double yawRad = Math.toRadians((double)this.currentYaw);
               double targetX = (-Math.sin(yawRad) * forward + Math.cos(yawRad) * strafe) * (double)this.speed.getFloat() * (double)7.0F;
               double targetZ = (Math.cos(yawRad) * forward + Math.sin(yawRad) * strafe) * (double)this.speed.getFloat() * (double)7.0F;
               double targetY = vertical * (double)this.speed.getFloat() * (double)7.0F;
               double accelerationBlend = (double)1.0F - Math.exp((double)-8.0F * deltaSeconds);
               double frictionBlend = (double)1.0F - Math.exp((double)-6.0F * deltaSeconds);
               this.velocityX += (targetX - this.velocityX) * accelerationBlend;
               this.velocityY += (targetY - this.velocityY) * accelerationBlend;
               this.velocityZ += (targetZ - this.velocityZ) * accelerationBlend;
               if (forward == (double)0.0F && strafe == (double)0.0F) {
                  this.velocityX -= this.velocityX * frictionBlend;
                  this.velocityZ -= this.velocityZ * frictionBlend;
               }

               if (vertical == (double)0.0F) {
                  this.velocityY -= this.velocityY * frictionBlend;
               }

               this.prevX = this.currentX;
               this.prevY = this.currentY;
               this.prevZ = this.currentZ;
               this.currentX += this.velocityX * deltaSeconds;
               this.currentY += this.velocityY * deltaSeconds;
               this.currentZ += this.velocityZ * deltaSeconds;
            }
         }
      }
   }

   public static void reapplyBodyInput(MinecraftClient client) {
      FreecamModule f = instance;
      if (f != null && f.isActive() && client.player != null) {
         ClientPlayerEntity player = client.player;
         GameOptions o = client.options;
         boolean mergePhysical = false;
         boolean fwd = f.latchedForward || mergePhysical && o.forwardKey.isPressed();
         boolean back = f.latchedBack || mergePhysical && o.backKey.isPressed();
         boolean left = f.latchedLeft || mergePhysical && o.leftKey.isPressed();
         boolean right = f.latchedRight || mergePhysical && o.rightKey.isPressed();
         boolean jump = f.latchedJump;
         boolean sneak = f.latchedSneak || mergePhysical && o.sneakKey.isPressed();
         boolean sprint = f.latchedSprint || mergePhysical && o.sprintKey.isPressed();
         if (mergePhysical) {
            if (o.backKey.isPressed()) {
               f.latchedForward = false;
            }

            if (o.forwardKey.isPressed()) {
               f.latchedBack = false;
            }

            if (o.rightKey.isPressed()) {
               f.latchedLeft = false;
            }

            if (o.leftKey.isPressed()) {
               f.latchedRight = false;
            }
         }

         player.input.playerInput = new PlayerInput(fwd, back, left, right, jump, sneak, sprint);
         float sx = (left ? 1.0F : 0.0F) - (right ? 1.0F : 0.0F);
         float sz = (fwd ? 1.0F : 0.0F) - (back ? 1.0F : 0.0F);
         Vec2f moveVector = (new Vec2f(sx, sz)).normalize();
         ((ClientInputAccessor)player.input).SkebobClient$setMoveVector(moveVector);
         player.setSneaking(sneak);
      }

   }

   public boolean hasLatchedLocomotion() {
      return this.latchedForward || this.latchedBack || this.latchedLeft || this.latchedRight || this.latchedJump || this.latchedSneak;
   }

   private void syncFreecamChunkLoading(MinecraftClient client) {
      if (this.active && client.world != null && client.player != null) {
         ClientChunkManager ccm = client.world.getChunkManager();
         ChunkPos camChunk = new ChunkPos((int)Math.floor(this.currentX) >> 4, (int)Math.floor(this.currentZ) >> 4);
         ChunkPos bodyChunk = client.player.getChunkPos();
         ChunkPos centerChunk = camChunk;
         int sepCamBody = Math.max(Math.abs(camChunk.x - bodyChunk.x), Math.abs(camChunk.z - bodyChunk.z));
         if (sepCamBody + 4 > 32) {
            int mx = (camChunk.x + bodyChunk.x) / 2;
            int mz = (camChunk.z + bodyChunk.z) / 2;
            centerChunk = new ChunkPos(mx, mz);
         }

         int spread = Math.max(Math.max(Math.abs(centerChunk.x - camChunk.x), Math.abs(centerChunk.z - camChunk.z)), Math.max(Math.abs(centerChunk.x - bodyChunk.x), Math.abs(centerChunk.z - bodyChunk.z)));
         int userDist = 12;
         int dist = Math.min(32, Math.max(userDist, spread + 4));
         if (dist != this.lastSyncedLoadDistance) {
            ccm.updateLoadDistance(dist);
            this.lastSyncedLoadDistance = dist;
         }

         if (this.lastSyncedCamChunk == null || centerChunk.x != this.lastSyncedCamChunk.x || centerChunk.z != this.lastSyncedCamChunk.z) {
            ccm.setChunkMapCenter(centerChunk.x, centerChunk.z);
            this.lastSyncedCamChunk = centerChunk;
            if (client.worldRenderer != null) {
               client.worldRenderer.scheduleTerrainUpdate();
            }
         }
      }

   }

   private void restoreVanillaChunkLoading(MinecraftClient client) {
      this.lastSyncedCamChunk = null;
      this.lastSyncedLoadDistance = Integer.MIN_VALUE;
      if (client.world != null) {
         ClientChunkManager ccm = client.world.getChunkManager();
         if (client.player != null) {
            ChunkPos p = client.player.getChunkPos();
            ccm.setChunkMapCenter(p.x, p.z);
         }

         ccm.updateLoadDistance(client.options.getClampedViewDistance());
         if (client.worldRenderer != null) {
            client.worldRenderer.scheduleTerrainUpdate();
         }
      }

   }

   private void applyViewOnlyClientState(MinecraftClient mc) {
      this.savedSmartCull = mc.chunkCullingEnabled;
      mc.chunkCullingEnabled = false;
   }

   private void restoreViewOnlyClientState(MinecraftClient mc) {
      mc.chunkCullingEnabled = this.savedSmartCull;
      if (mc.interactionManager != null) {
         mc.interactionManager.cancelBlockBreaking();
      }

   }

   public boolean isActive() {
      return this.isEnabled() && this.active;
   }

   public boolean isShowPlayerModel() {
      return true;
   }

   public boolean isShowHands() {
      return true;
   }

   public boolean renderHands() {
      return !this.isActive() || this.isShowHands();
   }

   public boolean wasHoldingSneak() {
      return this.latchedSneak;
   }

   public double getInterpolatedX(float tickDelta) {
      return MathHelper.lerp((double)this.smoothTick(tickDelta), this.prevX, this.currentX);
   }

   public double getInterpolatedY(float tickDelta) {
      return MathHelper.lerp((double)this.smoothTick(tickDelta), this.prevY, this.currentY);
   }

   public double getInterpolatedZ(float tickDelta) {
      return MathHelper.lerp((double)this.smoothTick(tickDelta), this.prevZ, this.currentZ);
   }

   public float getInterpolatedYaw(float tickDelta) {
      return MathHelper.lerpAngleDegrees(this.smoothTick(tickDelta), this.prevYaw, this.currentYaw);
   }

   public float getInterpolatedPitch(float tickDelta) {
      return MathHelper.lerp(this.smoothTick(tickDelta), this.prevPitch, this.currentPitch);
   }

   private float smoothTick(float tickDelta) {
      return Math.clamp(tickDelta, 0.0F, 1.0F);
   }

   public Vec3d getInterpolatedPos(float tickDelta) {
      return new Vec3d(this.getInterpolatedX(tickDelta), this.getInterpolatedY(tickDelta), this.getInterpolatedZ(tickDelta));
   }

   public void updateRenderState(float tickDelta) {
      if (!this.renderStateInitialized) {
         this.renderStateInitialized = true;
      }

      this.renderX = this.currentX;
      this.renderY = this.currentY;
      this.renderZ = this.currentZ;
      this.renderYaw = this.currentYaw;
      this.renderPitch = this.currentPitch;
   }

   public Vec3d getRenderPos() {
      return new Vec3d(this.renderX, this.renderY, this.renderZ);
   }

   public float getRenderYaw() {
      return this.renderYaw;
   }

   public float getRenderPitch() {
      return this.renderPitch;
   }

   public void setRotation(float yaw, float pitch) {
      this.currentYaw = yaw;
      this.currentPitch = MathHelper.clamp(pitch, -90.0F, 90.0F);
   }

   public float getCurrentYaw() {
      return this.currentYaw;
   }

   public float getCurrentPitch() {
      return this.currentPitch;
   }

   public float getLookSensitivity() {
      return 1.0F;
   }

   public void adjustSpeed(double wheelDelta) {
      if (wheelDelta != (double)0.0F) {
         this.speed.set((Double)this.speed.get() + Math.signum(wheelDelta) * (double)0.5F);
      }

   }
}
