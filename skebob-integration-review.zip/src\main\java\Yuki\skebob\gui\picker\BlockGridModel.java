package Yuki.skebob.gui.picker;

import Yuki.skebob.settings.BlockListSetting;
import Yuki.skebob.settings.ColorSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntSupplier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

public final class BlockGridModel implements PickerGrid {
   private static List<Block> allBlocks;
   private final BlockListSetting setting;
   private final IntSupplier defaultColor;
   private final String title;
   private List<PickerGrid.Cell> cells;

   public BlockGridModel(BlockListSetting setting, IntSupplier defaultColor, String title) {
      this.setting = setting;
      this.defaultColor = defaultColor;
      this.title = title;
   }

   private static List<Block> allBlocks() {
      if (allBlocks == null) {
         List<Block> list = new ArrayList();

         for(Block block : Registries.BLOCK) {
            if (block != Blocks.AIR && block != Blocks.CAVE_AIR && block != Blocks.VOID_AIR) {
               list.add(block);
            }
         }

         allBlocks = list;
      }

      return allBlocks;
   }

   public String title() {
      return this.title;
   }

   public long activeCount() {
      return this.setting.enabledCount();
   }

   public List<PickerGrid.Cell> cells() {
      if (this.cells == null) {
         List<PickerGrid.Cell> out = new ArrayList(allBlocks().size());

         for(Block block : allBlocks()) {
            out.add(new BlockCell(block));
         }

         this.cells = out;
      }

      return this.cells;
   }

   private final class BlockCell implements PickerGrid.Cell {
      private final Block block;
      private final String search;
      private ItemStack icon;

      BlockCell(Block block) {
         this.block = block;
         Identifier id = Registries.BLOCK.getId(block);
         String path = id != null ? id.getPath() : "";
         String ns = id != null ? id.getNamespace() : "";
         this.search = (path + " " + ns + " " + BlockListSetting.displayName(block)).toLowerCase(Locale.ROOT);
      }

      public ItemStack icon() {
         if (this.icon == null) {
            Item item = this.block.asItem();
            this.icon = new ItemStack(item == Items.AIR ? Items.BARRIER : item);
         }

         return this.icon;
      }

      public Identifier iconTexture() {
         Identifier itemId = Registries.ITEM.getId(this.icon().getItem());
         return Identifier.of(itemId.getNamespace(), "textures/item/" + itemId.getPath() + ".png");
      }

      public Identifier fallbackTexture() {
         Identifier blockId = Registries.BLOCK.getId(this.block);
         return Identifier.of(blockId.getNamespace(), "textures/block/" + blockId.getPath() + ".png");
      }

      public List<Identifier> fallbackTextures() {
         Identifier id = Registries.BLOCK.getId(this.block);
         String path = id.getPath();
         List<Identifier> textures = new ArrayList();
         textures.add(Identifier.of(id.getNamespace(), "textures/block/" + path + ".png"));
         if (path.equals("grass_block")) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/grass_block_top.png"));
         } else if (path.equals("dirt_path")) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/dirt_path_top.png"));
         } else if (path.startsWith("potted_")) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/flower_pot.png"));
         } else if (path.endsWith("_wall_torch")) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/torch.png"));
         } else if (!path.endsWith("_wall_sign") && !path.endsWith("_wall_hanging_sign")) {
            if (path.equals("water")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/water_still.png"));
            } else if (path.equals("lava")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/lava_still.png"));
            } else if (path.equals("fire")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/fire_0.png"));
            } else if (path.equals("soul_fire")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/soul_fire_0.png"));
            } else if (path.equals("redstone_wire")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/redstone_dust_dot.png"));
            } else if (path.equals("tripwire")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/tripwire.png"));
            } else if (path.equals("bubble_column")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/bubble_column.png"));
            } else if (path.equals("nether_portal")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/nether_portal.png"));
            } else if (path.equals("end_portal")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/end_portal.png"));
            } else if (path.equals("end_gateway")) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/end_gateway.png"));
            } else if (!path.equals("piston_head") && !path.equals("moving_piston")) {
               if (path.endsWith("_crop")) {
                  textures.add(Identifier.of(id.getNamespace(), "textures/block/" + path + "_stage_3.png"));
               } else if (path.endsWith("_stem")) {
                  textures.add(Identifier.of(id.getNamespace(), "textures/block/" + path + "_straight.png"));
               } else if (path.endsWith("_plant")) {
                  textures.add(Identifier.of(id.getNamespace(), "textures/block/" + path.replace("_plant", "") + ".png"));
               } else if (path.endsWith("_wall")) {
                  textures.add(Identifier.of(id.getNamespace(), "textures/block/stone.png"));
               }
            } else {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/piston_top.png"));
            }
         } else {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/oak_planks.png"));
         }

         String[] suffixes = new String[]{"_top", "_side", "_front", "_bottom", "_back", "_0", "_1", "_stage_0", "_stage_1", "_stage_2", "_stage_3", "_stage_4", "_stage_5", "_stage_6", "_stage_7"};

         for(String suffix : suffixes) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/" + path + suffix + ".png"));
         }

         String base = path;

         for(String prefix : new String[]{"potted_", "wall_", "cut_", "waxed_", "exposed_", "weathered_", "oxidized_"}) {
            if (base.startsWith(prefix)) {
               base = base.substring(prefix.length());
            }
         }

         if (!base.equals(path)) {
            textures.add(Identifier.of(id.getNamespace(), "textures/block/" + base + ".png"));

            for(String suffix : suffixes) {
               textures.add(Identifier.of(id.getNamespace(), "textures/block/" + base + suffix + ".png"));
            }
         }

         return textures;
      }

      public String label() {
         return BlockListSetting.displayName(this.block);
      }

      public boolean matches(String lowerQuery) {
         return this.search.contains(lowerQuery);
      }

      public boolean tracked() {
         return BlockGridModel.this.setting.find(this.block) != null;
      }

      public boolean enabled() {
         BlockListSetting.Target t = BlockGridModel.this.setting.find(this.block);
         return t != null && (Boolean)t.enabled.get();
      }

      public boolean selected() {
         return BlockGridModel.this.setting.find(this.block) != null;
      }

      public int color() {
         BlockListSetting.Target t = BlockGridModel.this.setting.find(this.block);
         return t != null ? (Integer)t.color.get() : BlockGridModel.this.defaultColor.getAsInt();
      }

      public void toggle() {
         BlockListSetting.Target t = BlockGridModel.this.setting.find(this.block);
         if (t == null) {
            BlockGridModel.this.setting.add(this.block, true, BlockGridModel.this.defaultColor.getAsInt());
         } else {
            t.enabled.toggle();
         }

      }

      public ColorSetting colorTarget() {
         BlockListSetting.Target t = BlockGridModel.this.setting.find(this.block);
         if (t == null) {
            t = BlockGridModel.this.setting.add(this.block, true, BlockGridModel.this.defaultColor.getAsInt());
         }

         return t != null ? t.color : null;
      }
   }
}
