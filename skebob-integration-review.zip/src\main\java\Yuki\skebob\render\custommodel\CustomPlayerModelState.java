package Yuki.skebob.render.custommodel;

/** Render-state bridge populated by PlayerEntityRendererSkinChangerMixin. */
public interface CustomPlayerModelState {
    boolean skebob$hasCustomModel();
    String skebob$getCustomModel();
    void skebob$setCustomModel(String model);
}
