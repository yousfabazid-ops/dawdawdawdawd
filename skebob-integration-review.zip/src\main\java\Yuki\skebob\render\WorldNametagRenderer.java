package Yuki.skebob.render;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.Modules;
import Yuki.skebob.module.impl.NameProtectModule;
import Yuki.skebob.module.impl.NameTagsModule;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.util.Colors;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.joml.Matrix3x2fStack;

public final class WorldNametagRenderer {
   private static final int MAX_TAGS = 80;

   private WorldNametagRenderer() {
   }

   public static void render(NVGRenderer vg) {
      if (WorldProjection.isValid()) {
         ModuleManager modules = SkebobClient.modules();
         if (modules != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            ClientWorld level = mc.world;
            ClientPlayerEntity self = mc.player;
            if (level != null && self != null) {
               NameTagsModule names = modules.nameTags;
               boolean doNames = names != null && names.isEnabled();
               if (doNames) {
                  float pt = WorldProjection.partialTick();
                  Theme theme = SkebobClient.themes().current();
                  Modules.HudModule hud = modules.hud;
                  int accent = theme.accent();
                  List<Tag> tags = new ArrayList();
                  if (doNames) {
                     double range = (Double)names.range.get();
                     double rangeSq = range * range;
                     float nameScale = names.scale.getFloat();
                     float nameOpacity = (float)((Double)names.opacity.get() / (double)100.0F);
                     if ((Boolean)names.players.get()) {
                        NameProtectModule protect = modules.nameProtect;
                        boolean protecting = protect != null && protect.isEnabled();
                        boolean showSelf = (Boolean)names.self.get() && !mc.options.getPerspective().isFirstPerson();

                        for(AbstractClientPlayerEntity player : level.getPlayers()) {
                           boolean isSelf = player == self;
                           if ((!isSelf || showSelf) && !player.isSpectator() && player.isAlive()) {
                              double distSq = self.squaredDistanceTo(player);
                              if (isSelf || !(distSq > rangeSq)) {
                                 String shown = player.getGameProfile().name();
                                 if (protecting) {
                                    String replaced = protect.replacementForDisplay(shown);
                                    if (replaced != null) {
                                       shown = replaced;
                                    }
                                 }

                                 String suffix = !isSelf && (Boolean)names.distance.get() ? (int)Math.sqrt(distSq) + "m" : null;
                                 if (!shown.isEmpty() || suffix != null) {
                                    tags.add(entityTag(player, pt, Math.sqrt(distSq), shown, suffix, accent, -1.0F, nameScale, nameOpacity));
                                 }
                              }
                           }
                        }
                     }

                     if ((Boolean)names.items.get()) {
                        for(Entity entity : level.getEntities()) {
                           if (entity instanceof ItemEntity) {
                              ItemEntity item = (ItemEntity)entity;
                              if (item.isAlive()) {
                                 double distSq = self.squaredDistanceTo(item);
                                 if (!(distSq > rangeSq)) {
                                    ItemStack stack = item.getStack();
                                    if (!stack.isEmpty()) {
                                       String suffix = itemSuffix(stack.getCount(), (Boolean)names.itemAmount.get(), (Boolean)names.distance.get() ? (int)Math.sqrt(distSq) + "m" : null);
                                       tags.add(entityTag(item, pt, Math.sqrt(distSq), stack.getName().getString(), suffix, accent, -1.0F, nameScale, nameOpacity));
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }

                  if (!tags.isEmpty()) {
                     tags.sort(Comparator.comparingDouble(Tag::dist));
                     int count = Math.min(tags.size(), 80);

                     for(int i = count - 1; i >= 0; --i) {
                        Tag tag = (Tag)tags.get(i);
                        float[] screen = WorldProjection.project(tag.wx, tag.wy, tag.wz);
                        if (screen != null) {
                           drawTag(vg, theme, screen[0], screen[1], tag);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   private static Tag entityTag(Entity e, float pt, double dist, String name, String suffix, int accent, float healthFrac, float scale, float opacity) {
      double x = MathHelper.lerp((double)pt, e.lastRenderX, e.getX());
      double y = MathHelper.lerp((double)pt, e.lastRenderY, e.getY()) + (double)e.getHeight() + (double)0.5F;
      double z = MathHelper.lerp((double)pt, e.lastRenderZ, e.getZ());
      return new Tag(dist, x, y, z, name, suffix, accent, healthFrac, scale, opacity);
   }

   private static String itemSuffix(int amount, boolean showAmount, String distance) {
      StringBuilder sb = new StringBuilder();
      if (showAmount && amount > 1) {
         sb.append('x').append(amount);
      }

      if (distance != null) {
         if (sb.length() > 0) {
            sb.append("  ");
         }

         sb.append(distance);
      }

      return sb.length() == 0 ? null : sb.toString();
   }

   private static float pillHeight(float s, boolean hasHealth) {
      float textRowH = 12.5F * s + 3.5F * s * 2.0F;
      return textRowH + (hasHealth ? 3.0F * s + 3.5F * s : 0.0F);
   }

   public static void renderEquipment(DrawContext gg) {
      if (WorldProjection.isValid()) {
         ModuleManager modules = SkebobClient.modules();
         if (modules != null) {
            NameTagsModule names = modules.nameTags;
            if (names != null && names.isEnabled() && (Boolean)names.players.get()) {
               boolean showArmor = (Boolean)names.armor.get();
               boolean showHand = (Boolean)names.heldItem.get();
               if (showArmor || showHand) {
                  MinecraftClient mc = MinecraftClient.getInstance();
                  if (mc.currentScreen == null && !mc.options.hudHidden) {
                     ClientWorld level = mc.world;
                     ClientPlayerEntity self = mc.player;
                     if (level != null && self != null) {
                        float pt = WorldProjection.partialTick();
                        double range = (Double)names.range.get();
                        double rangeSq = range * range;
                        float s = names.scale.getFloat();
                        float pillH = pillHeight(s, false);
                        float uiScale = OverlayRenderer.uiScale();
                        double guiScale = (double)mc.getWindow().getScaleFactor();
                        boolean showSelf = (Boolean)names.self.get() && !mc.options.getPerspective().isFirstPerson();
                        List<ItemStack> row = new ArrayList();

                        for(AbstractClientPlayerEntity player : level.getPlayers()) {
                           boolean isSelf = player == self;
                           if ((!isSelf || showSelf) && !player.isSpectator() && player.isAlive() && (isSelf || !(self.squaredDistanceTo(player) > rangeSq))) {
                              row.clear();
                              if (showArmor) {
                                 addItem(row, player.getEquippedStack(EquipmentSlot.HEAD));
                                 addItem(row, player.getEquippedStack(EquipmentSlot.CHEST));
                                 addItem(row, player.getEquippedStack(EquipmentSlot.LEGS));
                                 addItem(row, player.getEquippedStack(EquipmentSlot.FEET));
                              }

                              if (showHand) {
                                 addItem(row, player.getMainHandStack());
                                 addItem(row, player.getEquippedStack(EquipmentSlot.OFFHAND));
                              }

                              if (!row.isEmpty()) {
                                 double wx = MathHelper.lerp((double)pt, player.lastRenderX, player.getX());
                                 double wy = MathHelper.lerp((double)pt, player.lastRenderY, player.getY()) + (double)player.getHeight() + (double)0.5F;
                                 double wz = MathHelper.lerp((double)pt, player.lastRenderZ, player.getZ());
                                 float[] px = WorldProjection.projectRaw(wx, wy, wz);
                                 if (px != null) {
                                    float guiX = (float)((double)px[0] / guiScale);
                                    float rowBottomY = (float)((double)(px[1] - pillH * uiScale) / guiScale) - 3.0F;
                                    float icon = 11.0F * s;
                                    float step = icon + 1.5F;
                                    float totalW = (float)row.size() * icon + (float)(row.size() - 1) * 1.5F;
                                    float startX = guiX - totalW / 2.0F;
                                    float rowTopY = rowBottomY - icon;
                                    Matrix3x2fStack pose = gg.getMatrices();

                                    for(int i = 0; i < row.size(); ++i) {
                                       ItemStack stack = (ItemStack)row.get(i);
                                       pose.pushMatrix();
                                       pose.translate(startX + (float)i * step, rowTopY);
                                       pose.scale(icon / 16.0F, icon / 16.0F);
                                       gg.drawItem(player, stack, 0, 0, 0);
                                       gg.drawStackOverlay(mc.textRenderer, stack, 0, 0);
                                       pose.popMatrix();
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }

   private static void addItem(List<ItemStack> list, ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         list.add(stack);
      }

   }

   private static void drawTag(NVGRenderer vg, Theme theme, float uiX, float uiY, Tag tag) {
      float s = tag.scale;
      int accentBright = Colors.lighten(tag.accent, 0.35F);
      float fontMain = 12.5F * s;
      float fontSub = 10.0F * s;
      float padX = 6.0F * s;
      float padY = 3.5F * s;
      float gap = 5.0F * s;
      float nameW = vg.textWidth(tag.name, fontMain);
      float suffixW = tag.suffix != null ? gap + vg.textWidth(tag.suffix, fontSub) : 0.0F;
      float w = nameW + suffixW + padX * 2.0F;
      float textRowH = fontMain + padY * 2.0F;
      float x = uiX - w / 2.0F;
      float y = uiY - textRowH;
      float radius = Math.min(6.0F * s, textRowH / 2.0F);
      boolean fade = tag.opacity < 0.999F;
      if (fade) {
         vg.save();
         vg.alpha(tag.opacity);
      }

      vg.glow(x, y, w, textRowH, radius, 4.0F, Colors.withAlpha(tag.accent, 0.12F));
      vg.rectGradient(x, y, w, textRowH, radius, theme.background(), theme.backgroundTo(), true);
      vg.rectOutline(x, y, w, textRowH, radius, 1.0F, -1);
      float cy = y + padY + fontMain / 2.0F;
      float tx = x + padX;
      tx += vg.textGradient(tag.name, tx, cy, fontMain, accentBright, tag.accent);
      if (tag.suffix != null) {
         tx += gap;
         vg.text(tag.suffix, tx, cy, fontSub, theme.textMuted());
      }

      if (fade) {
         vg.restore();
      }

   }

   private static record Tag(double dist, double wx, double wy, double wz, String name, String suffix, int accent, float healthFrac, float scale, float opacity) {
   }
}
