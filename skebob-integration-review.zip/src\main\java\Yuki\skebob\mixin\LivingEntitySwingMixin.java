package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({LivingEntity.class})
public class LivingEntitySwingMixin {
   @ModifyReturnValue(
      method = {"getHandSwingDuration"},
      at = {@At("RETURN")}
   )
   private int SkebobClient$swingSpeed(int original) {
      LivingEntity self = (LivingEntity)(Object)this;
      if (MinecraftClient.getInstance().player != self) {
         return original;
      } else {
         ModuleManager modules = SkebobClient.modules();
         if (modules != null && modules.swingSpeed != null && modules.swingSpeed.isEnabled()) {
            float multiplier = modules.swingSpeed.multiplier();
            return multiplier <= 0.01F ? original : Math.max(1, Math.round((float)original / multiplier));
         } else {
            return original;
         }
      }
   }
}
