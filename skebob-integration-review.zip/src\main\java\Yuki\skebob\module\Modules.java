package Yuki.skebob.module;

import Yuki.skebob.render.SusChunkRenderer;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.Setting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.suschunk.SusChunkScanner;

public final class Modules {
   private Modules() {
   }

   public static class Placeholder extends Module {
      public Placeholder(String name, String description, Category category, Setting<?>... settings) {
         super(name, description, category);

         for (Setting<?> setting : settings) {
            this.addSetting(setting);
         }
      }
   }

   public static class ClickGuiModule extends Module {
      public final BooleanSetting blur =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Blur",
               "Gaussian-blur the world behind the GUI",
               true
            )
         );

      public final SliderSetting blurStrength =
         (SliderSetting)this.addSetting(
            new SliderSetting(
               "Blur Strength",
               "How strong the background blur is",
               4.0,
               1.0,
               10.0,
               1.0
            )
         );

      public ClickGuiModule() {
         super(
            "ClickGUI",
            "The SkebobClient menu. In menus, Shift opens it too.",
            Category.CLIENT
         );

         this.getKeybind().set(344);
      }
   }

   public static class SusChunkFinderModule extends Module {

      public final SliderSetting simulationDistance =
         (SliderSetting)this.addSetting(
            new SliderSetting(
               "Simulation Distance",
               "Distance used to spread growth evidence between chunks",
               4.0,
               2.0,
               16.0,
               1.0
            ).withLabel(
               value -> Integer.toString((int)value)
            )
         );

      public final SliderSetting sensitivity =
         (SliderSetting)this.addSetting(
            new SliderSetting(
               "Sensitivity",
               "Minimum grown things needed to mark chunk as sus",
               3.0,
               1.0,
               20.0,
               1.0
            ).withLabel(
               value -> Integer.toString((int)value)
            )
         );

      public final BooleanSetting autoSensitivity =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Auto Sensitivity",
               "Automatically adjusts the sensitivity to keep only a few suspicious chunks visible",
               true
            )
         );

      public final SliderSetting alpha =
         (SliderSetting)this.addSetting(
            new SliderSetting(
               "Alpha",
               "Opacity of the suspicious chunk overlay",
               80.0,
               10.0,
               255.0,
               1.0
            ).withLabel(
               value -> Integer.toString((int)value)
            )
         );

      public final BooleanSetting kelp =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Kelp",
               "Detect suspicious grown kelp",
               true
            )
         );

      public final BooleanSetting caveVines =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Cave Vines",
               "Detect suspicious cave vine growth",
               true
            )
         );

      public final BooleanSetting vines =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Vines",
               "Detect suspicious vine growth",
               true
            )
         );

      public final BooleanSetting amethyst =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Amethyst",
               "Detect suspicious amethyst growth",
               true
            )
         );

      public final BooleanSetting bamboo =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Bamboo",
               "Detect suspicious bamboo growth",
               true
            )
         );

      public final BooleanSetting beeNest =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Bee Nest",
               "Bee nests with honey mean the chunk was loaded",
               true
            )
         );

      public final BooleanSetting rotatedDeepslate =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Rotated Deepslate",
               "Detect rotated deepslate buried between Y 0-60",
               true
            )
         );

      public final SusChunkScanner scanner;

      public SusChunkFinderModule() {
         super(
            "Sus Chunk Finder",
            "Finds probable base locations using plant/amethyst growth and rotated deepslate",
            Category.RENDER
         );

         this.scanner =
            new SusChunkScanner(
               this.simulationDistance,
               this.sensitivity,
               this.kelp,
               this.caveVines,
               this.vines,
               this.amethyst,
               this.bamboo,
               this.beeNest,
               this.rotatedDeepslate
            );
      }

      @Override
      public void onTick() {
         this.scanner.tick();
      }

      @Override
      protected void onDisable() {
         this.scanner.clear();
         SusChunkRenderer.reset();
      }
   }

   public static class ClusterEspModule extends Module {
      public final BooleanSetting tracers =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Tracers",
               "Draw lines from the camera to detected cluster cells",
               false
            )
         );

      public final SusChunkScanner scanner =
         null;

      public ClusterEspModule() {
         super(
            "ClusterESP",
            "Highlights light-0 amethyst cluster cells",
            Category.RENDER
         );
      }

      public void onTick() {
      }

      protected void onDisable() {
      }
   }

   public static class HudModule extends Module {
      public final BooleanSetting watermark =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Watermark",
               "Show the SkebobClient badge",
               true
            )
         );

      public final BooleanSetting arrayList =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "ArrayList",
               "Enabled modules list",
               true
            )
         );

      public final BooleanSetting fps =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "FPS",
               "Framerate readout",
               true
            )
         );

      public final BooleanSetting ping =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Ping",
               "Latency readout",
               false
            )
         );

      public final BooleanSetting coordinates =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Coordinates",
               "Block position readout",
               true
            )
         );

      public final BooleanSetting direction =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Direction",
               "Facing readout",
               true
            )
         );

      public final BooleanSetting cps =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "CPS",
               "Clicks per second",
               false
            )
         );

      public final BooleanSetting armor =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Armor",
               "Equipped armor + durability",
               false
            )
         );

      public final BooleanSetting potions =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Potions",
               "Active effects with timers",
               false
            )
         );

      public final BooleanSetting keystrokes =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Keystrokes",
               "WASD + mouse + space display",
               false
            )
         );

      public final BooleanSetting radar =
         (BooleanSetting)this.addSetting(
            new BooleanSetting(
               "Radar",
               "Circular player radar",
               true
            )
         );

      public HudModule() {
         super(
            "HUD",
            "All HUD elements - move & resize via chat (T)",
            Category.CLIENT
         );

         this.setEnabled(true);
      }
   }

   public static class SpotifyModule extends Module {
      public SpotifyModule() {
         super(
            "SpotifyHUD",
            "Now playing - skip and seek from the HUD",
            Category.CLIENT
         );

         this.setEnabled(true);
      }
   }
}