package Yuki.skebob.mixin;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.render.AccessoryRenderer;
import Yuki.skebob.render.BlockEntityEspRenderer;
import Yuki.skebob.render.BlockEspRenderer;
import Yuki.skebob.render.ClusterEspRenderer;
import Yuki.skebob.render.EntityEspRenderer;
import Yuki.skebob.render.HitParticleRenderer;
import Yuki.skebob.render.LightDebugRenderer;
import Yuki.skebob.render.PrimeChunkRenderer;
import Yuki.skebob.render.StorageEspRenderer;
import Yuki.skebob.render.SusChunkRenderer;
import Yuki.skebob.render.SusChunkFinderV2Renderer;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public class LevelRendererMixin {
   @Inject(
      method = {"renderTargetBlockOutline(Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/util/math/MatrixStack;ZLnet/minecraft/client/render/state/WorldRenderState;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void SkebobClient$renderWorldOverlays(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, boolean translucentPass, WorldRenderState levelRenderState, CallbackInfo ci) {
      ModuleManager modules = SkebobClient.modules();
      if (modules != null) {
         if (translucentPass && modules.susChunkFinder.isEnabled()) {
            SusChunkRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.susChunkFinder);
         }

         if (translucentPass && modules.susChunkFinderV2.isEnabled()) {
            SusChunkFinderV2Renderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.susChunkFinderV2);
         }

         if (translucentPass && modules.primeChunkFinder.isEnabled()) {
            PrimeChunkRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.primeChunkFinder);
         }

         if (translucentPass && modules.clusterEsp.isEnabled() && modules.clusterEsp.scanner != null) {
            ClusterEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.clusterEsp);
         }

         if (translucentPass && modules.lightDebug.isEnabled()) {
            LightDebugRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.lightDebug);
         }

         if (translucentPass && modules.storageEsp != null && modules.storageEsp.isEnabled()) {
            StorageEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.storageEsp);
         }

         if (translucentPass && modules.blockEsp != null && modules.blockEsp.isEnabled()) {
            BlockEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEsp);
         }

         if (translucentPass && modules.blockEntityEsp != null && modules.blockEntityEsp.isEnabled()) {
            BlockEntityEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEntityEsp);
         }

         if (translucentPass && modules.playerEsp != null && modules.playerEsp.isEnabled()) {
            EntityEspRenderer.renderPlayers(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.playerEsp);
         }

         if (translucentPass && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            HitParticleRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.hitParticles);
         }

         if (translucentPass && modules.customAccessories != null && modules.customAccessories.isEnabled()) {
            AccessoryRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.customAccessories);
         }
      }

   }
}
