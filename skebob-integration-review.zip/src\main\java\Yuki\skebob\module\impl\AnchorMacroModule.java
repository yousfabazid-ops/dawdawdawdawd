package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.util.BlockHelper;
import Yuki.skebob.util.InventoryHelper;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public class AnchorMacroModule extends Module {
   public final SliderSetting switchDelay = (SliderSetting)this.addSetting(new SliderSetting("Switch Delay", "", (double)0.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final SliderSetting glowstoneDelay = (SliderSetting)this.addSetting(new SliderSetting("Glowstone Delay", "", (double)0.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final SliderSetting explodeDelay = (SliderSetting)this.addSetting(new SliderSetting("Explode Delay", "", (double)0.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   public final SliderSetting totemSlot = (SliderSetting)this.addSetting(new SliderSetting("Totem Slot", "", (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   public final BooleanSetting autoSwitchBack = (BooleanSetting)this.addSetting(new BooleanSetting("Auto Switch Back", "", true));
   public final SliderSetting switchBackDelay = (SliderSetting)this.addSetting(new SliderSetting("Switch Back Delay", "", (double)2.0F, (double)0.0F, (double)20.0F, (double)1.0F));
   private int step;
   private int tickCounter;
   private BlockPos targetPos;
   private int previousSlot = -1;

   public AnchorMacroModule() {
      super("Anchor Macro", "Automatically blows up respawn anchors", Category.COMBAT);
   }

   protected void onEnable() {
      this.resetState();
   }

   protected void onDisable() {
      this.resetState();
   }

   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.interactionManager != null && client.world != null) {
         if (this.step > 0) {
            this.processStep(client);
         } else {
            long handle = client.getWindow().getHandle();
            boolean rmb = GLFW.glfwGetMouseButton(handle, 1) == 1;
            if (rmb && client.crosshairTarget != null && client.crosshairTarget.getType() == Type.BLOCK) {
               BlockHitResult hit = (BlockHitResult)client.crosshairTarget;
               BlockPos pos = hit.getBlockPos();
               if (BlockHelper.isBlockAt(pos, Blocks.RESPAWN_ANCHOR)) {
                  this.targetPos = pos;
                  this.previousSlot = client.player.getInventory().getSelectedSlot();
                  if (BlockHelper.isAnchorUncharged(pos)) {
                     this.step = 1;
                     this.tickCounter = 0;
                  } else if (BlockHelper.isAnchorCharged(pos)) {
                     this.step = 3;
                     this.tickCounter = 0;
                  }
               }
            }
         }
      }

   }

   private void processStep(MinecraftClient client) {
      ++this.tickCounter;
      HitResult var4 = client.crosshairTarget;
      BlockHitResult var10000;
      if (var4 instanceof BlockHitResult bhr) {
         var10000 = bhr;
      } else {
         var10000 = null;
      }

      switch (this.step) {
         case 1:
            if (this.tickCounter >= this.switchDelay.getInt()) {
               InventoryHelper.swapToItem(Items.GLOWSTONE);
               this.step = 2;
               this.tickCounter = 0;
            }
            break;
         case 2:
            if (this.tickCounter >= this.glowstoneDelay.getInt()) {
               if (var10000 != null && this.targetPos.equals(var10000.getBlockPos())) {
                  BlockHelper.interactBlock(var10000, true);
               }

               this.step = 3;
               this.tickCounter = 0;
            }
            break;
         case 3:
            if (this.tickCounter >= this.explodeDelay.getInt()) {
               InventoryHelper.swap(this.totemSlot.getInt() - 1);
               this.step = 4;
               this.tickCounter = 0;
            }
            break;
         case 4:
            if (this.tickCounter >= 1) {
               if (var10000 != null && this.targetPos.equals(var10000.getBlockPos())) {
                  BlockHelper.interactBlock(var10000, true);
               }

               if ((Boolean)this.autoSwitchBack.get() && this.previousSlot >= 0) {
                  this.step = 5;
                  this.tickCounter = 0;
               } else {
                  this.resetState();
               }
            }
            break;
         case 5:
            if (this.tickCounter >= this.switchBackDelay.getInt()) {
               InventoryHelper.swap(this.previousSlot);
               this.resetState();
            }
            break;
         default:
            this.resetState();
      }

   }

   private void resetState() {
      this.step = 0;
      this.tickCounter = 0;
      this.targetPos = null;
      this.previousSlot = -1;
   }
}
