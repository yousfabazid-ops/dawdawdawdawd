package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.SliderSetting;

public class FullbrightModule extends Module {
   public final SliderSetting gamma = (SliderSetting)this.addSetting(new SliderSetting("Gamma", "Brightness boost", (double)12.0F, (double)1.0F, (double)15.0F, (double)1.0F));

   public FullbrightModule() {
      super("FullBright", "Maximum brightness everywhere", Category.RENDER);
   }
}
