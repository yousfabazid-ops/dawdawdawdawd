package Yuki.skebob.gui.picker;

import Yuki.skebob.settings.ColorSetting;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

public interface PickerGrid {
   String title();

   long activeCount();

   List<Cell> cells();

   public interface Cell {
      ItemStack icon();

      default Identifier iconTexture() {
         Identifier itemId = Registries.ITEM.getId(this.icon().getItem());
         return Identifier.of(itemId.getNamespace(), "textures/item/" + itemId.getPath() + ".png");
      }

      default Identifier fallbackTexture() {
         return null;
      }

      default List<Identifier> fallbackTextures() {
         Identifier texture = this.fallbackTexture();
         return texture == null ? List.of() : List.of(texture);
      }

      String label();

      boolean matches(String var1);

      boolean tracked();

      boolean enabled();

      boolean selected();

      int color();

      void toggle();

      ColorSetting colorTarget();
   }
}
