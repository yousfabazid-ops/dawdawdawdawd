package Yuki.skebob.module.impl;

import Yuki.skebob.module.Category;
import Yuki.skebob.module.Module;
import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;
import Yuki.skebob.suschunk.SusChunkFinderV2Scanner;

/** A separate V2 candidate finder; it does not reuse the original SusChunkScanner. */
public final class SusChunkFinderV2Module extends Module {
    public final SliderSetting scanRadius;
    public final SliderSetting simChunks;
    public final SliderSetting sensitivity;
    public final SliderSetting alpha;
    public final BooleanSetting chestFilter;
    public final SusChunkFinderV2Scanner scanner;

    public SusChunkFinderV2Module() {
        super("Sus Chunk Finder V2",
            "Incrementally scans loaded chunks for amethyst-rich underground candidates",
            Category.RENDER);
        this.scanRadius = addSetting(new SliderSetting(
            "Scan Radius", "Chunk radius multiplier (1-5 means 5-25 chunks)", 1.0, 1.0, 5.0, 1.0));
        this.simChunks = addSetting(new SliderSetting(
            "Sim Chunks", "10 shows candidate chunks; lower values show a possible region footprint", 10.0, 1.0, 10.0, 1.0));
        this.sensitivity = addSetting(new SliderSetting(
            "Sensitivity", "Minimum amethyst blocks/clusters counted in a chunk", 3.0, 1.0, 20.0, 1.0));
        this.alpha = addSetting(new SliderSetting(
            "Alpha", "Overlay opacity", 40.0, 10.0, 255.0, 1.0));
        this.chestFilter = addSetting(new BooleanSetting(
            "Chest Filter", "When you are below Y=-2, only show candidates with 10+ chests below Y=0", true));
        this.scanner = new SusChunkFinderV2Scanner();
    }

    @Override
    public void onTick() {
        if (!isEnabled()) {
            return;
        }
        scanner.tick(scanRadius.getInt(), simChunks.getInt(), sensitivity.getInt(), chestFilter.get());
    }

    @Override
    protected void onDisable() {
        scanner.clear();
    }
}