package Yuki.skebob.theme;

import Yuki.skebob.util.Colors;

public class Theme {
    private final String name;
    private int accent;
    private final boolean custom;

    public Theme(String name, int accent, boolean custom) {
        this.name = name;
        this.accent = accent;
        this.custom = custom;
    }

    public String getName() {
        return this.name;
    }

    public int accent() {
        return this.accent;
    }

    public void setAccent(int accent) {
        this.accent = accent;
    }

    public boolean isCustom() {
        return this.custom;
    }

    public int accentBright() {
        return Colors.lighten(this.accent, 0.20F);
    }

    public int accentHover() {
        return Colors.withAlpha(this.accent, 0.14F);
    }

    public int background() {
        return -234025715;
    }

    public int backgroundTo() {
        return -233433578;
    }

    public int headerTop() {
        return -14540254;
    }

    public int headerBottom() {
        return -15198184;
    }

    public int moduleActiveFill() {
        return -13421773;
    }

    public int textPrimary() {
        return -855310;
    }

    public int textMuted() {
        return -5592406;
    }

    public int textDisabled() {
        return -10066330;
    }

    public int statusEnabled() {
        return -1;
    }

    public int statusDisabled() {
        return -11184811;
    }

    public int border() {
        return -11908534;
    }

    public int borderBright() {
        return -1;
    }
}