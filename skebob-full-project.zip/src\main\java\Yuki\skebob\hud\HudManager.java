package Yuki.skebob.hud;

import Yuki.skebob.hud.components.ArmorHud;
import Yuki.skebob.hud.components.ArrayListHud;
import Yuki.skebob.hud.components.InfoHud;
import Yuki.skebob.hud.components.KeystrokesHud;
import Yuki.skebob.hud.components.PotionsHud;
import Yuki.skebob.hud.components.RadarHud;
import Yuki.skebob.hud.components.SpotifyHud;
import Yuki.skebob.hud.components.StaffListHud;
import Yuki.skebob.hud.components.WatermarkHud;
import Yuki.skebob.module.ModuleManager;
import Yuki.skebob.module.Modules;
import Yuki.skebob.notification.NotificationManager;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.spotify.SpotifyService;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.CpsTracker;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ClientPlayerEntity;

public class HudManager {
   private static final float MINIMUM_HUD_SCALE = 1.25F;
   private final List<HudComponent> components = new ArrayList();

   public HudManager(ModuleManager modules, ThemeManager themes, SpotifyService spotify, NotificationManager notifications) {
      Modules.HudModule hud = modules.hud;
      this.components.add(new WatermarkHud(themes, () -> hud.isEnabled() && (Boolean)hud.watermark.get()));
      this.components.add(new ArrayListHud(modules, hud, themes, () -> hud.isEnabled() && (Boolean)hud.arrayList.get()));
      this.components.add(new InfoHud("fps", themes, "FPS", () -> Integer.toString(MinecraftClient.getInstance().getCurrentFps()), 0.03F, 0.91F, () -> hud.isEnabled() && (Boolean)hud.fps.get()));
      this.components.add(new InfoHud("coords", themes, "XYZ", HudManager::coordsString, 0.16F, 0.91F, () -> hud.isEnabled() && (Boolean)hud.coordinates.get()));
      this.components.add(new InfoHud("cps", themes, "CPS", () -> {
         int var10000 = CpsTracker.get(0);
         return var10000 + " | " + CpsTracker.get(1);
      }, 0.3F, 0.91F, () -> hud.isEnabled() && (Boolean)hud.cps.get()));
      this.components.add(new ArmorHud(themes, () -> hud.isEnabled() && (Boolean)hud.armor.get()));
      this.components.add(new PotionsHud(themes, () -> hud.isEnabled() && (Boolean)hud.potions.get()));
      this.components.add(new KeystrokesHud(themes, () -> hud.isEnabled() && (Boolean)hud.keystrokes.get()));
      this.components.add(new RadarHud(hud, themes, () -> hud.isEnabled() && (Boolean)hud.radar.get()));
      this.components.add(new StaffListHud(modules.staffList, themes));
      this.components.add(new SpotifyHud(modules.spotify, spotify, themes));
   }

   private static String coordsString() {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         return "0, 0, 0";
      } else {
         BlockPos pos = player.getBlockPos();
         int var10000 = pos.getX();
         return var10000 + ", " + pos.getY() + ", " + pos.getZ();
      }
   }

   private static String pingString() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player != null && mc.getNetworkHandler() != null) {
         PlayerListEntry info = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         return info == null ? "0ms" : info.getLatency() + "ms";
      } else {
         return "0ms";
      }
   }

   private static String directionString() {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         return "N";
      } else {
         Direction dir = player.getHorizontalFacing();
         String var10000;
         switch (dir) {
            case NORTH -> var10000 = "N  -Z";
            case SOUTH -> var10000 = "S  +Z";
            case WEST -> var10000 = "W  -X";
            case EAST -> var10000 = "E  +X";
            default -> var10000 = dir.getId().toUpperCase();
         }

         return var10000;
      }
   }

   public List<HudComponent> getComponents() {
      return this.components;
   }

   public List<Placement> layout(NVGRenderer vg, float uiWidth, float uiHeight, boolean includeHidden) {
      List<Placement> placements = new ArrayList();

      for(HudComponent component : this.components) {
         if (includeHidden || component.visible()) {
            float scale = component.getScale();
            float w = component.measureWidth(vg) * scale;
            float h = component.measureHeight(vg) * scale;
            float x = component.getFx() * (uiWidth - w);
            float y = component.getFy() * (uiHeight - h);
            placements.add(new Placement(component, x, y, w, h));
         }
      }

      return placements;
   }

   public void render(NVGRenderer vg, float uiWidth, float uiHeight) {
      for(Placement p : this.layout(vg, uiWidth, uiHeight, false)) {
         this.renderPlacement(vg, p);
      }

   }

   public void renderPlacement(NVGRenderer vg, Placement p) {
      float scale = p.component().getScale();
      vg.save();
      vg.translate((float)Math.round(p.x()), (float)Math.round(p.y()));
      vg.scale(scale);
      p.component().render(vg, 0.0F, 0.0F, p.w() / scale, p.h() / scale);
      vg.restore();
   }

   public JsonObject toJson() {
      JsonObject json = new JsonObject();

      for(HudComponent component : this.components) {
         JsonObject entry = new JsonObject();
         entry.addProperty("fx", component.getFx());
         entry.addProperty("fy", component.getFy());
         entry.addProperty("scale", component.getScale());
         json.add(component.getId(), entry);
      }

      return json;
   }

   public void fromJson(JsonObject json) {
      for(HudComponent component : this.components) {
         JsonObject entry = json.getAsJsonObject(component.getId());
         if (entry != null && entry.has("fx") && entry.has("fy")) {
            component.setPosition(entry.get("fx").getAsFloat(), entry.get("fy").getAsFloat());
            if (entry.has("scale")) {
               component.setScale(Math.max(1.25F, entry.get("scale").getAsFloat()));
            }
         }
      }

   }

   public static record Placement(HudComponent component, float x, float y, float w, float h) {
      public boolean contains(float px, float py) {
         return px >= this.x && px <= this.x + this.w && py >= this.y && py <= this.y + this.h;
      }
   }
}
