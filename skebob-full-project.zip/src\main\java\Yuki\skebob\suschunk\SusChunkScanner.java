package Yuki.skebob.suschunk;

import Yuki.skebob.settings.BooleanSetting;
import Yuki.skebob.settings.SliderSetting;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class SusChunkScanner {

    /*
     * V2 scan tuning.
     *
     * The important difference from the old scanner:
     * we do not scan every loaded chunk in one giant job.
     * Chunks are queued and processed in small background batches.
     */
    private static final int TICK_INTERVAL = 5;
    private static final int RESCAN_INTERVAL = 60;
    private static final int CHUNKS_PER_BATCH = 10;
    private static final int PRUNE_INTERVAL = 20;

    private final SliderSetting simulationDistance;
    private final SliderSetting sensitivity;

    private final BooleanSetting kelp;
    private final BooleanSetting caveVines;
    private final BooleanSetting vines;
    private final BooleanSetting amethyst;
    private final BooleanSetting bamboo;
    private final BooleanSetting beeNest;
    private final BooleanSetting rotatedDeepslate;

    private final Map<Long, Integer> chunkHeatmap =
        new ConcurrentHashMap<>();

    private final Set<Long> loadedChunkPositions =
        ConcurrentHashMap.newKeySet();

    private final Set<BlockPos> suspiciousDeepslateBlocks =
        ConcurrentHashMap.newKeySet();

    private final Set<BlockPos> amethystCells =
        ConcurrentHashMap.newKeySet();

    private final Map<Long, Set<BlockPos>> chunkDeepslateMap =
        new ConcurrentHashMap<>();

    private final Map<Long, Integer> chunkGrowthCounts =
        new ConcurrentHashMap<>();

    private final Map<Long, Boolean> chunkHasFullyGrown =
        new ConcurrentHashMap<>();

    private final Map<Long, Integer> trackedChunks =
        new ConcurrentHashMap<>();

    private final Map<Long, Integer> lastScannedTick =
        new ConcurrentHashMap<>();

    private final ConcurrentLinkedQueue<ChunkPos> scanQueue =
        new ConcurrentLinkedQueue<>();

    private final Set<Long> queuedChunks =
        ConcurrentHashMap.newKeySet();

    private ExecutorService executor;

    private final AtomicBoolean scanning =
        new AtomicBoolean(false);

    private int tickCounter;

    public SusChunkScanner(
        SliderSetting simulationDistance,
        SliderSetting sensitivity,
        BooleanSetting kelp,
        BooleanSetting caveVines,
        BooleanSetting vines,
        BooleanSetting amethyst,
        BooleanSetting bamboo,
        BooleanSetting beeNest,
        BooleanSetting rotatedDeepslate
    ) {
        this.simulationDistance = simulationDistance;
        this.sensitivity = sensitivity;
        this.kelp = kelp;
        this.caveVines = caveVines;
        this.vines = vines;
        this.amethyst = amethyst;
        this.bamboo = bamboo;
        this.beeNest = beeNest;
        this.rotatedDeepslate = rotatedDeepslate;
    }

    public Map<Long, Integer> chunkHeatmap() {
        return Collections.unmodifiableMap(this.chunkHeatmap);
    }

    public Set<BlockPos> suspiciousDeepslateBlocks() {
        return Collections.unmodifiableSet(
            this.suspiciousDeepslateBlocks
        );
    }

    public Set<BlockPos> amethystCells() {
        return Collections.unmodifiableSet(
            this.amethystCells
        );
    }

    public Set<Long> trackedChunks() {
        return Collections.unmodifiableSet(
            this.trackedChunks.keySet()
        );
    }

    public Set<Long> loadedChunkPositions() {
        return Collections.unmodifiableSet(
            this.loadedChunkPositions
        );
    }

    public int sensitivity() {
        return this.sensitivity.getInt();
    }

    public int alpha() {
        return 80;
    }

    public void clear() {
        this.chunkHeatmap.clear();
        this.loadedChunkPositions.clear();
        this.suspiciousDeepslateBlocks.clear();
        this.amethystCells.clear();
        this.chunkDeepslateMap.clear();
        this.chunkGrowthCounts.clear();
        this.chunkHasFullyGrown.clear();
        this.trackedChunks.clear();
        this.lastScannedTick.clear();
        this.scanQueue.clear();
        this.queuedChunks.clear();

        this.tickCounter = 0;
        this.scanning.set(false);

        if (this.executor != null) {
            this.executor.shutdownNow();
            this.executor = null;
        }
    }

    public void tick() {
        MinecraftClient mc =
            MinecraftClient.getInstance();

        if (mc.world == null || mc.player == null) {
            return;
        }

        this.tickCounter++;

        if (this.tickCounter % TICK_INTERVAL != 0) {
            return;
        }

        if (this.executor == null ||
            this.executor.isShutdown() ||
            this.executor.isTerminated()) {

            this.executor =
                Executors.newSingleThreadExecutor(task -> {
                    Thread thread =
                        new Thread(
                            task,
                            "skebob-sus-chunk-v2"
                        );

                    thread.setDaemon(true);
                    return thread;
                });
        }

        this.refreshLoadedChunks(mc);

        if (this.tickCounter % PRUNE_INTERVAL == 0) {
            this.pruneOldData(mc.player.getChunkPos());
        }

        this.enqueueNeededChunks();

        if (!this.scanning.compareAndSet(false, true)) {
            return;
        }

        ArrayList<ChunkPos> batch =
            new ArrayList<>(CHUNKS_PER_BATCH);

        ArrayList<WorldChunk> chunks =
            new ArrayList<>(CHUNKS_PER_BATCH);

        for (int i = 0; i < CHUNKS_PER_BATCH; i++) {
            ChunkPos pos = this.scanQueue.poll();

            if (pos == null) {
                break;
            }

            this.queuedChunks.remove(pos.toLong());

            WorldChunk chunk =
                mc.world.getChunkManager()
                    .getWorldChunk(
                        pos.x,
                        pos.z,
                        false
                    );

            if (chunk == null || chunk.isEmpty()) {
                continue;
            }

            batch.add(pos);
            chunks.add(chunk);
        }

        if (batch.isEmpty()) {
            this.scanning.set(false);
            return;
        }

        try {
            this.executor.submit(() -> {
                try {
                    for (int i = 0; i < batch.size(); i++) {
                        ChunkPos pos = batch.get(i);
                        WorldChunk chunk = chunks.get(i);

                        this.updateChunkData(
                            pos,
                            chunk,
                            mc
                        );
                    }
                } catch (Throwable ignored) {
                } finally {
                    this.scanning.set(false);
                }
            });
        } catch (Throwable ignored) {
            this.scanning.set(false);
        }
    }

    private void refreshLoadedChunks(MinecraftClient mc) {
        ChunkPos center =
            mc.player.getChunkPos();

        int radius =
            Math.min(
                mc.options.getClampedViewDistance(),
                16
            );

        Set<Long> currentLoaded =
            new HashSet<>();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                ChunkPos pos =
                    new ChunkPos(
                        center.x + dx,
                        center.z + dz
                    );

                WorldChunk chunk =
                    mc.world.getChunkManager()
                        .getWorldChunk(
                            pos.x,
                            pos.z,
                            false
                        );

                if (chunk != null && !chunk.isEmpty()) {
                    currentLoaded.add(pos.toLong());
                }
            }
        }

        this.loadedChunkPositions.clear();
        this.loadedChunkPositions.addAll(currentLoaded);

        /*
         * Forget old queue entries for chunks that are not loaded anymore.
         */
        this.scanQueue.removeIf(
            pos -> !currentLoaded.contains(pos.toLong())
        );

        this.queuedChunks.removeIf(
            key -> !currentLoaded.contains(key)
        );
    }

    private void enqueueNeededChunks() {
        int now = this.tickCounter;

        for (long key : this.loadedChunkPositions) {
            int last =
                this.lastScannedTick.getOrDefault(
                    key,
                    -RESCAN_INTERVAL
                );

            if (now - last < RESCAN_INTERVAL) {
                continue;
            }

            if (!this.queuedChunks.add(key)) {
                continue;
            }

            this.scanQueue.add(
                new ChunkPos(key)
            );
        }
    }

    private void updateChunkData(
        ChunkPos chunkPos,
        WorldChunk chunk,
        MinecraftClient mc
    ) {
        long chunkKey =
            chunkPos.toLong();

        this.lastScannedTick.put(
            chunkKey,
            this.tickCounter
        );

        int simDist =
            this.simulationDistance.getInt();

        int previousGrowth =
            this.chunkGrowthCounts.getOrDefault(
                chunkKey,
                0
            );

        boolean previousFullyGrown =
            Boolean.TRUE.equals(
                this.chunkHasFullyGrown.get(chunkKey)
            );

        Set<BlockPos> previousDeepslate =
            this.chunkDeepslateMap.remove(chunkKey);

        /*
         * Remove the previous contribution before writing
         * the new result. This keeps the heatmap stable.
         */
        if (previousGrowth > 0) {
            for (int dx = -simDist; dx <= simDist; dx++) {
                for (int dz = -simDist; dz <= simDist; dz++) {
                    long key =
                        ChunkPos.toLong(
                            chunkPos.x + dx,
                            chunkPos.z + dz
                        );

                    this.chunkHeatmap.compute(
                        key,
                        (ignored, value) ->
                            decrementValue(
                                previousGrowth,
                                value
                            )
                    );
                }
            }
        }

        if (previousFullyGrown) {
            for (int dx = -simDist; dx <= simDist; dx++) {
                for (int dz = -simDist; dz <= simDist; dz++) {
                    this.removeTrackedChunk(
                        new ChunkPos(
                            chunkPos.x + dx,
                            chunkPos.z + dz
                        )
                    );
                }
            }
        }

        if (previousDeepslate != null &&
            !previousDeepslate.isEmpty()) {

            this.suspiciousDeepslateBlocks
                .removeAll(previousDeepslate);
        }

        this.amethystCells.removeIf(
            pos ->
                new ChunkPos(pos).toLong() == chunkKey
        );

        ScanResult result =
            this.scanChunkBlocks(
                chunkPos,
                chunk,
                mc
            );

        this.chunkGrowthCounts.put(
            chunkKey,
            result.growthCount
        );

        this.chunkHasFullyGrown.put(
            chunkKey,
            result.hasGrown
        );

        if (result.hasGrown) {
            for (int dx = -simDist; dx <= simDist; dx++) {
                for (int dz = -simDist; dz <= simDist; dz++) {
                    this.addTrackedChunk(
                        new ChunkPos(
                            chunkPos.x + dx,
                            chunkPos.z + dz
                        )
                    );
                }
            }
        }

        if (result.growthCount > 0) {
            for (int dx = -simDist; dx <= simDist; dx++) {
                for (int dz = -simDist; dz <= simDist; dz++) {
                    long key =
                        ChunkPos.toLong(
                            chunkPos.x + dx,
                            chunkPos.z + dz
                        );

                    this.chunkHeatmap.merge(
                        key,
                        result.growthCount,
                        Integer::sum
                    );
                }
            }
        }

        if (!result.deepslate.isEmpty()) {
            this.chunkDeepslateMap.put(
                chunkKey,
                result.deepslate
            );

            this.suspiciousDeepslateBlocks
                .addAll(result.deepslate);
        }
    }

    private void addTrackedChunk(ChunkPos pos) {
        this.trackedChunks.merge(
            pos.toLong(),
            1,
            Integer::sum
        );
    }

    private void removeTrackedChunk(ChunkPos pos) {
        this.trackedChunks.compute(
            pos.toLong(),
            (key, value) ->
                decrementTracked(value)
        );
    }

    public boolean isChunkTracked(ChunkPos pos) {
        return this.trackedChunks.containsKey(
            pos.toLong()
        );
    }

    private ScanResult scanChunkBlocks(
        ChunkPos chunkPos,
        WorldChunk chunk,
        MinecraftClient mc
    ) {
        if (mc.world == null) {
            return new ScanResult(
                0,
                false,
                Set.of()
            );
        }

        ChunkSection[] sections =
            chunk.getSectionArray();

        int bottomSection =
            chunk.getBottomSectionCoord();

        int startX =
            chunkPos.getStartX();

        int startZ =
            chunkPos.getStartZ();

        boolean checkKelp = this.kelp.get();
        boolean checkCaveVines = this.caveVines.get();
        boolean checkVines = this.vines.get();
        boolean checkAmethyst = this.amethyst.get();
        boolean checkBamboo = this.bamboo.get();
        boolean checkBeeNest = this.beeNest.get();
        boolean checkDeepslate = this.rotatedDeepslate.get();

        int kelpGrown = 0;
        int kelpNotGrown = 0;

        int caveVinesGrown = 0;
        int caveVinesNotGrown = 0;

        int vinesGrown = 0;
        int vinesNotGrown = 0;

        int amethystGrown = 0;
        int amethystNotGrown = 0;

        int bambooGrown = 0;
        int bambooNotGrown = 0;

        int beeNestGrown = 0;
        int beeNestNotGrown = 0;

        boolean checkDonutFolia =
            checkAmethyst &&
            this.isDonutFolia();

        boolean foundBuds = false;
        boolean foundClusters = false;

        Set<BlockPos> deepslatePosSet =
            ConcurrentHashMap.newKeySet();

        for (int secIndex = 0;
             secIndex < sections.length;
             secIndex++) {

            ChunkSection section =
                sections[secIndex];

            if (section == null ||
                section.isEmpty()) {
                continue;
            }

            /*
             * Fast palette check:
             * if the section contains none of our enabled
             * blocks, skip all 4096 positions in that section.
             */
            if (!section.getBlockStateContainer().hasAny(
                state ->
                    (checkKelp && state.isOf(Blocks.KELP)) ||
                    (checkCaveVines && state.isOf(Blocks.CAVE_VINES)) ||
                    (checkVines && state.isOf(Blocks.VINE)) ||
                    (checkAmethyst && (
                        state.isOf(Blocks.AMETHYST_CLUSTER) ||
                        state.isOf(Blocks.SMALL_AMETHYST_BUD) ||
                        state.isOf(Blocks.MEDIUM_AMETHYST_BUD) ||
                        state.isOf(Blocks.LARGE_AMETHYST_BUD)
                    )) ||
                    (checkBamboo && state.isOf(Blocks.BAMBOO)) ||
                    (checkBeeNest && state.isOf(Blocks.BEE_NEST)) ||
                    (checkDeepslate && state.isOf(Blocks.DEEPSLATE))
            )) {
                continue;
            }

            int sectionMinY =
                (bottomSection + secIndex) << 4;

            if (checkDonutFolia) {
                if (!foundBuds &&
                    section.getBlockStateContainer()
                        .hasAny(
                            SusChunkScanner::isAmethystBud
                        )) {
                    foundBuds = true;
                }

                if (!foundClusters &&
                    section.getBlockStateContainer()
                        .hasAny(
                            SusChunkScanner::isAmethystCluster
                        )) {
                    foundClusters = true;
                }
            }

            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {

                        BlockState state =
                            section.getBlockState(x, y, z);

                        if (checkKelp &&
                            state.isOf(Blocks.KELP) &&
                            state.contains(Properties.AGE_25)) {

                            int age =
                                state.get(Properties.AGE_25);

                            BlockPos above =
                                new BlockPos(
                                    startX + x,
                                    sectionMinY + y + 1,
                                    startZ + z
                                );

                            boolean waterAbove =
                                mc.world
                                    .getBlockState(above)
                                    .isOf(Blocks.WATER);

                            if (age != 25 && waterAbove) {
                                kelpGrown++;
                            } else {
                                kelpNotGrown++;
                            }
                        }

                        if (checkCaveVines &&
                            state.isOf(Blocks.CAVE_VINES) &&
                            state.contains(Properties.AGE_25)) {

                            int age =
                                state.get(Properties.AGE_25);

                            BlockPos below =
                                new BlockPos(
                                    startX + x,
                                    sectionMinY + y - 1,
                                    startZ + z
                                );

                            boolean airBelow =
                                mc.world
                                    .getBlockState(below)
                                    .isAir();

                            if (age != 25 && airBelow) {
                                caveVinesGrown++;
                            } else {
                                caveVinesNotGrown++;
                            }
                        }

                        if (checkVines &&
                            state.isOf(Blocks.VINE)) {

                            BlockPos pos =
                                new BlockPos(
                                    startX + x,
                                    sectionMinY + y,
                                    startZ + z
                                );

                            BlockState below =
                                mc.world.getBlockState(
                                    pos.down()
                                );

                            if (!below.isOf(Blocks.VINE)) {
                                if (!below.isAir()) {
                                    vinesNotGrown++;
                                } else if (
                                    state.get(Properties.NORTH) ||
                                    state.get(Properties.EAST) ||
                                    state.get(Properties.SOUTH) ||
                                    state.get(Properties.WEST)
                                ) {
                                    vinesGrown++;
                                } else {
                                    vinesNotGrown++;
                                }
                            }
                        }

                        if (checkAmethyst &&
                            !checkDonutFolia) {

                            if (state.isOf(
                                Blocks.AMETHYST_CLUSTER
                            )) {

                                amethystNotGrown++;

                                this.amethystCells.add(
                                    new BlockPos(
                                        startX + x,
                                        sectionMinY + y,
                                        startZ + z
                                    )
                                );

                            } else if (
                                (
                                    state.isOf(
                                        Blocks.SMALL_AMETHYST_BUD
                                    ) ||
                                    state.isOf(
                                        Blocks.MEDIUM_AMETHYST_BUD
                                    ) ||
                                    state.isOf(
                                        Blocks.LARGE_AMETHYST_BUD
                                    )
                                ) &&
                                state.contains(
                                    Properties.FACING
                                )
                            ) {

                                Direction facing =
                                    state.get(
                                        Properties.FACING
                                    );

                                BlockPos parentPos =
                                    new BlockPos(
                                        startX + x,
                                        sectionMinY + y,
                                        startZ + z
                                    ).offset(
                                        facing.getOpposite()
                                    );

                                if (mc.world
                                    .getBlockState(parentPos)
                                    .isOf(
                                        Blocks.BUDDING_AMETHYST
                                    )) {
                                    amethystGrown++;
                                } else {
                                    amethystNotGrown++;
                                }
                            }
                        }

                        if (checkBamboo &&
                            state.isOf(Blocks.BAMBOO) &&
                            state.contains(Properties.STAGE)) {

                            BlockPos above =
                                new BlockPos(
                                    startX + x,
                                    sectionMinY + y + 1,
                                    startZ + z
                                );

                            BlockState stateAbove =
                                mc.world.getBlockState(above);

                            if (!stateAbove.isOf(
                                Blocks.BAMBOO
                            )) {
                                if (state.get(
                                    Properties.STAGE
                                ) == 1) {
                                    bambooNotGrown++;
                                } else if (
                                    stateAbove.isAir()
                                ) {
                                    bambooGrown++;
                                }
                            }
                        }

                        if (checkBeeNest &&
                            state.isOf(Blocks.BEE_NEST) &&
                            state.contains(
                                Properties.HONEY_LEVEL
                            )) {

                            if (state.get(
                                Properties.HONEY_LEVEL
                            ) == 5) {
                                beeNestNotGrown++;
                            } else {
                                beeNestGrown++;
                            }
                        }

                        if (checkDeepslate &&
                            state.isOf(Blocks.DEEPSLATE) &&
                            state.contains(Properties.AXIS) &&
                            state.get(Properties.AXIS) != Axis.Y) {

                            int blockY =
                                sectionMinY + y;

                            if (blockY >= 0 &&
                                blockY <= 60) {

                                BlockPos pos =
                                    new BlockPos(
                                        startX + x,
                                        blockY,
                                        startZ + z
                                    );

                                boolean fullySurrounded = true;

                                for (Direction dir :
                                    Direction.values()) {

                                    if (mc.world
                                        .getBlockState(
                                            pos.offset(dir)
                                        )
                                        .isAir()) {

                                        fullySurrounded = false;
                                        break;
                                    }
                                }

                                if (fullySurrounded) {
                                    deepslatePosSet.add(pos);
                                }
                            }
                        }
                    }
                }
            }
        }

        if (checkDonutFolia) {
            if (foundBuds) {
                amethystGrown++;
            } else if (foundClusters) {
                amethystNotGrown++;
            }
        }

        int totalGrown =
            (checkKelp ? kelpGrown : 0) +
            (checkCaveVines ? caveVinesGrown : 0) +
            (checkVines ? vinesGrown : 0) +
            (checkAmethyst ? amethystGrown : 0) +
            (checkBamboo ? bambooGrown : 0) +
            (checkBeeNest ? beeNestGrown : 0);

        int totalNotGrown =
            (checkKelp ? kelpNotGrown : 0) +
            (checkCaveVines ? caveVinesNotGrown : 0) +
            (checkVines ? vinesNotGrown : 0) +
            (checkAmethyst ? amethystNotGrown : 0) +
            (checkBamboo ? bambooNotGrown : 0) +
            (checkBeeNest ? beeNestNotGrown : 0);

        boolean hasGrown =
            totalGrown > 0;

        return new ScanResult(totalNotGrown, hasGrown, deepslatePosSet);
    }

    private void pruneOldData(ChunkPos center) {
        int simDist =
            this.simulationDistance.getInt();

        int radius =
            18 + simDist;

        this.chunkHeatmap.keySet().removeIf(
            key -> {
                ChunkPos pos =
                    new ChunkPos(key);

                return Math.abs(
                    pos.x - center.x
                ) > radius ||
                Math.abs(
                    pos.z - center.z
                ) > radius;
            }
        );

        this.trackedChunks.keySet().removeIf(
            key -> {
                ChunkPos pos =
                    new ChunkPos(key);

                return Math.abs(
                    pos.x - center.x
                ) > radius ||
                Math.abs(
                    pos.z - center.z
                ) > radius;
            }
        );

        this.lastScannedTick.keySet().removeIf(
            key -> {
                ChunkPos pos =
                    new ChunkPos(key);

                return Math.abs(
                    pos.x - center.x
                ) > radius ||
                Math.abs(
                    pos.z - center.z
                ) > radius;
            }
        );
    }

    public boolean isDonutFolia() {
        MinecraftClient mc =
            MinecraftClient.getInstance();

        if (mc.getNetworkHandler() == null) {
            return false;
        }

        String brand =
            mc.getNetworkHandler().getBrand();

        return brand != null &&
            brand.contains("DonutFolia");
    }

    public static boolean isAmethystCluster(
        BlockState state
    ) {
        return state.getBlock() ==
            Blocks.AMETHYST_CLUSTER;
    }

    public static boolean isAmethystBud(
        BlockState state
    ) {
        return state.getBlock() ==
            Blocks.SMALL_AMETHYST_BUD ||
            state.getBlock() ==
                Blocks.MEDIUM_AMETHYST_BUD ||
            state.getBlock() ==
                Blocks.LARGE_AMETHYST_BUD;
    }

    private static Integer decrementTracked(
        Integer value
    ) {
        if (value == null) {
            return null;
        }

        int newValue =
            value - 1;

        return newValue <= 0
            ? null
            : newValue;
    }

    private static Integer decrementValue(
        int amount,
        Integer value
    ) {
        int newValue =
            (value == null ? 0 : value) - amount;

        return newValue <= 0
            ? null
            : newValue;
    }

    private record ScanResult(
        int growthCount,
        boolean hasGrown,
        Set<BlockPos> deepslate
    ) {
    }
}