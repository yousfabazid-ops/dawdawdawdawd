package Yuki.skebob.hud.components;

import Yuki.skebob.hud.HudComponent;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.Colors;
import java.util.function.BooleanSupplier;

public class WatermarkHud extends HudComponent {
   private static final float HEIGHT = 30.0F;
   private static final float PAD = 13.0F;
   private static final float LOGO_SIZE = 24.0F;
   private static final float TEXT_SIZE = 14.0F;
   private final ThemeManager themes;

   public WatermarkHud(ThemeManager themes, BooleanSupplier visible) {
      super("watermark", 0.03F, 0.04F, visible);
      this.themes = themes;
   }

   public float measureWidth(NVGRenderer vg) {
      return 13.0F + vg.textWidth("SkebobClient", 16.0F) + 13.0F;
   }

   public float measureHeight(NVGRenderer vg) {
      return 30.0F;
   }

   public void render(NVGRenderer vg, float x, float y, float w, float h) {
      Theme theme = this.themes.current();
      float cy = y + h / 2.0F;
      float breathe = (float)((double)0.5F + (double)0.5F * Math.sin((double)System.nanoTime() / (double)8.0E8F));
      float drift = (float)((double)0.5F + (double)0.5F * Math.sin((double)System.nanoTime() / (double)4.8E8F));
      int gradTop = Colors.lerp(theme.accentBright(), theme.accent(), drift);
      int gradBottom = Colors.lerp(theme.accent(), theme.accentBright(), drift);
      vg.glow(x, y, w, h, h / 2.0F, 8.0F, Colors.withAlpha(theme.accent(), 0.1F + 0.1F * breathe));
      vg.rect(x, y, w, h, 5.0F, Colors.withAlpha(theme.background(), 0.94F));
      vg.rectOutline(x, y, w, h, 5.0F, 1.5F, -1);
      float tx = x + 13.0F;
      vg.textGlow("SkebobClient", tx, cy, 16.0F, Colors.withAlpha(theme.accent(), 0.45F + 0.3F * breathe));
      vg.textGradient("SkebobClient", tx, cy, 16.0F, gradTop, gradBottom);
   }
}
