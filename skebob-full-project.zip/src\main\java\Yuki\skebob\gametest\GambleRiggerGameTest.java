package Yuki.skebob.gametest;

import Yuki.skebob.SkebobClient;
import Yuki.skebob.gui.ClickGuiScreen;
import Yuki.skebob.module.impl.GambleRiggerModule;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestServerContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.util.Hand;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.Generic3x3ContainerScreenHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.client.gui.screen.ingame.Generic3x3ContainerScreen;

public class GambleRiggerGameTest implements FabricClientGameTest {
   private static final BlockPos DISPENSER = new BlockPos(2, -59, 4);
   private static final Item[] ITEM;
   private static final String[] ID;
   private static final int[] COUNT;

   public void runTest(ClientGameTestContext context) {
      TestSingleplayerContext world = context.worldBuilder().create();

      try {
         world.getClientWorld().waitForChunksRender();
         context.runOnClient((mc) -> mc.options.pauseOnLostFocus = false);
         context.getInput().resizeWindow(1600, 900);
         context.waitTicks(2);
         TestServerContext server = world.getServer();
         server.runCommand("gamemode survival @a");
         server.runCommand("clear @a");
         server.runCommand("setblock 2 -59 4 minecraft:dispenser");

         for(int i = 0; i < 9; ++i) {
            server.runCommand("item replace block 2 -59 4 container." + i + " with " + ID[i] + " " + COUNT[i]);
         }

         server.runCommand("tp @a 2 -58 2 0 0");
         context.waitTicks(20);
         world.getClientWorld().waitForChunksRender();
         context.runOnClient((mc) -> {
            GambleRiggerModule mod = SkebobClient.modules().gambleRigger;
            require(mod != null, "GambleRigger registered");
            require(!mod.isEnabled(), "starts disabled");
            mod.clickDelay.set((double)0.0F);
            mod.chatFeedback.set(false);
            mod.keepStays.set(true);
            mod.setEnabled(true);
         });
         openDispenser(context);
         context.waitTicks(3);
         context.runOnClient((mc) -> {
            ScreenHandler menu = mc.player.currentScreenHandler;
            require(menu instanceof Generic3x3ContainerScreenHandler, "dispenser menu open, got " + menu.getClass().getSimpleName());

            for(int i = 0; i < 9; ++i) {
               ItemStack s = menu.getSlot(i).getStack();
               require(s.isOf(ITEM[i]) && s.getCount() == COUNT[i], "grid slot " + i + " should be " + String.valueOf(ITEM[i]) + " x" + COUNT[i] + ", got " + describe(s));
            }

         });
         context.takeScreenshot("gamblerigger-01-panel");
         context.runOnClient((mc) -> SkebobClient.modules().gambleRigger.requestKeep(5));
         context.waitTicks(40);
         context.runOnClient((mc) -> {
            GambleRiggerModule mod = SkebobClient.modules().gambleRigger;
            require(mod.phase() == GambleRiggerModule.Phase.EXTRACTED, "after taking, phase should be EXTRACTED, got " + String.valueOf(mod.phase()));
            ScreenHandler menu = mc.player.currentScreenHandler;
            require(menu.getSlot(5).getStack().isOf(ITEM[5]) && menu.getSlot(5).getStack().getCount() == COUNT[5], "kept slot #6 must stay in place, got " + describe(menu.getSlot(5).getStack()));

            for(int i = 0; i < 9; ++i) {
               if (i != 5) {
                  require(menu.getSlot(i).getStack().isEmpty(), "grid slot " + i + " should be empty after taking, got " + describe(menu.getSlot(i).getStack()));
                  boolean var10000 = invHas(menu, ITEM[i], COUNT[i]);
                  String var10001 = String.valueOf(ITEM[i]);
                  require(var10000, "inventory must now hold " + var10001 + " x" + COUNT[i] + " pulled from slot " + i);
               }
            }

         });
         context.takeScreenshot("gamblerigger-02-taken-keep6");
         context.runOnClient((mc) -> SkebobClient.modules().gambleRigger.requestRestore());
         context.waitTicks(40);
         context.runOnClient((mc) -> {
            GambleRiggerModule mod = SkebobClient.modules().gambleRigger;
            require(mod.phase() == GambleRiggerModule.Phase.IDLE, "after restore, phase should be IDLE, got " + String.valueOf(mod.phase()));
            ScreenHandler menu = mc.player.currentScreenHandler;

            for(int i = 0; i < 9; ++i) {
               ItemStack s = menu.getSlot(i).getStack();
               require(s.isOf(ITEM[i]) && s.getCount() == COUNT[i], "restored grid slot " + i + " should be " + String.valueOf(ITEM[i]) + " x" + COUNT[i] + ", got " + describe(s));
            }

         });
         context.takeScreenshot("gamblerigger-03-restored");
         context.runOnClient((mc) -> {
            GambleRiggerModule mod = SkebobClient.modules().gambleRigger;
            mod.keepStays.set(false);
            mod.requestKeep(2);
         });
         context.waitTicks(40);
         context.runOnClient((mc) -> {
            ScreenHandler menu = mc.player.currentScreenHandler;

            for(int i = 0; i < 9; ++i) {
               require(menu.getSlot(i).getStack().isEmpty(), "keep-stays OFF: slot " + i + " should be empty after taking, got " + describe(menu.getSlot(i).getStack()));
            }

         });
         context.runOnClient((mc) -> SkebobClient.modules().gambleRigger.requestRestore());
         context.waitTicks(40);
         context.runOnClient((mc) -> {
            ScreenHandler menu = mc.player.currentScreenHandler;
            require(menu.getSlot(2).getStack().isEmpty(), "keep-stays OFF: picked slot #3 must be left empty, got " + describe(menu.getSlot(2).getStack()));
            boolean var10000 = invHas(menu, ITEM[2], COUNT[2]);
            String var10001 = String.valueOf(ITEM[2]);
            require(var10000, "keep-stays OFF: you must still hold the picked stack " + var10001 + " x" + COUNT[2]);

            for(int i = 0; i < 9; ++i) {
               if (i != 2) {
                  ItemStack s = menu.getSlot(i).getStack();
                  require(s.isOf(ITEM[i]) && s.getCount() == COUNT[i], "keep-stays OFF: slot " + i + " should be restored to " + String.valueOf(ITEM[i]) + " x" + COUNT[i] + ", got " + describe(s));
               }
            }

         });
         context.takeScreenshot("gamblerigger-04-keepoff-slot3-empty");
         context.runOnClient((mc) -> {
            if (mc.player != null) {
               mc.player.closeHandledScreen();
            }

            SkebobClient.modules().gambleRigger.keepStays.set(true);
            SkebobClient.modules().gambleRigger.reset();
         });
         context.waitForScreen((Class)null);
         context.runOnClient((mc) -> ClickGuiScreen.state().setExpanded("GambleRigger@MISC", true));
         context.getInput().pressKey(344);
         context.waitForScreen(ClickGuiScreen.class);
         context.waitTicks(8);
         context.takeScreenshot("gamblerigger-05-settings");
         context.runOnClient((mc) -> {
            SkebobClient.modules().gambleRigger.setEnabled(false);
            ClickGuiScreen.state().setExpanded("GambleRigger@MISC", false);
         });
         context.getInput().pressKey(344);
         context.waitForScreen((Class)null);
      } catch (Throwable var6) {
         if (world != null) {
            try {
               world.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }
         }

         throw var6;
      }

      if (world != null) {
         world.close();
      }

   }

   private static void openDispenser(ClientGameTestContext context) {
      context.runOnClient((mc) -> {
         if (mc.player != null && mc.interactionManager != null) {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(DISPENSER), Direction.UP, DISPENSER, false));
         }

      });
      context.waitForScreen(Generic3x3ContainerScreen.class);
   }

   private static boolean invHas(ScreenHandler menu, Item item, int count) {
      for(int i = 9; i < 45; ++i) {
         ItemStack s = menu.getSlot(i).getStack();
         if (s.isOf(item) && s.getCount() == count) {
            return true;
         }
      }

      return false;
   }

   private static String describe(ItemStack s) {
      return s.isEmpty() ? "empty" : String.valueOf(s.getItem()) + " x" + s.getCount();
   }

   private static void require(boolean condition, String what) {
      if (!condition) {
         throw new AssertionError("FAILED: " + what);
      }
   }

   static {
      ITEM = new Item[]{Items.DIAMOND, Items.EMERALD, Items.GOLD_INGOT, Items.IRON_INGOT, Items.REDSTONE, Items.LAPIS_LAZULI, Items.COAL, Items.QUARTZ, Items.GLOWSTONE_DUST};
      ID = new String[]{"minecraft:diamond", "minecraft:emerald", "minecraft:gold_ingot", "minecraft:iron_ingot", "minecraft:redstone", "minecraft:lapis_lazuli", "minecraft:coal", "minecraft:quartz", "minecraft:glowstone_dust"};
      COUNT = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
   }
}
