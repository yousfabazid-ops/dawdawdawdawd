package Yuki.skebob.hud.components;

import Yuki.skebob.hud.HudComponent;
import Yuki.skebob.module.Modules;
import Yuki.skebob.render.nanovg.NVGImages;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import Yuki.skebob.util.Colors;
import java.util.function.BooleanSupplier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class RadarHud extends HudComponent {
   private static final float SIZE = 128.0F;
   private final Modules.HudModule module;
   private final ThemeManager themes;

   public RadarHud(Modules.HudModule module, ThemeManager themes, BooleanSupplier visible) {
      super("radar", 0.12F, 0.34F, visible);
      this.module = module;
      this.themes = themes;
      this.setScale(1.25F);
   }

   public float measureWidth(NVGRenderer vg) {
      return 128.0F;
   }

   public float measureHeight(NVGRenderer vg) {
      return 128.0F;
   }

   public void render(NVGRenderer vg, float x, float y, float w, float h) {
      Theme theme = this.themes.current();
      PlayerEntity self = MinecraftClient.getInstance().player;
      if (self != null) {
         float radius = w / 2.0F;
         float cx = x + radius;
         float cy = y + radius;
         vg.circle(cx, cy, radius, Colors.withAlpha(theme.background(), 0.94F));
         vg.circleOutline(cx, cy, radius, 1.4F, -1);
         int cross = Colors.withAlpha(theme.accent(), 0.18F);
         vg.line(cx - radius, cy, cx + radius, cy, 1.0F, cross);
         vg.line(cx, cy - radius, cx, cy + radius, 1.0F, cross);
         float yaw = self.getYaw();
         float facing = (float)Math.toRadians((double)(yaw + 90.0F));
         String[] names = new String[]{"N", "E", "S", "W"};
         float[][] dirs = new float[][]{{0.0F, -1.0F}, {1.0F, 0.0F}, {0.0F, 1.0F}, {-1.0F, 0.0F}};

         for(int i = 0; i < 4; ++i) {
            float sx = screenX(dirs[i][0], dirs[i][1], facing);
            float sy = screenY(dirs[i][0], dirs[i][1], facing);
            float mx = cx + sx * (radius - 9.0F);
            float my = cy + sy * (radius - 9.0F);
            vg.text(names[i], mx - vg.textWidth(names[i], 11.0F) / 2.0F, my, 11.0F, -1);
         }

         vg.circleGlow(cx, cy, 3.0F, 4.0F, Colors.withAlpha(theme.accent(), 0.6F));
         vg.circle(cx, cy, 3.0F, theme.accentBright());
         float headSize = Math.max(10.0F, radius * 0.17F);
         float range = 48.0F;

         for(AbstractClientPlayerEntity other : MinecraftClient.getInstance().world.getPlayers()) {
            if (other != self) {
               float dx = (float)(other.getX() - self.getX());
               float dz = (float)(other.getZ() - self.getZ());
               float dist = (float)Math.sqrt((double)(dx * dx + dz * dz));
               if (!(dist > range)) {
                  float t = dist / range;
                  float px = cx + screenX(dx, dz, facing) / Math.max(dist, 0.001F) * t * (radius - headSize / 2.0F - 3.0F);
                  float py = cy + screenY(dx, dz, facing) / Math.max(dist, 0.001F) * t * (radius - headSize / 2.0F - 3.0F);
                  int skin = NVGImages.wrapGlTexture(other.getSkin().comp_1626().comp_3627(), 64, 64);
                  if (skin > 0) {
                     float hx = px - headSize / 2.0F;
                     float hy = py - headSize / 2.0F;
                     NVGImages.drawSubImage(vg, skin, 64.0F, 64.0F, 8.0F, 8.0F, 16.0F, 16.0F, hx, hy, headSize, headSize, 1.0F);
                     NVGImages.drawSubImage(vg, skin, 64.0F, 64.0F, 40.0F, 8.0F, 48.0F, 16.0F, hx, hy, headSize, headSize, 1.0F);
                     vg.rectOutline(hx - 1.0F, hy - 1.0F, headSize + 2.0F, headSize + 2.0F, 3.0F, 1.0F, Colors.withAlpha(-1, 0.35F));
                  } else {
                     vg.circleGlow(px, py, 2.5F, 3.0F, Colors.withAlpha(-1, 0.4F));
                     vg.circle(px, py, 2.5F, -1);
                  }
               }
            }
         }
      }

   }

   private static float screenX(float dx, float dz, float facing) {
      return (float)((double)(-dx) * Math.sin((double)facing) + (double)dz * Math.cos((double)facing));
   }

   private static float screenY(float dx, float dz, float facing) {
      return (float)(-((double)dx * Math.cos((double)facing) + (double)dz * Math.sin((double)facing)));
   }
}
