package Yuki.skebob.suschunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/** Independent, incremental amethyst/chest candidate scanner for Sus Chunk Finder V2. */
public final class SusChunkFinderV2Scanner {
    private static final int REFRESH_QUEUE_EVERY_TICKS = 5;
    private static final int RESCAN_INTERVAL_TICKS = 200;
    private static final int PRUNE_EVERY_TICKS = 20;
    private static final int CHUNKS_PER_TICK = 3;
    private static final int[] SHAPE_WIDTHS = {1, 2, 1, 3, 5, 5};
    private static final int[] SHAPE_DEPTHS = {4, 4, 2, 1, 4, 6};

    private final ArrayDeque<ChunkPos> scanQueue = new ArrayDeque<>();
    private final Set<Long> queuedKeys = new HashSet<>();
    private final Map<Long, Long> lastScanTick = new HashMap<>();
    private final Map<Long, ScanResult> results = new HashMap<>();
    private final Set<Long> displayChunks = new HashSet<>();
    private final Set<Long> displayChunksView = Collections.unmodifiableSet(displayChunks);

    private ClientWorld trackedWorld;
    private int tickCounter;
    private int lastQueueRefreshTick;

    public void tick(int scanRadius, int simChunks, int sensitivity, boolean chestFilter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) {
            clear();
            return;
        }

        if (trackedWorld != client.world) {
            clear();
            trackedWorld = client.world;
        }

        tickCounter++;
        int radius = Math.max(1, Math.min(5, scanRadius)) * 5;
        int centerX = client.player.getBlockX() >> 4;
        int centerZ = client.player.getBlockZ() >> 4;

        if (tickCounter - lastQueueRefreshTick >= REFRESH_QUEUE_EVERY_TICKS) {
            enqueueNearbyLoadedChunks(client.world, centerX, centerZ, radius);
            lastQueueRefreshTick = tickCounter;
        }

        int budget = CHUNKS_PER_TICK;
        while (budget-- > 0 && !scanQueue.isEmpty()) {
            ChunkPos pos = scanQueue.removeFirst();
            long key = pos.toLong();
            queuedKeys.remove(key);

            if (Math.abs(pos.x - centerX) > radius || Math.abs(pos.z - centerZ) > radius) {
                continue;
            }

            WorldChunk chunk = client.world.getChunkManager().getWorldChunk(pos.x, pos.z, false);
            if (chunk == null) {
                continue;
            }

            ScanResult result = scanChunk(client.world, chunk);
            lastScanTick.put(key, (long) tickCounter);
            if (result.amethystCount > 0 || result.chestCount > 0) {
                results.put(key, result);
            } else {
                results.remove(key);
            }
        }

        if (tickCounter % PRUNE_EVERY_TICKS == 0) {
            pruneResults(client.world, centerX, centerZ, radius);
        }

        rebuildDisplayChunks(centerX, centerZ, client.player.getY(), sensitivity, simChunks, chestFilter);
    }

    private void enqueueNearbyLoadedChunks(ClientWorld world, int centerX, int centerZ, int radius) {
        for (int x = centerX - radius; x <= centerX + radius; x++) {
            for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                if (world.getChunkManager().getWorldChunk(x, z, false) == null) {
                    continue;
                }
                long key = ChunkPos.toLong(x, z);
                Long last = lastScanTick.get(key);
                if (last != null && tickCounter - last < RESCAN_INTERVAL_TICKS) {
                    continue;
                }
                if (queuedKeys.add(key)) {
                    scanQueue.addLast(new ChunkPos(x, z));
                }
            }
        }
    }

    private ScanResult scanChunk(ClientWorld world, WorldChunk chunk) {
        int amethystCount = 0;
        int chestCount = 0;
        int bottomY = world.getBottomY();
        ChunkSection[] sections = chunk.getSectionArray();
        int firstSectionY = bottomY >> 4;

        for (int index = 0; index < sections.length; index++) {
            ChunkSection section = sections[index];
            if (section == null || section.isEmpty()) {
                continue;
            }

            int sectionBaseY = (firstSectionY + index) << 4;
            int fromY = Math.max(bottomY, sectionBaseY);
            int toY = Math.min(32, sectionBaseY + 15);
            if (fromY > toY) {
                continue;
            }

            boolean mayHaveAmethyst = section.hasAny(state ->
                state.isOf(Blocks.AMETHYST_CLUSTER) || state.isOf(Blocks.AMETHYST_BLOCK));
            boolean mayHaveChest = sectionBaseY < 0 && section.hasAny(state ->
                state.isOf(Blocks.CHEST) || state.isOf(Blocks.TRAPPED_CHEST));
            if (!mayHaveAmethyst && !mayHaveChest) {
                continue;
            }

            for (int y = fromY; y <= toY; y++) {
                int localY = y & 15;
                boolean countAmethystAtY = mayHaveAmethyst;
                boolean countChestAtY = mayHaveChest && y < 0 && chestCount < 10;
                if (!countAmethystAtY && !countChestAtY) {
                    continue;
                }
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        BlockState state = section.getBlockState(x, localY, z);
                        if (countAmethystAtY &&
                            (state.isOf(Blocks.AMETHYST_CLUSTER) || state.isOf(Blocks.AMETHYST_BLOCK))) {
                            amethystCount++;
                        }
                        if (countChestAtY &&
                            (state.isOf(Blocks.CHEST) || state.isOf(Blocks.TRAPPED_CHEST))) {
                            chestCount++;
                        }
                    }
                }
            }
        }
        return new ScanResult(amethystCount, chestCount);
    }

    private void pruneResults(ClientWorld world, int centerX, int centerZ, int radius) {
        Iterator<Map.Entry<Long, ScanResult>> iterator = results.entrySet().iterator();
        while (iterator.hasNext()) {
            long key = iterator.next().getKey();
            int x = ChunkPos.getPackedX(key);
            int z = ChunkPos.getPackedZ(key);
            boolean outsideRadius = Math.abs(x - centerX) > radius || Math.abs(z - centerZ) > radius;
            boolean unloaded = world.getChunkManager().getWorldChunk(x, z, false) == null;
            if (outsideRadius || unloaded) {
                iterator.remove();
                lastScanTick.remove(key);
            }
        }
    }

    private void rebuildDisplayChunks(int centerX, int centerZ, double playerY,
                                      int sensitivity, int simChunks, boolean chestFilter) {
        displayChunks.clear();
        int minCount = Math.max(1, Math.min(20, sensitivity));
        boolean applyChestFilter = chestFilter && playerY <= -2.0;
        List<Map.Entry<Long, ScanResult>> candidates = new ArrayList<>();

        for (Map.Entry<Long, ScanResult> entry : results.entrySet()) {
            ScanResult result = entry.getValue();
            if (result.amethystCount < minCount) {
                continue;
            }
            if (applyChestFilter && result.chestCount < 10) {
                continue;
            }
            candidates.add(entry);
        }

        candidates.sort(new Comparator<Map.Entry<Long, ScanResult>>() {
            @Override
            public int compare(Map.Entry<Long, ScanResult> left, Map.Entry<Long, ScanResult> right) {
                int byScore = Integer.compare(right.getValue().amethystCount, left.getValue().amethystCount);
                if (byScore != 0) {
                    return byScore;
                }
                long leftDistance = distanceSquared(left.getKey(), centerX, centerZ);
                long rightDistance = distanceSquared(right.getKey(), centerX, centerZ);
                return Long.compare(leftDistance, rightDistance);
            }
        });

        int candidateLimit = Math.max(3, 33 - minCount * 3);
        int limit = Math.min(candidateLimit, candidates.size());
        for (int index = 0; index < limit; index++) {
            Map.Entry<Long, ScanResult> candidate = candidates.get(index);
            long key = candidate.getKey();
            int chunkX = ChunkPos.getPackedX(key);
            int chunkZ = ChunkPos.getPackedZ(key);

            if (simChunks >= 10) {
                displayChunks.add(key);
                continue;
            }

            int shape = Math.floorMod((int) (key ^ candidate.getValue().amethystCount), SHAPE_WIDTHS.length);
            int width = SHAPE_WIDTHS[shape];
            int depth = SHAPE_DEPTHS[shape];
            int startX = chunkX - (width / 2);
            int startZ = chunkZ - (depth / 2);
            for (int dx = 0; dx < width; dx++) {
                for (int dz = 0; dz < depth; dz++) {
                    displayChunks.add(ChunkPos.toLong(startX + dx, startZ + dz));
                }
            }
        }
    }

    private long distanceSquared(long key, int centerX, int centerZ) {
        long dx = (long) ChunkPos.getPackedX(key) - centerX;
        long dz = (long) ChunkPos.getPackedZ(key) - centerZ;
        return dx * dx + dz * dz;
    }

    public Set<Long> suspiciousChunks() {
        return displayChunksView;
    }

    public void clear() {
        scanQueue.clear();
        queuedKeys.clear();
        lastScanTick.clear();
        results.clear();
        displayChunks.clear();
        trackedWorld = null;
        tickCounter = 0;
        lastQueueRefreshTick = 0;
    }

    private static final class ScanResult {
        private final int amethystCount;
        private final int chestCount;

        private ScanResult(int amethystCount, int chestCount) {
            this.amethystCount = amethystCount;
            this.chestCount = chestCount;
        }
    }
}