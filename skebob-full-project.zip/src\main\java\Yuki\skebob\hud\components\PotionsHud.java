package Yuki.skebob.hud.components;

import Yuki.skebob.hud.HudComponent;
import Yuki.skebob.render.nanovg.NVGImages;
import Yuki.skebob.render.nanovg.NVGRenderer;
import Yuki.skebob.theme.Theme;
import Yuki.skebob.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;

public class PotionsHud extends HudComponent {
   private static final float ROW = 24.0F;
   private static final float ICON = 18.0F;
   private static final float PAD = 7.0F;
   private static final float FONT = 12.5F;
   private final ThemeManager themes;

   public PotionsHud(ThemeManager themes, BooleanSupplier visible) {
      super("potions", 0.86F, 0.48F, visible);
      this.themes = themes;
   }

   private List<StatusEffectInstance> effects() {
      PlayerEntity player = MinecraftClient.getInstance().player;
      if (player == null) {
         return List.of();
      } else {
         List<StatusEffectInstance> list = new ArrayList(player.getStatusEffects());
         list.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());
         return list;
      }
   }

   private static String label(StatusEffectInstance effect) {
      String name = ((StatusEffect)effect.getEffectType().comp_349()).getName().getString();
      int amp = effect.getAmplifier();
      return amp > 0 ? name + " " + (amp + 1) : name;
   }

   private static String timer(StatusEffectInstance effect) {
      if (effect.isInfinite()) {
         return "âˆž";
      } else {
         int seconds = effect.getDuration() / 20;
         return String.format("%d:%02d", seconds / 60, seconds % 60);
      }
   }

   public float measureWidth(NVGRenderer vg) {
      float max = 110.0F;

      for(StatusEffectInstance effect : this.effects()) {
         max = Math.max(max, 31.0F + vg.textWidth(label(effect), 12.5F) + 10.0F + vg.textWidth(timer(effect), 12.5F) + 7.0F);
      }

      return max;
   }

   public float measureHeight(NVGRenderer vg) {
      return Math.max(24.0F, (float)this.effects().size() * 24.0F);
   }

   public void render(NVGRenderer vg, float x, float y, float w, float h) {
      Theme theme = this.themes.current();
      List<StatusEffectInstance> effects = this.effects();
      if (!effects.isEmpty()) {
         boolean right = this.rightAnchored();
         vg.rect(x, y, w, h, 9.0F, -16777216);
         float rowY = y;

         for(StatusEffectInstance effect : effects) {
            float labelW = vg.textWidth(label(effect), 12.5F);
            float timerW = vg.textWidth(timer(effect), 12.5F);
            float rowW = 31.0F + labelW + 10.0F + timerW + 7.0F;
            float rowX = right ? x + w - rowW : x;
            float cy = rowY + 12.0F;
            Identifier effectId = effect.getEffectType().getKey().map((k) -> (Identifier)k.getValue()).orElse(null);
            if (effectId != null) {
               int image = NVGImages.fromResource(Identifier.of(effectId.getNamespace(), "textures/mob_effect/" + effectId.getPath() + ".png"));
               if (image > 0) {
                  vg.imagePattern(image, rowX + 7.0F, cy - 9.0F, 18.0F, 18.0F, rowX + 7.0F, cy - 9.0F, 18.0F, 18.0F, 1.0F);
               }
            }

            vg.text(label(effect), rowX + 7.0F + 18.0F + 6.0F, cy, 12.5F, theme.textPrimary());
            vg.textGradient(timer(effect), rowX + rowW - 7.0F - timerW, cy, 12.5F, theme.accentBright(), theme.accent());
            rowY += 24.0F;
         }
      }

   }
}
